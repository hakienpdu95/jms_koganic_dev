=== Shoppable Images ===
Contributors: studiowombat,maartenbelmans
Tags: shoppable images,image hotspots,woocommerce,click to buy,tag image
Requires at least: 3.7
Tested up to: 4.9.6
Stable tag: 1.0.4

== Description ==

The pro version of the plugin.

= version 1.0.4 =
 * Enhancement: if a product doesn't exist anymore, it won't be loaded when editing an image in the backend.

= version 1.0.3 =
 * Enhancement: Better loading of Woo products on the backend.

= version 1.0.2 =
 * Fix: Small mobile enhancement.

= version 1.0.1 =
 * Fix: Remove get_display_price in favor of get_price.

= version 1.0.0 =
 * Initial version.