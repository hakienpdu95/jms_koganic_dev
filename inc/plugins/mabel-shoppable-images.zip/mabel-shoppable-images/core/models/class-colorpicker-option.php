<?php

namespace MABEL_SI\Core\Models {

	class ColorPicker_Option extends Option
	{

	}
}