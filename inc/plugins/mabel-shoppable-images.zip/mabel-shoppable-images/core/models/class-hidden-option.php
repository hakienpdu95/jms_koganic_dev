<?php

namespace MABEL_SI\Core\Models {

	class Hidden_Option extends Option
	{

	}
}