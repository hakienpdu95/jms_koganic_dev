<?php

namespace MABEL_SI\Core\Models {

	class Number_Option extends Text_Option
	{

	}
}