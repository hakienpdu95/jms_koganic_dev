<?php
/** @var \MABEL_SI\Core\Models\Hidden_Option $option */
?>

<input type="hidden" name="<?php echo $option->name; ?>" value="<?php echo $option->value; ?>" />