<?php

namespace MABEL_SI\Core\Common
{
	class Registry
	{

		/**
		 * @var Loader
		 */
		private static $loader;

		/**
		 * @return \MABEL_SI\Core\Common\Loader
		 */
		public static function get_loader()
		{
			if(self::$loader === null)
			{
				self::$loader = new Loader();
			}

			return self::$loader;
		}

	}
}