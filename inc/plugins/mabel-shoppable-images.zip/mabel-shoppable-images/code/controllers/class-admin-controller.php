<?php

namespace MABEL_SI\Code\Controllers
{
	use MABEL_SI\Core\Common\Admin;
	use MABEL_SI\Core\Common\Linq\Enumerable;
	use MABEL_SI\Core\Common\Managers\Config_Manager;
	use MABEL_SI\Core\Common\Managers\Options_Manager;
	use MABEL_SI\Core\Common\Managers\Settings_Manager;
	use MABEL_SI\Core\Models\ColorPicker_Option;
	use MABEL_SI\Core\Models\Custom_Option;
	use MABEL_SI\Core\Models\Dropdown_Option;
	use MABEL_SI\Core\Models\Range_Option;
	use MABEL_SI\Core\Models\Text_Option;
	use MongoDB\Driver\Query;

	if(!defined('ABSPATH')){die;}

	class Admin_Controller extends Admin
	{
		private $slug;
		public function __construct()
		{
			parent::__construct(new Options_Manager());
			$this->slug = Config_Manager::$slug;

			$this->add_mediamanager_scripts = true;

			$this->add_script_dependencies('wp-color-picker');
			$this->add_style('wp-color-picker',null);

			$this->add_ajax_function('mb-siwc-get-images', $this,'get_images',false,true);
			$this->add_ajax_function('mb-siwc-get-image', $this,'get_image',false,true);
			$this->add_ajax_function('mb-siwc-add-image', $this,'add_image',false,true);
			$this->add_ajax_function('mb-siwc-update-image', $this,'update_image',false,true);
			$this->add_ajax_function('mb-siwc-delete-image', $this, 'delete_image', false, true);

			$this->add_ajax_function('mb-siwc-get-product-by-id', $this, 'get_wc_product_by_id', false, true);
			$this->add_ajax_function('mb-siwc-get-products-by-ids', $this, 'get_wc_products_by_ids', false, true);
			$this->add_ajax_function('mb-siwc-get-products', $this, 'get_wc_product_by_name', false, true);
		}

		public function get_wc_products_by_ids() {

			if(empty($_GET['ids'])){
				echo json_encode(array());
				wp_die();
			}

			$is_new = version_compare( WC()->version, '3.0.0','>=') === true;

			$ps = get_posts(array( 'post_type' => 'product', 'post__in' => explode(',',$_GET['ids']) ));

			$products = array();

			foreach ($ps as $p){
				$product = wc_get_product($p->ID);

				$products[] = array(
					'name'  => $product->get_title(),
					'url'   => $product->get_permalink(),
					'price' => get_woocommerce_currency_symbol() . ($is_new ? wc_get_price_to_display($product) :  $product->get_display_price()),
					'id' => $product->get_id()
				);

			}

			echo json_encode($products);
			wp_die();
		}

		public function get_wc_product_by_id()
		{
			echo json_encode($this->get_wc_product($_GET['id']));
			wp_die();
		}

		public function get_wc_product_by_name()
		{
			global $wpdb;
			$product_ids = $wpdb->get_results( $wpdb->prepare( "
				SELECT ID as id 
				FROM {$wpdb->prefix}posts i
				WHERE post_type = 'product' AND post_title LIKE %s
				ORDER BY post_title ASC 
				LIMIT 5",'%' . $_GET['q'] . '%'
			));

			$products = array();

			foreach(Enumerable::from($product_ids)->select('$x => $x->id')->toArray() as $pid) {
				$product = $this->get_wc_product($pid);
				if(empty($product)) continue;
				array_push($products,$product);
			}

			echo json_encode($products);
			wp_die();
		}

		private function get_wc_product($pid)
		{
			$is_new = version_compare( WC()->version, '3.0.0','>=') === true;

			$product = wc_get_product($pid);


			return array(
				'name'  => $product->get_title(),
				'url'   => $product->get_permalink(),
				'price' => get_woocommerce_currency_symbol() . ($is_new ? wc_get_price_to_display($product) :  $product->get_display_price()),
				'id' => $product->get_id()
			);
		}

		public function delete_image()
		{
			wp_delete_post( $_REQUEST['imageId'], true );
			wp_die();
		}

		public function get_image()
		{
			if(!isset($_GET['id'])) wp_die();

			$post = get_post($_GET['id']);
			if($post == null) wp_die();

			wp_send_json(array(
				'id' => $post->ID,
				'image'  => json_decode(get_post_meta($post->ID,'image',true))->image,
				'tags' => json_decode(get_post_meta($post->ID,'tags',true))
			));
		}

		public function get_images()
		{
			$page = isset($_GET['page']) ? $_GET['page'] : 1;

			$post_ids = new \WP_Query(array(
				'post_type' => 'mb_siwc_image',
				'fields' => 'ids',
				'posts_per_page' => 12,
				'paged' => $page
			));

			$images = array();

			foreach ($post_ids->posts as $id){
				$thumb = json_decode(get_post_meta($id,'image',true))->thumb;
				$obj = (object) array(
					'id' => $id,
					'image'  => $thumb,
					'tags' => json_decode(get_post_meta($id,'tags',true))
				);
				array_push($images,$obj);
			}
			wp_reset_postdata();

			wp_send_json( array(
				'images' => $images,
				'maxPages' => $post_ids->max_num_pages,
				'currentPage' => $page
			));
		}

		public function update_image()
		{
			update_post_meta($_POST['id'],'tags',$_POST['tags']);
			wp_die();
		}

		public function add_image()
		{
			$id = wp_insert_post(array(
				'post_type' => 'mb_siwc_image',
				'post_status' => 'publish'
			),true);

			if(!is_wp_error( $id ) && $id > 0){

				add_post_meta($id,'image', json_encode(array(
					'image' => $_POST['image'],
					'thumb' => $_POST['thumb']
				)));
				add_post_meta($id,'tags', $_POST['tags']);
			}
			wp_die($id);
		}

		public function init_admin_page()
		{
			$this->options_manager->add_section('design', __('Design',$this->slug), 'admin-customizer', true);
			$this->options_manager->add_section('addimage', __('Add image',$this->slug), 'format-image');
			$this->options_manager->add_section('images', __('Images',$this->slug), 'images-alt2');

			$this->options_manager->add_option('design',
				new ColorPicker_Option(
					'tagbgcolor',
					Settings_Manager::get_setting('tagbgcolor'),
					__('Tag background color',$this->slug)
				)
			);

			$this->options_manager->add_option('design',
				new ColorPicker_Option(
					'tagfgcolor',
					Settings_Manager::get_setting('tagfgcolor'),
					__('Icon color',$this->slug)
				)
			);

			$this->options_manager->add_option('design',
				new Dropdown_Option(
					'tagicon',
					__('Tag icon',$this->slug),
					array(
						'siwc-icon-info' => 'Info',
						'siwc-icon-info_outline' => 'Info (outlined)',
						'siwc-icon-plus' => 'Plus',
						'siwc-icon-plus_thin' => 'Plus (thin)',
						'siwc-icon-tag' => 'Tag',
						'siwc-icon-tag_outline' => 'Tag (outline)',
						'siwc-icon-target' => 'Target'
					),
					Settings_Manager::get_setting('tagicon')
				)
			);

			$this->options_manager->add_option('addimage',
				new Custom_Option(null,'add_image',array(
					'woocommerce_active' => class_exists( 'WooCommerce' )
				))
			);

			$this->options_manager->add_option('design',
				new Range_Option(
					'tagsize',
					Settings_Manager::get_setting('tagsize'),
					__('Tag size',$this->slug),
					10,
					50
				)
			);

			$this->options_manager->add_option('design',
				new Range_Option(
					'iconsize',
					Settings_Manager::get_setting('iconsize'),
					__('Icon size',$this->slug),
					10,
					50
				)
			);

			$this->options_manager->add_option('design',
				new Range_Option(
					'tagborderradius',
					Settings_Manager::get_setting('tagborderradius'),
					__('Rounded corners',$this->slug),
					0,
					50
				)
			);

			$this->options_manager->add_option('design',
				new Text_Option(
					'buttontext',
					__('Button text', $this->slug),
					Settings_Manager::get_setting('buttontext'),
					null,
					__('What text should appear on the button linking to the product page?')
				)
			);

			$this->options_manager->add_option('images',
				new Custom_Option(null,'all_images')
			);

		}

	}
}