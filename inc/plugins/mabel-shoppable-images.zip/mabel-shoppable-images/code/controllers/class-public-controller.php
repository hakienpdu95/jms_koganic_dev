<?php

namespace MABEL_SI\Code\Controllers
{

	use MABEL_SI\Core\Common\Frontend;
	use MABEL_SI\Core\Common\Managers\Config_Manager;
	use MABEL_SI\Core\Common\Managers\Settings_Manager;
	use MABEL_SI\Core\Models\Inline_Style;

	if(!defined('ABSPATH')){die;}

	class Public_Controller extends Frontend
	{
		public function __construct()
		{
			parent::__construct();

			$this->add_script_dependencies('jquery');
			$this->add_script(Config_Manager::$slug,'public/js/public.min.js');
			$this->add_style(Config_Manager::$slug,'public/css/public.min.css');

			$style = new Inline_Style(Config_Manager::$slug,'span.mb-siwc-tag',array(
				'margin-left' => '-'.intval(Settings_Manager::get_setting('tagsize')/2) .'px',
				'margin-top' => '-'.intval(Settings_Manager::get_setting('tagsize')/2) .'px',
				'color' => Settings_Manager::get_setting('tagfgcolor'),
				'width' => Settings_Manager::get_setting('tagsize') .'px',
				'height' => Settings_Manager::get_setting('tagsize') .'px',
				'line-height' => Settings_Manager::get_setting('tagsize') .'px',
				'background' => Settings_Manager::get_setting('tagbgcolor'),
				'font-size' => Settings_Manager::get_setting('iconsize') .'px',
				'border-radius' => Settings_Manager::get_setting('tagborderradius') .'%',
				'-webkit-border-radius' => Settings_Manager::get_setting('tagborderradius') .'%',
				'-moz-border-radius' => Settings_Manager::get_setting('tagborderradius') .'%',
			));

			add_action('wp_footer',array($this,'add_mobile_check'));

			$this->add_inline_style($style);
		}

		public function add_mobile_check(){
			echo '<div class="si-mobile-check"></div>';
		}

		public function fetch_shortcode_ajax()
		{
			$attributes = htmlspecialchars_decode(stripslashes($_REQUEST['options']));
			echo do_shortcode('[' .$_REQUEST['code']. ' ' . $attributes . ' caching="false" ]');
			wp_die();
		}
	}
}