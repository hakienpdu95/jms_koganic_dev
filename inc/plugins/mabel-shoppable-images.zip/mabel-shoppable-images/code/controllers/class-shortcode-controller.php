<?php

namespace MABEL_SI\Code\Controllers
{

	use MABEL_SI\Code\Models\Shoppable_Image_VM;
	use MABEL_SI\Code\Models\Tag;
	use MABEL_SI\Code\Services\Woocommerce_Service;
	use MABEL_SI\Core\Common\Linq\Enumerable;
	use MABEL_SI\Core\Common\Managers\Config_Manager;
	use MABEL_SI\Core\Common\Managers\Settings_Manager;
	use MABEL_SI\Core\Common\Shortcode;

	if(!defined('ABSPATH')){die;}

	class Shortcode_Controller
	{
		private $slug;

		public function __construct()
		{
			$this->slug = Config_Manager::$slug;
			$this->init_shortcode();
		}

		private function init_shortcode()
		{
			new Shortcode(
				'shoppable_image',
				'shoppable-image',
				array($this,'create_shortcode_model')
			);
		}

		public function create_shortcode_model($attributes){
			$model = new Shoppable_Image_VM();

			if(!isset($attributes['id']) || get_post($attributes['id']) == null || get_post($attributes['id'])->post_type !== 'mb_siwc_image') {
				$model->show_error = true;
				return $model;
			}

			$model->button_text = Settings_Manager::get_setting('buttontext');
			$model->size = Settings_Manager::get_setting('tagsize');
			$model->icon = Settings_Manager::get_setting('tagicon');
			$model->image = json_decode(get_post_meta($attributes['id'],'image',true))->image;
			$taglist = json_decode(get_post_meta($attributes['id'],'tags',true));
			foreach($taglist as $tag)
			{
				$t = new Tag(round(doubleval($tag->x),4),round(doubleval($tag->y),4));
				if($tag->id){
					$product = Woocommerce_Service::get_product($tag->id);
					if($product === null)
						continue;
					$t->link = $product->get_permalink();
					preg_match( '/src="(.*?)"/', $product->get_image('shop_thumbnail'), $imgurl);
					$t->thumb = count($imgurl) === 2? $imgurl[1] : null;
					$t->price = get_woocommerce_currency_symbol() . $product->get_price();
					$t->title = $product->get_title();
				}else{
					$t->price = $tag->price;
					$t->title = $tag->name;
					$t->link = $tag->url;
				}

				array_push($model->tags, $t);
			}

			return $model;
		}

	}
}