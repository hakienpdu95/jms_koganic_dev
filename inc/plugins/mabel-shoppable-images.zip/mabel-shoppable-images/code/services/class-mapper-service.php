<?php

namespace MABEL_SI\Code\Services
{
	class Mapper_Service
	{

		public static function toTag($tag)
		{

		}
	}
}