<?php
/**
 * Plugin Name: Koganic Addons
 * Plugin URI: http://joommasters.com
 * Description: Currently supports the following theme functionality: shortcodes, CPT.
 * Version: 1.3
 * Author: JoomMasters
 * Author URI: http://joommasters.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: koganic-addons
 */

define( 'KOGANIC_ADDONS_URL', plugin_dir_url( __FILE__ ) );
define( 'KOGANIC_ADDONS_PATH', plugin_dir_path( __FILE__ ) );

if ( ! function_exists( 'is_plugin_active' ) ) {
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

/*
 * Load plugin textdomain
 */

if ( ! function_exists( 'koganic_addons_load_textdomain' ) ) {
	function koganic_addons_load_textdomain() {
		load_plugin_textdomain( 'koganic-addons', false, KOGANIC_ADDONS_PATH . 'languages' );
	}

	add_action( 'plugins_loaded', 'koganic_addons_load_textdomain' );
}

if ( ! empty( $_REQUEST['action'] ) && 'elementor' === $_REQUEST['action'] && is_admin() ) {
	add_action( 'init','koganic_register_wc_hooks', 5 );
	if ( class_exists( 'Woocommerce' ) ) {
		add_action( 'elementor/editor/before_enqueue_scripts', function() {
			remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
			remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
			remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
		} );
	}
}

if ( ! function_exists( 'koganic_admin_styles' ) ) {
	function koganic_admin_styles() {
		wp_enqueue_style( 'custom-style', KOGANIC_ADDONS_URL . 'assets/css/admin.css' );
	}

	add_action( 'admin_print_styles', 'koganic_admin_styles' );
}

function koganic_compress( $variable ) {
	return base64_encode( $variable );
}

function koganic_decompress( $variable ) {
	return base64_decode( $variable );
}

function koganic_get_svg( $variable ) {
	return file_get_contents( $variable );
}

/*
* [ CS Framework. ] - - - - - - - - - - - - - - - - - - - -
*/
require_once KOGANIC_ADDONS_PATH . 'inc/cs-framework/cs-framework.php';
require_once KOGANIC_ADDONS_PATH . 'inc/footer_layout/init.php';
require_once KOGANIC_ADDONS_PATH . 'inc/html_block/init.php';

/*
* [ Elementor. ] - - - - - - - - - - - - - - - - - - - -
*/

if ( did_action( 'elementor/loaded' ) ) {
	add_action( 'elementor/elements/categories_registered', 'koganic_add_elementor_widget_categories' );
	if ( ! function_exists( 'koganic_add_elementor_widget_categories' ) ) {
		function koganic_add_elementor_widget_categories( $elements_manager ) {
			$elements_manager->add_category(
				'koganic',
				[
					'title' => __( 'Koganic Addons', 'koganic-addons' ),
					'icon'  => 'fa fa-plug',
				]
			);
		}
	}
	add_action( 'elementor/widgets/widgets_registered', 'koganic_init_elementor_widgets' );
	if ( ! function_exists( 'koganic_init_elementor_widgets' ) ) {
		function koganic_init_elementor_widgets() {
			foreach ( glob( KOGANIC_ADDONS_PATH . 'inc/elementor/*.php' ) as $filename ) {
				include_once $filename;
			}
		}
	}
	add_action( 'elementor/controls/controls_registered', 'koganic_register_controls' );
	if ( ! function_exists( 'koganic_register_controls' ) ) {
		function koganic_register_controls() {
			include_once( __DIR__ . '/inc/elementor-koganic-control.php' );
			$controls_manager = \Elementor\Plugin::$instance->controls_manager;
			$controls_manager->register_control( 'koganic', new Koganic_Control() );
		}
	}
	if ( ! empty( $_REQUEST['action'] ) && 'elementor' === $_REQUEST['action'] && is_admin() ) {
		add_action( 'init','koganic_register_wc_hooks', 5 );
	}
	if ( ! function_exists( 'koganic_register_wc_hooks' ) ) {
		function koganic_register_wc_hooks() {
			if ( function_exists( 'WC' ) ) {
				WC()->frontend_includes();
				//include_once( WC()->plugin_path() . '/includes/wc-template-functions.php' );
			}
		}
	}

	add_action( 'elementor/ajax/register_actions', 'koganic_register_ajax_actions' );
	function koganic_register_ajax_actions( \Elementor\Core\Common\Modules\Ajax\Module $ajax_manager){
		$ajax_manager->register_ajax_action( 'posts_control_filter_autocomplete', 'posts_control_filter_autocomplete');
		$ajax_manager->register_ajax_action( 'koganic_control_value_titles', 'koganic_control_value_titles');
	}
	function posts_control_filter_autocomplete(array $data){
		if ( empty( $data['autocomplete'] ) || empty( $data['q'] )) {
			return new \WP_Error('autocomplete', 'Empty or incomplete data' );
		}
		$autocomplete = $data['autocomplete'];
		$query_args = [
			'post_type' => 'any',
			'posts_per_page' => -1,
			's' => $data['q'],
		];
		if ( !empty( $autocomplete['query'] ) ){
			$query_args = wp_parse_args( $autocomplete['query'] , $query_args);
		}
		$results = [];
		$query = new \WP_Query( $query_args );
		foreach ( $query->posts as $post ) {
			$results[] = [
				'id' => $post->ID,
				'text' => $post->post_title,
			];
		}
		return [
			'results' => $results,
		];
	}
	function koganic_control_value_titles($request){
		if ( empty( $request['get_titles'] ) || empty( $request['id'] )) {
			return new \WP_Error('autocomplete', 'Empty or incomplete data' );
		}
		$get_titles = $request['get_titles'];
		if ( empty( $get_titles['query'] ) ) {
			$get_titles['query'] = [];
		}
		$query_args = [
			'post_type' => 'any',
			'posts_per_page' => -1,
			'post__in' => (array) $request['id'],
		];
		$query_args = wp_parse_args( $get_titles['query'] , $query_args);

		$results = [];
		$query = new \WP_Query( $query_args );
		foreach ( $query->posts as $post ) {
			$results[$post->ID] = $post->post_title;
		};

		return $results;
	}
function koganic_add_custom_icons_tab( $tabs = array() ) {

		// Append new icons
		$new_icons = array(
			'user',
			'people',
			'user-female',
			'user-follow',
			'user-following',
			'user-unfollow',
			'login',
			'logout',
			'emotsmile',
			'phone',
			'call-end',
			'call-in',
			'call-out',
			'map',
			'location-pin',
			'direction',
			'directions',
			'compass',
			'layers',
			'menu',
			'list',
			'options-vertical',
			'options',
			'arrow-down',
			'arrow-left',
			'arrow-right',
			'arrow-up',
			'arrow-up-circle',
			'arrow-left-circle',
			'arrow-right-circle',
			'arrow-down-circle',
			'check',
			'clock',
			'plus',
			'minus',
			'close',
			'event',
			'exclamation',
			'organization',
			'trophy',
			'screen-smartphone',
			'screen-desktop',
			'plane',
			'notebook',
			'mustache',
			'mouse',
			'magnet',
			'energy',
			'disc',
			'cursor',
			'cursor-move',
			'crop',
			'chemistry',
			'speedometer',
			'shield',
			'screen-tablet',
			'magic-wand',
			'hourglass',
			'graduation',
			'ghost',
			'game-controller',
			'fire',
			'eyeglass',
			'envelope-open',
			'envelope-letter',
			'bell',
			'badge',
			'anchor',
			'wallet',
			'vector',
			'speech',
			'puzzle',
			'printer',
			'present',
			'playlist',
			'pin',
			'picture',
			'handbag',
			'globe-alt',
			'globe',
			'folder-alt',
			'folder',
			'film',
			'feed',
			'drop',
			'drawer',
			'docs',
			'doc',
			'diamond',
			'cup',
			'calculator',
			'bubbles',
			'briefcase',
			'book-open',
			'basket-loaded',
			'basket',
			'bag',
			'action-undo',
			'action-redo',
			'wrench',
			'umbrella',
			'trash',
			'tag',
			'support',
			'frame',
			'size-fullscreen',
			'size-actual',
			'shuffle',
			'share-alt',
			'share',
			'rocket',
			'question',
			'pie-chart',
			'pencil',
			'note',
			'loop',
			'home',
			'grid',
			'graph',
			'microphone',
			'music-tone-alt',
			'music-tone',
			'earphones-alt',
			'earphones',
			'equalizer',
			'like',
			'dislike',
			'control-start',
			'control-rewind',
			'control-play',
			'control-pause',
			'control-forward',
			'control-end',
			'volume-1',
			'volume-2',
			'volume-off',
			'calendar',
			'bulb',
			'chart',
			'ban',
			'bubble',
			'camrecorder',
			'camera',
			'cloud-download',
			'cloud-upload',
			'envelope',
			'eye',
			'flag',
			'heart',
			'info',
			'key',
			'link',
			'lock',
			'lock-open',
			'magnifier',
			'magnifier-add',
			'magnifier-remove',
			'paper-clip',
			'paper-plane',
			'power',
			'refresh',
			'reload',
			'settings',
			'star',
			'symbol-female',
			'symbol-male',
			'target',
			'credit-card',
			'paypal',
			'social-tumblr',
			'social-twitter',
			'social-facebook',
			'social-instagram',
			'social-linkedin',
			'social-pinterest',
			'social-github',
			'social-google',
			'social-reddit',
			'social-skype',
			'social-dribbble',
			'social-behance',
			'social-foursqare',
			'social-soundcloud',
			'social-spotify',
			'social-stumbleupon',
			'social-youtube',
			'social-dropbox',
			'social-vkontakte',
			'social-steam'
		);

		$tabs['simple-line-icons'] = array(
			'name'          => 'simple-line-icons',
			'label'         => esc_html__( 'Simple Line Icons', 'koganic' ),
			'labelIcon'     => 'fas fa-user',
			'prefix'        => 'icon-',
			'displayPrefix' => 'icons',
			'url'           => 'https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.5.5/css/simple-line-icons.min.css',
			'icons'         => $new_icons,
			'ver'           => '2.5.5',
		);

		return $tabs;
	}

	add_filter( 'elementor/icons_manager/additional_tabs', 'koganic_add_custom_icons_tab' );	
}

/**
 * functions
 *
 */
require KOGANIC_ADDONS_PATH . 'functions.php';

/**
 * Widgets Core
 *
 */
require KOGANIC_ADDONS_PATH . 'classes/class-koganic-widgets.php';
add_action( 'widgets_init',  'koganic_framework_widget_init' );

/*
* [ Shortcode Visual Composer ] - - - - - - - - - - - - - - - - - - - -
*/
foreach ( glob( KOGANIC_ADDONS_PATH . 'inc/shortcodes/*.php' ) as $filename ) {
	include_once $filename;
}

/*
* [ Mega Menu. ] - - - - - - - - - - - - - - - - - - - -
*/
require_once KOGANIC_ADDONS_PATH . 'inc/megamenu/megamenu.php';

require_once( KOGANIC_ADDONS_PATH . 'inc/portfolio/init.php' );

function getCSSAnimation( $css_animation ) {
	$output = '';
	if ( '' !== $css_animation && 'none' !== $css_animation ) {
		wp_enqueue_script( 'waypoints' );
		wp_enqueue_style( 'animate-css' );
		$output = ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
	}

	return $output;
}

//Actions
add_action( 'admin_enqueue_scripts', 'koganic_admin_enqueue_styles_scripts' );

function koganic_admin_enqueue_styles_scripts() {
	global $pagenow;
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	if ( 'widgets.php' == $pagenow ) {
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'koganic_addons_admin', KOGANIC_ADDONS_URL . 'assets/css/admin.css', array(), '1.3' );

		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_script( 'koganic_admin', KOGANIC_ADDONS_URL . 'assets/js/admin' . $suffix . '.js', array(
			'jquery',
			'wp-color-picker'
		), '1.3', true );
	}
}
add_action('wp_enqueue_scripts', function(){
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	wp_enqueue_style( 'koganic_addons_frontend', KOGANIC_ADDONS_URL . 'assets/css/frontend.css', array(), '1.3' );
});