(function ($) {
    var koganicItemView = elementor.modules.controls.Select2.extend({

        cache: null,

        isTitlesReceived: false,

        getSelect2Placeholder: function getSelect2Placeholder() {
            return {
                id: '',
                text: 'Select an option '
            };
        },


        getQueryData: function getQueryData() {
            // Use a clone to keep model data unchanged:
            var autocomplete = elementorCommon.helpers.cloneObject(this.model.get('autocomplete'));

            if (_.isEmpty(autocomplete.query)) {
                autocomplete.query = {};
            }

            return {
                autocomplete: autocomplete
            };
        },

        getSelect2DefaultOptions: function getSelect2DefaultOptions() {
            var self = this;
            return jQuery.extend(elementor.modules.controls.Select2.prototype.getSelect2DefaultOptions.apply(this, arguments), {
                ajax: {
                    transport: function transport(params, success, failure) {
                        var bcFormat = !_.isEmpty(self.model.get('filter_type'));

                        var data = {},
                            action = 'posts_control_filter_autocomplete';

                        data = self.getQueryData();

                        data.q = params.data.q;
                        console.log(data);
                        return elementorCommon.ajax.addRequest(action, {
                            data: data,
                            success: success,
                            error: failure
                        });
                    },
                    data: function data(params) {
                        return {
                            q: params.term,
                            page: params.page
                        };
                    },
                    cache: true
                },
                minimumInputLength: 1
            });
        },

        getValueTitles: function getValueTitles() {
            var self = this,
                data = {},
                bcFormat = !_.isEmpty(this.model.get('filter_type'));

            var ids = this.getControlValue(),
                action = 'koganic_control_value_titles'
                filterType = 'post';

            data.get_titles = self.getQueryData().autocomplete;
            data.unique_id = '' + self.cid + filterType;

            if (!ids || !filterType) {
                return;
            }

            if (!_.isArray(ids)) {
                ids = [ids];
            }

            elementorCommon.ajax.loadObjects({
                action: action,
                ids: ids,
                data: data,
                before: function before() {
                    self.addControlSpinner();
                },
                success: function success(ajaxData) {
                    self.isTitlesReceived = true;

                    self.model.set('options', ajaxData);

                    self.render();
                }
            });
        },

        addControlSpinner: function addControlSpinner() {
            this.ui.select.prop('disabled', true);
            this.$el.find('.elementor-control-title').after('<span class="elementor-control-spinner">&nbsp;<i class="eicon-spinner eicon-animation-spin"></i>&nbsp;</span>');
        },


        onReady: function onReady() {
            // Safari takes it's time to get the original select width
            setTimeout(elementor.modules.controls.Select2.prototype.onReady.bind(this));

           if (!this.isTitlesReceived) {
                this.getValueTitles();
           }
        },

    });

    elementor.addControlView('koganic', koganicItemView);

})(jQuery);