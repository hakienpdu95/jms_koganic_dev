(function ($) {
    "use strict";

    class WidgetHandlerCarouselClass extends elementorModules.frontend.handlers.Base {
        getDefaultSettings() {
            /*return {
                selectors: {
                    carousel: '.' + this.getWidgetType()+'-carousel-'+this.getID()
                },
            }*/
            return {
                selectors: {
                    carousel: ['.brand-carousel','.product-carousel','.product-categories-carousel','.testimonials-carousel','.instagram-carousel','.images-carousel','.blogs-carousel'].map(obj =>{
                        return obj + '-' +this.getID();
                    }).join(', '),
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );
            return {
                $carousel: this.$element.find( selectors.carousel ),
            };
        }

        bindEvents() {
            const _options = $.fn.getOptions(this.elements.$carousel.data('carousel'));
            if (_options){
                var _itemDesktop   	   = _options.itemDesktop,
                    _itemSmallDesktop  = _options.itemSmallDesktop,
                    _itemTablet        = _options.itemTablet,
                    _itemMobile        = _options.itemMobile,
                    _itemSmallMobile   = _options.itemSmallMobile,
                    _margin            = _options.margin,
                    _navigation        = _options.navigation,
                    _pagination        = _options.pagination,
                    _autoplay          = _options.autoplay,
                    _loop        	   = _options.loop,
                    _slider_opacity    = _options.slider_opacity,
                    _opts              = {};
                var [marginSmallMobile, marginMobile, marginTablet,marginSmallDesktop] = Array(4).fill(0);
                switch (_margin) {
                    case 0:
                        marginSmallMobile = marginMobile= marginTablet = marginSmallDesktop = 0;
                        break;
                    case 10:
                        marginSmallMobile = marginMobile= marginTablet = marginSmallDesktop = 10;
                        break;
                    case 20:
                        marginSmallMobile = marginMobile= marginTablet = marginSmallDesktop = 20;
                        break;
                    case 30:
                        marginSmallMobile = marginMobile= marginTablet = marginSmallDesktop = 30;
                        break;
                    case 40:
                        marginSmallMobile = marginMobile= marginTablet = marginSmallDesktop = 20;
                        break;
                    case 50:
                        marginSmallMobile = marginMobile= marginTablet = marginSmallDesktop = 25;
                        break;
                    case 60:
                        marginSmallMobile = 10;
                        marginMobile = 10;
                        marginTablet = 20;
                        marginSmallDesktop = 30;
                        break;
                    case 70:
                        marginSmallMobile = 10;
                        marginMobile = 10;
                        marginTablet = 20;
                        marginSmallDesktop = 30;
                        break;                        
                    default:
                }
                _opts = {
                    margin: _margin,
                    dots: _pagination,
                    nav: _navigation,
                    autoplay: _autoplay,
                    loop: _loop,
                    responsive : {
                        320 : {
                            items: _itemSmallMobile,
                            margin: marginSmallMobile
                        },
                        445 : {
                            items: _itemMobile,
                            margin: marginMobile
                        },
                        768 : {
                            items: _itemTablet,
                            margin: marginTablet
                        },
                        991 : {
                            items: _itemSmallDesktop,
                            margin: marginSmallDesktop
                        },
                        1199 : {
                            items: parseInt(_itemSmallDesktop),
                            margin: marginSmallDesktop
                        },
                        1300 : {
                            items: parseInt(_itemDesktop),
                        }
                    },
                };
            }
            if(_slider_opacity){
                var self = this.elements.$carousel;
                self.on( 'initialized.owl.carousel', (e) => {
                    var total = self.find('.owl-stage .owl-item.active').length;
                    self.find('.owl-stage .owl-item.active').each(function(index){
                        if ((index !== 0) && (index !== total - 1))  {
                            $(this).addClass('centerActiveItem');
                        }
                    });
                } );
                self.on('translate.owl.carousel', (e) => {
                    self.find('.owl-stage .owl-item').removeClass('centerActiveItem');
                });

                self.on('translated.owl.carousel', (e) => {
                    var total = self.find('.owl-stage .owl-item.active').length;;
                    self.find('.owl-stage .owl-item.active').each(function(index){
                        if ((index !== 0) && (index !== total - 1))  {
                            $(this).addClass('centerActiveItem');
                        }
                    });
                });
            }
            this.elements.$carousel.owlCarousel(_opts);

            if(this.getWidgetType() == 'blog') {
                var imgHeight = $('.blogs-carousel-'+this.getID() + ' .blog-post-loop').height() - 68;
            } else {
                var imgHeight = this.elements.$carousel.find(".product-box .product-thumb").height();    
            } 

            var posTop = imgHeight/2;
                posTop += 10;
            this.elements.$carousel.find(".owl-nav [class*='owl-']").css('top',posTop + "px");
        }

    }

    class WidgetHandlerMapClass extends elementorModules.frontend.handlers.Base {
        getFieldValue( option, raw = false ) {
            var modelCID = this.getModelCID();
            if ( modelCID ) {
                var settings = elementorFrontend.config.elements.data[ modelCID ];
                if ( settings ) {
                    return settings.get( option );
                }
            }
            return this.getElementSettings( option );
        }

        getDefaultSettings() {
            return {
                selectors: {
                    googleMap: '.google-map-'+this.getID(),
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );
            return {
                $map: this.$element.find( selectors.googleMap ),
            };
        }

        IsJsonString(str) {
            try {
                JSON.parse(str);
            } catch (e) {
                return false;
            }
            return true;
        }
        bindEvents() {
            if (typeof google === 'object' && typeof google.maps === 'object' && this.elements.$map.length) {
                var lat = this.getFieldValue('lat'),
                    lon = this.getFieldValue('lon'),
                    zoom = this.getFieldValue('zoom'),
                    scroll = this.getFieldValue('scroll'),
                    style  = this.getFieldValue('style_json');
                style =  this.IsJsonString(style) ?  JSON.parse(style) : {};
                if(lat && lon){
                    new Maplace({
                        locations: [
                            {
                                lat: lat,
                                lon: lon,
                                icon: this.getFieldValue('google_icon') ,
                                animation: google.maps.Animation.DROP
                            }
                        ],
                        controls_on_map: false,
                        map_div: this.elements.$map.selector,
                        start: 1,
                        map_options: {
                            zoom: zoom.size,
                            scrollwheel: scroll === 'yes' ? true : false ,
                        },
                        styles: [style]
                    }).Load();
                }
            }
        }
    }


    class WidgetHandlerTabClass extends elementorModules.frontend.handlers.Base{
        getDefaultSettings() {
            return {
                selectors: {
                    wrap: '.jmsproducttabs-elements',
                    tab: '.jms-tabs-title li',
                    filter: '.koganic-apf:not(.koganic-apf-by-price) label',
                    price: '.koganic-apf-by-price label',
                    inner: '.product-tab-content',
                    search: '.koganic-search'
                },
            };
        }
        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );
            return {
                $wrap: this.$element.find( selectors.wrap ),
                $tab: this.$element.find( selectors.tab ),
                $filter: this.$element.find( selectors.filter ),
                $price: this.$element.find( selectors.price ),
                $search: this.$element.find( selectors.search ),
                cache : [],
                search_timeout: undefined,
                search_string: '',
                search_previous_string: '',
            };
        }
        bindEvents() {
            var $inner = this.elements.$wrap.find('.product-tab-content');
            if( $inner.find('.owl-carousel').length < 1 ) {
                this.elements.cache[0] = {html: $inner.html()};
                this.elements.cache.search = {html: $inner.html()};
            }
            this.elements.$tab.on( 'click', this.initProductTabs.bind( this ) );
            this.elements.$wrap.on( 'click', '.loadmore_product_btn a' ,this.loadMoreProduct.bind( this )  );
            this.elements.$search.on( 'keyup', this.searchProduct.bind( this ) );
            this.elements.$filter.on( 'click', this.filterProduct.bind( this ) );
            this.elements.$price.on( 'click', this.filterProductByPrice.bind( this ) );
        }
        searchProduct(event){
            var self = this,
                $this = $(event.currentTarget),
                inner    = this.elements.$wrap.find('.koganic-products-holder'),
                loadmore = this.elements.$wrap.find('.loadmore_product_btn a');

            this.elements.search_string = jQuery.trim($this.val());

            if( this.elements.search_string.length < 2 ){
                if( this.elements.cache.search && this.elements.search_string.length === 0) {
                    console.log(self.elements.cache.search.html);
                    this.elements.$wrap.removeClass('show-loading');
                    setTimeout(function() {
                        if( self.elements.cache.search.html ) {
                            self.elements.$wrap.find('.product-tab-content').html(self.elements.cache.search.html);
                        }
                    }, 100);
                }else{
                    this.elements.$wrap.addClass('show-loading');
                }
                return;
            }
            clearTimeout(this.elements.search_timeout);

            this.elements.search_timeout = setTimeout(function(){
                if( self.elements.search_string === self.elements.search_previous_string || self.elements.search_string.length < 2 ){
                    return;
                }
                var atts = self.getDataCurrent(),
                    cache = [],
                    maxPaged = loadmore.attr('data-max-paged'),
                    paged = 1;//inner.attr('data-paged');

                self.elements.search_previous_string = self.elements.search_string;
                atts['s'] = self.elements.search_string;

                self.loadProducts( atts, paged, inner, self.elements.$wrap, cache, function(data) {
                    if( data.items ) {
                        inner.html(data.items).attr('data-paged', paged);
                    }
                    if ( data.status !== 'have-posts' ) {
                        loadmore.addClass('disabled');
                    } else {
                        loadmore.removeClass('disabled');
                    }
                });
            },500);
        }
        filterProduct(event){
            if( $(event.target).is('input') ) {
                return false;
            }
            var $this = $(event.currentTarget),
                curr_chckbx = $this.find('input[type="checkbox"]'),
                curr = curr_chckbx.closest('.koganic-woocommerce-ajax-product-filter'),
                curr_var = curr_chckbx.val();
            var field = curr.children('input[type="hidden"]:first'),
                curr_name = field.attr('name'),
                curr_val = field.val();

            var pfObj = curr.find('.koganic-apf[data-filter="'+curr_name+'"]');

            if ( !curr.hasClass('checked_multi') ) {

                if ( curr_var === '' || curr_chckbx.closest('label').hasClass('koganic_active') ) {
                    pfObj.find('.koganic_active input[type="checkbox"]').prop('checked',false).change().closest('label').removeClass('koganic_active');
                    curr.find('input[name="'+curr_name+'"]').val('');
                }else{
                    pfObj.find('.koganic_active input[type="checkbox"]').prop('checked',false).change().closest('label').removeClass('koganic_active');
                    curr.find('input[name="'+curr_name+'"]').val(curr_var);
                    pfObj.find('input[value="'+curr_var+'"][type="checkbox"]').prop('checked',true).change().closest('label').addClass('koganic_active');
                }
            }else{
                if ( curr_chckbx.val() !== '' ){
                    var curr_settings = '';
                    if ( curr_chckbx.closest('label').hasClass('koganic_active') ) {
                        curr_settings = ( curr_val.indexOf(',') > 0 ? curr_val.replace(',' + curr_var, '').replace(curr_var + ',', '') : '' );
                        curr.find('input[name="'+curr_name+'"]').val(curr_settings);
                        pfObj.find('input[value="'+curr_var+'"][type="checkbox"]').prop('checked',false).change().closest('label').removeClass('koganic_active');
                    }else{
                        curr_settings = ( curr_val === '' ? curr_var : curr_val + ',' + curr_var );
                        curr.find('input[name="'+curr_name+'"]').val(curr_settings);
                        pfObj.find('input[value="'+curr_var+'"][type="checkbox"]').prop('checked',true).change().closest('label').addClass('koganic_active');
                    }
                }else{
                    curr.find('input[name="'+curr_name+'"]').val('');
                    pfObj.find('input[type="checkbox"]').attr('checked',false).change().closest('label').removeClass('koganic_active');
                }
            }

            this.koganic_filter();
            return false;
        }
        filterProductByPrice(event){
            if( $(event.target).is('input') ) {
                return false;
            }
            var $this = $(event.currentTarget),
                curr_chckbx = $this.find('input[type="checkbox"]'),
                curr = curr_chckbx.closest('.koganic-woocommerce-ajax-product-filter-by-price'),
                curr_var = curr_chckbx.val().split('-');
            var pfObj = curr.find('.koganic-apf-by-price');
            if ( curr_var[0] === '' && curr_var[1] === '' || curr_chckbx.closest('label').hasClass('koganic_active') ) {
                pfObj.find('.koganic_active input[type="checkbox"]').prop('checked',false).closest('label').removeClass('koganic_active');
                curr.find('input[name="min_price"]').val('');
                curr.find('input[name="max_price"]').val('');
            }else{
                pfObj.find('.koganic_active input[type="checkbox"]').prop('checked',false).change().closest('label').removeClass('koganic_active');
                pfObj.find('input[value="'+curr_var[0]+'-'+curr_var[1]+'"][type="checkbox"]').prop('checked',true).change().closest('label').addClass('koganic_active');
                curr.find('input[name="min_price"]').val(curr_var[0]);
                curr.find('input[name="max_price"]').val(curr_var[1]);
            }
            this.koganic_filter();
            return false;
        }
        koganic_filter(){
            var self = this,
                inner    = this.elements.$wrap.find('.koganic-products-holder'),
                loadmore = this.elements.$wrap.find('.loadmore_product_btn a'),
                atts     = this.getDataCurrent(),
                cache    = [],
                paged    = 1;
            this.loadProducts( atts, paged, inner, this.elements.$wrap, cache, function(data) {
                if( data.items ) {
                    inner.html(data.items).attr('data-paged', paged);
                }
                if ( data.status !== 'have-posts' ) {
                    loadmore.addClass('disabled');
                } else {
                    loadmore.removeClass('disabled');
                }
                self.elements.cache.search = {
                    html:self.elements.$wrap.find('.product-tab-content').html()
                };
            });
        }
        loadMoreProduct(event){
            event.preventDefault();
            var $this = $(event.currentTarget),
                inner = this.elements.$wrap.find('.koganic-products-holder'),
                cache = [];
            if( $this.hasClass('disabled') ) return;

            var atts     = inner.data('atts'),
                maxPaged = $this.attr('data-max-paged'),
                paged    = inner.attr('data-paged');
                paged++;

            this.loadProducts( atts, paged, inner, this.elements.$wrap, cache, function(data) {
                if( data.items ) {
                    inner.append(data.items).attr('data-paged', paged);
                }
                if ( paged >= maxPaged  ) {
                    $this.addClass('disabled');
                } else {
                    $this.removeClass('disabled');
                }
            });
        }
        initProductTabs(event){
            event.preventDefault();
            var self = this,
                $this = $(event.currentTarget),
                atts = $this.data('atts'),
                index = $this.index();

            this.loadTab(atts, index,this.elements.$wrap.find('.product-tab-content'), $this, this.elements.$wrap, this.elements.cache, function(data) {
                if( data.html ) {
                    self.elements.$wrap.find('.product-tab-content').html(data.html);
                }
            });
        }
        loadProducts(atts, paged, inner, wrap, cache, callback){
            var self = this;
            if( cache[paged] ) {
                wrap.removeClass('show-loading');
                setTimeout(function() {
                    callback(cache[paged]);
                }, 100);
                return;
            } else {
                wrap.addClass('show-loading');
            }

            $.ajax({
                url: koganic_settings.ajaxurl,
                data: {
                    atts: atts,
                    paged: paged,
                    action: 'koganic_get_product_shortcode',
                },
                dataType: 'json',
                method: 'POST',
                beforeSend: function() {
                    if(!wrap.find('.filter-toggle').hasClass('collapsed')){
                        wrap.find('.filter-toggle').trigger('click');
                    }
                },
                success: function(data) {
                    cache[paged] = data;
                    callback( data );
                },
                error: function(data) {
                    console.log('ajax error');
                },
                complete: function() {
                    wrap.removeClass('show-loading');
                    tooltipProduct();
                },
            });
        }
        loadTab(atts, index, inner, button, wrap, cache, callback){
            var self = this;
            button.parent().find('.active').removeClass('active');
            button.addClass('active');

            if( cache[index] ) {
                setTimeout(function() {
                    wrap.removeClass('show-loading');
                    callback(cache[index]);
                }, 300);
                return;
            } else {
                wrap.addClass('show-loading');
            }

            $.ajax({
                url: koganic_settings.ajaxurl,
                data: {
                    atts: atts,
                    action: 'koganic_get_products_tab',
                },
                dataType: 'json',
                method: 'POST',
                success: function(data) {
                    cache[index] = data;
                    callback(data);
                },
                error: function(data) {
                    console.log('Ajax error');
                },
                complete: function() {
                    wrap.find('.koganic-products-loader').remove();
                    wrap.removeClass('show-loading');
                    tooltipProduct();

                    self.elements.cache['search'] = {
                        html:self.elements.$wrap.find('.product-tab-content').html()
                    };

                },
            });
        }
        getDataCurrent(){
            var data = {};
            if(this.elements.$wrap.length){
                var curr_data = this.elements.$wrap.find('.koganic-products-holder');
                if(curr_data.length){
                    data = $.fn.getOptions( curr_data.data('atts'));
                }
                let data_filter  = {};
                this.elements.$wrap.find(':input[type="hidden"]').each(function(e){
                    if($(this).val() !== '' ){
                        data_filter[$(this).attr('name')] = $(this).val();
                    }
                });
                data['filters'] = data_filter;
            }
            return data;
        }
        resetFilter(){
            this.elements.$wrap.find('input[type="checkbox"]').attr('checked',false).change().closest('label').removeClass('koganic_active');
        }
    }

    $( window ).on( 'elementor/frontend/init', () => {
        const addHandlerCarousel = ( $element ) => {
            elementorFrontend.elementsHandler.addHandler( WidgetHandlerCarouselClass, {
                $element,
            } );
        };
        const addHandlerMap = ( $element ) => {
            elementorFrontend.elementsHandler.addHandler( WidgetHandlerMapClass, {
                $element,
            } );
        };
        const addHandlerTabs = ( $element ) => {
            elementorFrontend.elementsHandler.addHandler( WidgetHandlerTabClass, {
                $element,
            } );
        };
        elementorFrontend.hooks.addAction( 'frontend/element_ready/brand_carousel.default', addHandlerCarousel );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/feature_categories.default', addHandlerCarousel );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/product.default', addHandlerCarousel );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/testimonials.default', addHandlerCarousel );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/instagram.default', addHandlerCarousel );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/images_carousel.default', addHandlerCarousel );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/blog.default', addHandlerCarousel );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/google_map.default', addHandlerMap );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/product_tabs.default', addHandlerTabs );
    } );

    function tooltipProduct() {
        $('.product-style-1 .quickview a, .product-style-1 .btn-wishlist a').each(function(){
            var text = $.trim($(this).text());
            var title = $.trim($(this).attr('title'));
            $(this).attr('data-toggle', 'tooltip');
            $(this).attr('data-placement', 'top');
            if(!title){
                $(this).attr('title', text);
            }
        });

        $('.product-style-2 .quickview a, .product-style-2 .btn-wishlist a').each(function(){
            var text = $.trim($(this).text());
            var title = $.trim($(this).attr('title'));
            $(this).attr('data-toggle', 'tooltip');
            $(this).attr('data-placement', 'top');
            if(!title){
                $(this).attr('title', text);
            }
        });

        $('.product-style-3 .quickview a, .product-style-3 .btn-wishlist a, .product-style-3 .addtocart-thumb a').each(function(){
            var text = $.trim($(this).text());
            var title = $.trim($(this).attr('title'));
            $(this).attr('data-toggle', 'tooltip');
            $(this).attr('data-placement', 'top');
            if(!title){
                $(this).attr('title', text);
            }
        });

        $('.product-style-4 .quickview a').each(function(){
            var text = $.trim($(this).text());
            var title = $.trim($(this).attr('title'));
            $(this).attr('data-toggle', 'tooltip');
            $(this).attr('data-placement', 'top');
            if(!title){
                $(this).attr('title', text);
            }
        });

        $('.product-style-5 .btn-wishlist a').each(function(){
            var text = $.trim($(this).text());
            var title = $.trim($(this).attr('title'));
            $(this).attr('data-toggle', 'tooltip');
            $(this).attr('data-placement', 'top');
            if(!title){
                $(this).attr('title', text);
            }
        });
        
        $('.product-style-6 .quickview a, .product-style-6 .btn-wishlist a, .product-style-6 .addtocart-thumb').each(function(){
            var text = $.trim($(this).text());
            var title = $.trim($(this).attr('title'));
            $(this).attr('data-toggle', 'tooltip');
            $(this).attr('data-placement', 'top');
            if(!title){
                $(this).attr('title', text);
            }
        });

        $('[data-toggle="tooltip"]').tooltip({container: 'body', delay: { show: 100, hide: 0 } });
    }
    
})(jQuery);

(function($) {

    $.fn.getOptions = function(opts) {
        if (typeof(opts) == 'object') {
            return opts;
        } else if (typeof(opts) == 'string') {
            try {
                return JSON.parse(opts.replace(/'/g,'"').replace(';',''));
            } catch(e) {
                return {};
            }
        } else {
            return {};
        }
    };

})(jQuery);