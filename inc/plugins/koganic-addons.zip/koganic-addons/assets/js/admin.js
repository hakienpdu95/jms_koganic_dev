/**
 * Yanka Admin
 *
 * @version 1.3
 */
(function ($) {
    "use strict";
    $.add_new_range = function (t) {
        var range_filter = t.parents('.widget-content').find('.range-filter'),
            input_field = range_filter.find('input:last-child'),
            field_name = range_filter.data('field_name'),
            position = parseInt(input_field.data('position')) + 1,
            html = '<input type="text" placeholder="min" name="' + field_name + '[' + position + '][min]" value="" class="koganic-apf-price-filter-input widefat" data-position="' + position + '"/>' +
                '<input type="text" placeholder="max" name="' + field_name + '[' + position + '][max]" value="" class="koganic-apf-price-filter-input widefat" data-position="' + position + '"/>';

        range_filter.append(html);
    };

    $(document).on('change', '.koganic_apf_type, .koganic_apf_attributes', function (e) {
        var t = this,
            container       = $(this).parents('.widget-content').find('.koganic_apf_placeholder').html(''),
            spinner         = container.next('.spinner').show(),
            display         = $(this).parents('.widget-content').find('#koganic-apf-display'),
            attributes      = $(this).parents('.widget-content').find('.koganic-apf-attribute-list'),
            tag_list        = $(this).parents('.widget-content').find('.koganic-apf-widget-tag-list');

        var data = {
            action   : 'koganic_apf_select_type',
            id       : $('input[name=widget_id]', $(t).parents('.widget-content')).val(),
            name     : $('input[name=widget_name]', $(t).parents('.widget-content')).val(),
            attribute: $('.koganic_apf_attributes', $(t).parents('.widget-content')).val(),
            value    : $('.koganic_apf_type', $(t).parents('.widget-content')).val()
        };

        /* Hierarchical hide/show */
        if (data.value === 'list' || data.value === 'select' || data.value === 'tags' ) {
            display.show();
        } else if (data.value === 'label' || data.value === 'color' || data.value === 'sort') {
            display.hide();
        }

        if( data.value === 'tags' || data.value === 'categories' || data.value === 'sort'){
            attributes.hide();
        } else {
            attributes.show();
        }

        $.post(ajaxurl, data, function (response) {
            spinner.hide();
            container.html(response.content);
        }, 'json');

    });

    $(document).ajaxComplete(function (event, request, options) {
        if (
            request &&
            4 === request.readyState &&
            200 === request.status
        ) {
            $(document).trigger('koganic_colorpicker');
        }
    });

    $(document).on('widget-updated', function(event, widget){
        $(document).trigger('koganic_colorpicker');
        $('.koganic_apf_type, .koganic_apf_attributes').trigger('change');
    });

    //color-picker
    $(document).on('koganic_colorpicker',function () {
        $('.koganic-apf-colorpicker').each(function () {
            $(this).wpColorPicker();
        });
    }).trigger('yith_colorpicker');

    $(function () {
        $(document).trigger('koganic_colorpicker');
        $('.koganic_apf_type, .koganic_apf_attributes').trigger('change');
    });
})(jQuery);