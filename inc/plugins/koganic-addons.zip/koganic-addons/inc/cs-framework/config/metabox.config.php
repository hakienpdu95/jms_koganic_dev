<?php

if ( ! defined( 'ABSPATH' ) ) {
    die;
} // Cannot access pages directly.

$options = array();

if ( isset( $_GET['post'] ) && $_GET['post'] == get_option( 'page_for_posts' ) ) return;

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
$footer_layouts = array();
$footer_layouts = array(
    '' => esc_html__( '- Select footer -', 'koganic-addons' ),
);

$jscomposer_templates_args = array(
    'orderby'          => 'title',
    'order'            => 'ASC',
    'post_type'        => 'footerlayout',
    'post_status'      => 'publish',
    'posts_per_page'   => 30,
);
$jscomposer_templates = get_posts( $jscomposer_templates_args );

if(count($jscomposer_templates) > 0) {
    foreach($jscomposer_templates as $jscomposer_template){
        $footer_layouts[$jscomposer_template->post_title] = $jscomposer_template->post_title;
    }
    $footer_default = $jscomposer_templates[0]->post_title;
}

$options[]    = array(
    'id'        => '_custom_page_options',
    'title'     => esc_html__('Page Options', 'koganic-addons'),
    'post_type' => 'page',
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 's1',
            'fields' => array(

                array(
                    'id'       => 'header-logo-page',
                    'type'     => 'image',
                    'title'    => esc_html__('Logo', 'koganic-addons'),
                    'default' => false
                ),
                
                array(
                    'id'    => 'page-width',
                    'type'  => 'select',
                    'title' => esc_html__('Page width', 'koganic-addons'),
                    'options'  => array(
                        'inherit' => esc_html__( 'Inherit', 'koganic-addons' ),
                        'fullwidth' => esc_html__( 'Fullwidth', 'koganic-addons' ),
                        'boxed'   => esc_html__( 'Boxed', 'koganic-addons' ),
                    ),
                    'default'  => 'inherit',
                ),
                array(
                    'id'      => 'background-body',
                    'type'    => 'switcher',
                    'title'   => esc_html__( 'Body background', 'koganic-addons' ),
                    'default' => false
                ),
                array(
                    'id'      => 'body-bg',
                    'type'    => 'image',
                    'title'   => esc_html__( 'Body background image', 'koganic-addons' ),
                    'dependency'   => array( 'background-body', '==', 'true' ),
                ),
                array(
                    'id'      => 'body-bg-color',
                    'type'    => 'color_picker',
                    'title'   => esc_html__( 'Body background color', 'koganic-addons' ),
                    'dependency'   => array( 'background-body', '==', 'true' ),
                ),
                array(
					'id'      => 'pagehead',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable page title', 'koganic-addons' ),
					'default' => false
				),
                array(
                    'id'      => 'page-title',
                    'type'    => 'text',
                    'title'   => esc_html__( 'Page Title', 'koganic-addons' ),
                    'default' => '',
                    'dependency'   => array( 'pagehead', '==', 'true' ),
                ),
                array(
                    'id'      => 'pagehead-bg',
                    'type'    => 'image',
                    'title'   => esc_html__( 'Page heading background image', 'koganic-addons' ),
                    'dependency'   => array( 'pagehead', '==', 'true' ),
                ),
                array(
                    'id'      => 'pagehead-bg-color',
                    'type'    => 'color_picker',
                    'title'   => esc_html__( 'Page heading background color', 'koganic-addons' ),
                    'dependency'   => array( 'pagehead', '==', 'true' ),
                ),
                array(
					'id'      => 'breadcrumb',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable Breadcrumb', 'koganic-addons' ),
					'default' => false,
				),
                array(
                    'id'    => 'page-header',
                    'type'  => 'select',
                    'title' => esc_html__('Header Style', 'koganic-addons'),
                    'desc'  => esc_html__('Choose the header style', 'koganic-addons'),
                    'options'  => array(
                        '' => esc_html__( '- Select header -', 'koganic-addons' ),
                        '1' => esc_html__( 'Header 1', 'koganic-addons' ),
                        '2' => esc_html__( 'Header 2', 'koganic-addons' ),
                        '3' => esc_html__( 'Header 3', 'koganic-addons' ),
                        '4' => esc_html__( 'Header 4', 'koganic-addons' ),
                        '5' => esc_html__( 'Header 5', 'koganic-addons' ),
                        '7' => esc_html__( 'Header 7', 'koganic-addons' ),
                        '9' => esc_html__( 'Header 9', 'koganic-addons' ),
                        '10' => esc_html__( 'Header 10', 'koganic-addons' ),
                        '11' => esc_html__( 'Header 11', 'koganic-addons' ),
                        '12' => esc_html__( 'Header 12', 'koganic-addons' ),
                    ),
                    'default'  => '',
                ),

                array(
					'id'      => 'header-fullwidth',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Header fullwidth', 'koganic-addons' ),
					'default' => false,
				),

                array(
                    'id'       => 'page-footer',
                    'type'     => 'select',
                    'title'    => __( 'Footer Layout', 'koganic-addons' ),
                    'desc'      => esc_html__('Go to Footer Layout (admin table) to create/edit layout', 'koganic-addons'),
                    'options'   => $footer_layouts,
                    'default'   => ''
                ),
                array(
					'id'      => 'disable-footer',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Disable footer', 'koganic-addons' ),
                    'desc'    => esc_html__( 'You can disable footer for this page', 'koganic-addons' ),
					'default' => false,
				),
            ),
        ),
    ),
);

// -----------------------------------------
// Single Product Metabox Options             -
// -----------------------------------------
$options[]    = array(
    'id'        => '_custom_single_product_options',
    'title'     => esc_html__('Product Settings', 'koganic-addons'),
    'post_type' => 'product',
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 's4',
            'fields' => array(
                array(
                    'id'      => 'wc-new-label',
                    'type'    => 'text',
                    'title'   => esc_html__( 'Add text label', 'koganic-addons' ),
                    'desc'    => esc_html__( 'Example: New or Hot... to make product highlights', 'koganic-addons' ),
                    'default' => '',
                ),
                array(
                    'id'    => 'wc-single-product-style',
                    'type'  => 'image_select',
                    'title' => esc_html__('Style', 'koganic-addons'),
                    'options'  => array(
                        '1' => CS_URI . '/assets/images/product/product-style-1.jpg',
                        '2' => CS_URI . '/assets/images/product/product-style-2.jpg',
                        '3' => CS_URI . '/assets/images/product/product-style-3.jpg',
                        '4' => CS_URI . '/assets/images/product/product-style-4.jpg',
                    ),
                    'default'  => '1',
                ),
                array(
					'id'      => 'wc-thumbnail-position',
					'type'    => 'select',
					'title'   => esc_html__( 'Thumbnail Position', 'koganic-addons' ),
					'options' => array(
						'left'    => esc_html__( 'Left', 'koganic-addons' ),
						'bottom'  => esc_html__( 'Bottom', 'koganic-addons' ),
						'right'   => esc_html__( 'Right', 'koganic-addons' ),
						'outside' => esc_html__( 'Outside', 'koganic-addons' )
					),
					'default'    => 'left',
					'dependency' => array( 'wc-single-product-style_1', '==', true ),
				),
                array(
                    'id'      => 'wc-tab-layout',
                    'type'    => 'select',
                    'title'   => esc_html__( 'Tabs Layout', 'koganic-addons' ),
                    'options' => array(
                        'tabs'    => esc_html__( 'Tabs Container', 'koganic-addons' ),
                        'accordion'  => esc_html__( 'Accordion Container', 'koganic-addons' )
                    ),
                    'default'    => 'tabs',
                ),                
                array(
					'id'      => 'wc-product-gallery-style',
					'type'    => 'image_select',
					'title'   => esc_html__( 'Product Gallery Style', 'koganic-addons' ),
					'options' => array(
                        '1' => CS_URI . '/assets/images/product/product-style-2.jpg',
                        '2' => CS_URI . '/assets/images/product/combined-grid-1.jpg',
                        '3' => CS_URI . '/assets/images/product/combined-grid-2.jpg',
					),
					'default'    => '1',
					'dependency' => array( 'wc-single-product-style_2', '==', true ),
				),               
                array(
					'id'      => 'wc-enable-background',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable Background?', 'koganic-addons' ),
					'default'    => false,
				),
                array(
					'id'      => 'wc-single-background-color',
					'type'    => 'color_picker',
					'title'   => esc_html__( 'Background Color', 'koganic-addons' ),
					'default'    => '',
					'dependency' => array( 'wc-enable-background', '==', true ),
				),
                array(
                    'id'      => 'wc-product-video-url',
					'type'    => 'text',
                    'title'   => esc_html__( 'Video URL', 'koganic-addons' ),
					'default'    => '',
				),
            ),
        ),
    ),
);

$options[] = array(
	'id'        => '_custom_wc_thumb_options',
	'title'     => esc_html__( 'Thumbnail Size', 'koganic-addons'),
	'post_type' => 'product',
	'context'   => 'side',
	'priority'  => 'default',
	'sections'  => array(
		array(
			'name'  => 's3',
			'fields' => array(
				array(
					'id'      => 'wc-thumbnail-size',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable Large Thumbnail', 'koganic-addons' ),
					'default' => false
				),
			),
		),
	),
);




CSFramework_Metabox::instance( $options );
