<?php
// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Koganic_Control' ) ) {
	class Koganic_Control extends \Elementor\Control_Select2  {

		public function get_type() {
			return 'koganic';
		}

		public function enqueue() {
			// Scripts
			wp_register_script( 'koganic-control', KOGANIC_ADDONS_URL . 'assets/js/elementor-addons-control.js', [ 'jquery'], '1.0.0' ,true);
			wp_enqueue_script( 'koganic-control' );
		}

		protected function get_default_settings() {
			return array_merge(
				parent::get_default_settings(), [
					'autocomplete' => '',
				]
			);
		}

	}
}
?>