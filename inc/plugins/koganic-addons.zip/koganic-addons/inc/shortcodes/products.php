<?php

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'koganic_shortcode_products' ) ) {
	function koganic_shortcode_products( $atts, $content = null ) {
		global $woocommerce_loop, $product;
		$parsed_atts = shortcode_atts( koganic_get_default_product_shortcode_atts(), $atts );
		extract( $parsed_atts );

		$doing_ajax = (defined( 'DOING_AJAX' ) && DOING_AJAX && $not_ajax != 'yes');

		$parsed_atts['not_ajax'] = 'no';

		$encoded_atts = json_encode( $parsed_atts );

		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		if( $ajax_page > 1 ) $paged = $ajax_page;

		$woocommerce_loop['is_shortcode']   = true;
		$woocommerce_loop['product_design'] = $product_design;
		$woocommerce_loop['style_product'] = $style_product;
		$woocommerce_loop['style_product_list'] = $style_product_list;
		$woocommerce_loop['style_thumb']  = $style_thumb;
		$woocommerce_loop['countdown']      = $countdown;
		$woocommerce_loop['varition_woocommerce']      = $varition_woocommerce;
		$woocommerce_loop['style_navigation']   = $style_navigation;
		$woocommerce_loop['slider_opacity']   = $slider_opacity;
		$woocommerce_loop['number_of_rows']   = $number_of_rows;
		$woocommerce_loop['type_product']   = $type_product;

        // -------------------
        $slider_id = rand(10, 9999);

		$classes = array('jmsproduct-elements');

		if ( isset($product_design) && $product_design == 'nocarousel' ) {
			$classes[] = 'product-design-grid';
		}

        if ( isset($slider_opacity) && $slider_opacity == 'yes' ) {
            $classes[] = 'slider-opacity';
        }
        
        if ( '' !== $css_animation ) {
			$classes[] = getCSSAnimation( $css_animation );
		}
 		
        if ( isset($style_navigation) && $style_navigation == 'icon_arrow' ) {
            $classes[] = 'icon_arrow';
        }elseif( isset($style_navigation) && $style_navigation == 'icon_box_arrow' ) {
            $classes[] = 'icon_box_arrow';
        }

        if ( '' !== $css_animation ) {
			$classes[] = getCSSAnimation( $css_animation );
		}

		if ( isset($el_class) && $el_class != '' ) {
			$classes[] = esc_attr($el_class);
		}

		/*if ( ! empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }*/

		// Holder class
		$class_wrapper = array();

		if ( isset($columns) && $columns != '' ) {
			$class_wrapper[] = 'layout-columns-' . $columns;
		}

		if ( isset($product_spacing) && $product_spacing != '' ) {
			$class_wrapper[] = 'layout-spacing-' . $product_spacing;
		}

        // Global Query
        $args = array(
			'post_type'            => 'product',
            'post_status' 		   => 'publish',
			'ignore_sticky_posts'  => 1,
			'paged'                => $paged,
			'orderby'              => $orderby,
			'order'                => $order,
			'posts_per_page'       => intval($total_items),
			'meta_query'           => WC()->query->get_meta_query(),
			'tax_query'            => WC()->query->get_tax_query()
		);

        // all products
        if( isset($product_type) && $product_type == 'ids' ) {
            if ( $sku != '' ) {
                $args['meta_query'][] = array(
                    'key'     => '_sku',
                    'value'   => array_map( 'trim', explode( ',', $sku ) ),
                    'compare' => 'IN'
                );
            }
            if ( $ids != '' ) {
                $args['post__in'] = array_map( 'trim', explode( ' ', $ids ) );
            }
        }


        //recent products
        if( isset($product_type) && $product_type == 'recent' ) {
			$args['orderby'] = 'date';
			$args['order']   = 'desc';
        }

        //featured products
		if( isset($product_type) && $product_type == 'featured' ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'name',
				'terms'    => 'featured',
				'operator' => 'IN',
			);
		}

		//best selling
		if( isset($product_type) && $product_type == 'selling' ) {
			$args['orderby'] = 'meta_value_num';
			$args['meta_key'] = 'total_sales';
		}

		//sale products
		if( isset($product_type) && $product_type == 'sale' ) {
			$args['post__in'] = array_merge( array( 0 ), wc_get_product_ids_on_sale() );
		}

        //product by categories
        if( isset($product_type) && $product_type == 'cat' ) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field'    => 'id',
                    'terms'    => $cat_id,
                ),
            );
        }
		if(!empty($s)){
            $args['s']  = $s;
        }
        if(isset($filters) && is_array($filters)){
            foreach ($filters as $key => $filter){
	            if ( 0 === strpos( $key, 'pa_' ) ) {
		            $args['tax_query'][] = array(
			            'taxonomy' => $key,
			            'field'    => 'slug',
			            'terms'    => explode(",", $filter),
			            'operator' => 'IN',
		            );
                }

            }
            if(!empty($filters['orderby'])){
                switch ($filters['orderby']){
                    case 'price':
	                    $args['orderby']  = 'meta_value_num';
	                    $args['meta_key'] = '_price';
	                    $args['order']    = 'asc';
                    break;
                    case 'price-desc':
	                    $args['orderby']  = 'meta_value_num';
	                    $args['meta_key'] = '_price';
	                    $args['order']    = 'desc';
                    break;
	                case 'rating':
		                $args['orderby']  = 'meta_value_num';
		                $args['meta_key'] = '_wc_average_rating';
		                $args['order']    = 'desc';
	                break;
	                case 'popularity':
		                $args['orderby']  = 'meta_value_num';
		                $args['meta_key'] = 'total_sales';
		                $args['order']    = 'desc';
	                break;
	                case 'date':
		                $args['orderby'] = 'date';
		                $args['order']   = 'desc';
	                break;
                }
            }
	        if(!empty($filters['min_price']) || !empty($filters['max_price'])){
	            $min = !empty($filters['min_price']) ? floatval($filters['min_price']) : 0;
	            $max = !empty($filters['max_price']) ? floatval($filters['max_price']) : PHP_INT_MAX;
		        $args['meta_query'][] = array(
			        'key' => '_price',
			        'value' => array($min , $max),
                    'type' => 'NUMERIC',
			        'compare' => 'BETWEEN'
                );
            }
        }


        $owl_atts = koganic_get_owl_attributes( $parsed_atts );

        $products = new WP_Query( $args );

        ob_start();
		/*echo "<pre>";
		print_r($parsed_atts);
		print_r($args);
		echo "</pre>";*/
        if( ! $doing_ajax ) echo '<div class="'. esc_attr( implode( ' ', $classes ) ) .'">';

			if ( isset( $product_design ) && $product_design == 'carousel' && !$doing_ajax ) {
				koganic_product_carousel_js( $atts, $slider_id);
				echo '<div class="koganic-products-holder spacing-carousel-'. intval( $items_margin) .' product-carousel-'. intval( $slider_id ) .' owl-carousel owl-theme" '. $owl_atts .'>';
			}

			if ( isset( $product_design ) && $product_design == 'nocarousel' && !$doing_ajax ) {
				echo '<div class="products row koganic-products-holder layout-columns-mobile-2 product-design-grid masonry-container '. implode( ' ', $class_wrapper ) .'" data-paged="1" data-atts="'. esc_attr( $encoded_atts ) .'">';
			}

			if ( isset( $product_design ) && $product_design == 'carousel' ) {
				if ( $products->have_posts() ) :
				$row = 1;
				while ( $products->have_posts() ) : $products->the_post();
					if($row == 1) :
						if( ! $doing_ajax ) echo '<div class="item-wrap">';
					endif;
				        wc_get_template_part( 'content', 'product' );
					if( $row == (int) $number_of_rows || $products->current_post+1 == $products->post_count) { $row=0; 
						if( ! $doing_ajax ) echo '</div>';
					} $row++;
				 endwhile;
				endif;
			}
			if ( isset( $product_design ) && $product_design == 'nocarousel' ) {
				if ( $products->have_posts() ) :
					while ( $products->have_posts() ) :
						$products->the_post();
						wc_get_template_part( 'content', 'product' );
					endwhile;
				endif;
			}
			wp_reset_postdata();

			if( ! $doing_ajax ) echo '</div>';

			if( ! $doing_ajax ) echo '<div class="clearfix"></div>';
			?>
			<?php if ( $products->max_num_pages > 1 && ($loadmore_product == 'yes') && ! $doing_ajax ) : ?>
					<div class="loadmore_product_btn">
						<a href="#" data-max-paged="<?php echo intval($products->max_num_pages); ?>"><?php esc_html_e('Load more products', 'koganic'); ?><span><?php esc_html_e('Loading...', 'koganic'); ?></span></a>
					</div>
			<?php endif; ?>

		<?php if( ! $doing_ajax ) echo '</div>'; ?>

		<?php

		$output = ob_get_clean();

	    if( $doing_ajax ) {
	    	$output =  array(
	    		'items'  => $output,
				'status' => ( $products->max_num_pages > $paged ) ? 'have-posts' : 'no-more-posts'
	    	);
	    }

	    return $output;
	}
	add_shortcode( 'jms_products', 'koganic_shortcode_products' );
}

if( ! function_exists( 'koganic_product_carousel_js' ) ) {
	function koganic_product_carousel_js( $atts, $id) {
		extract(shortcode_atts( array(
			'items_desktop'       => '',
            'items_small_desktop' => '',
            'items_tablet'        => '',
            'items_mobile'        => '',
            'items_small_mobile'  => '',
            'navigation'          => '',
            'items_margin'        => '30',
            'pagination'          => '',
            'autoplay'            => '',
            'loop'                => '',
		), $atts ));
		$func_name = 'carousel_' . $id;
		$func_name = function() use($atts, $id, $items_margin, $items_desktop, $items_small_desktop,  $items_tablet, $items_mobile, $items_small_mobile, $pagination, $autoplay, $navigation, $loop ) {
			
			ob_start();
			?>

				jQuery( document ).ready(function( $ ) {

					<!-- addSliderOpacity -->
	                $('.slider-opacity').on('initialized.owl.carousel', function(event) {
					    var total = $(this).find('.owl-stage .owl-item.active').length;
							$(this).find('.owl-stage .owl-item.active').each(function(index){
						        if ((index !== 0) && (index !== total - 1))  {
						            $(this).addClass('centerActiveItem');
						        }
						    });
				    });
				    $('.slider-opacity').on('translate.owl.carousel', function(event) {
				    	$(this).find('.owl-stage .owl-item').removeClass('centerActiveItem');
				    });
				    $('.slider-opacity').on('translated.owl.carousel', function(event) {
				    	var total = $(this).find('.owl-stage .owl-item.active').length;;
						$(this).find('.owl-stage .owl-item.active').each(function(index){
				            if ((index !== 0) && (index !== total - 1))  {
				            $(this).addClass('centerActiveItem');
				        }
				        });
				    });

	                var owl = $(".product-carousel-<?php echo esc_js( $id ); ?>.owl-carousel");


					var options = {
	            		responsive : {
							320 : {
				        		items: <?php echo intval($items_small_mobile); ?>,
				        	},
							445 : {
				        		items: <?php echo intval($items_mobile); ?>,
				        	},
							768 : {
				        		items: <?php echo intval($items_tablet); ?>,
				        	},
						    991 : {
						        items: <?php echo intval($items_small_desktop); ?>,
						    },
						    1199 : {
						        items: <?php echo intval($items_desktop); ?>,
						    }
						},
				        margin: <?php echo esc_attr( $items_margin ); ?>,
						nav: <?php echo esc_attr(( $navigation == 'no') || ( $navigation == '')) ? 'false' : 'true'; ?>,
				        dots: <?php echo esc_attr(( $pagination == 'no') || ( $pagination == '')) ? 'false' : 'true'; ?>,
				        autoplay: <?php echo esc_attr(( $autoplay == 'no') || ( $autoplay == '')) ? 'false' : 'true'; ?>,
				        loop: <?php echo esc_attr( ($loop == 'no') || ($loop == '')) ? 'false' : 'true'; ?>,
				        smartSpeed: 250,
				        dotsSpeed: 250,
				        autoHeight : true,
	                    navText: ['<?php esc_html_e('Prev', 'koganic'); ?>','<?php esc_html_e('Next', 'koganic'); ?>']
					}

	                owl.owlCarousel(options);

				});

				jQuery( document ).ready(function( $ ) {
					var imgHeight = $(".product-carousel-<?php echo esc_js( $id ); ?>.owl-carousel .product-box .product-thumb").height();
					var posTop = imgHeight/2;
						posTop += 10;

					$(".product-carousel-<?php echo esc_js( $id ); ?>.owl-theme .owl-nav [class*='owl-']").css('top',posTop + "px");

				});
			<?php
			return ob_get_clean();
		};

		echo '<script type="text/javascript">' . $func_name() . '</script>';
	}
}

if( ! function_exists( 'koganic_get_shortcode_product_ajax' ) ) {
	function koganic_get_shortcode_product_ajax() {
		if( ! empty( $_POST['atts'] ) ) {
			$atts = $_POST['atts'];
			$paged = ( empty( $_POST['paged'] ) ) ? 2 : (int) $_POST['paged'];
			$atts['ajax_page'] = $paged;
			$data = koganic_shortcode_products( $atts );
			echo json_encode( $data );
			die();
		}
	}
	add_action( 'wp_ajax_koganic_get_product_shortcode', 'koganic_get_shortcode_product_ajax' );
	add_action( 'wp_ajax_nopriv_koganic_get_product_shortcode', 'koganic_get_shortcode_product_ajax' );
}

if( ! function_exists( 'koganic_get_default_product_shortcode_atts' ) ) {
	function koganic_get_default_product_shortcode_atts() {
		return array(
			'product_design'       => 'nocarousel',
			'product_type'         => 'all',
			'orderby'              => 'title',
			'order'                => 'ASC',
			'ids'                  => '',
			'sku'                  => '',
			'cat_id'               => '',
			'countdown'            => '',
			'varition_woocommerce' => '',
			'total_items'          => '8',
			'columns'              => '4',
			'style_thumb'          => '',
			'loadmore_product'     => 'no',
			'type_product'         => 'grid',
			'style_product'        => '',
			'style_product_list'   => '',
			'product_spacing'      => '30',
			'slider_opacity'       => '',
			'style_navigation'     => 'icon_arrow',
			'css_animation'        => '',
			'not_ajax'             => 'no',
			'el_class'             => '',
			'css'                  => '',
			'ajax_page'            => '',
			'number_of_rows'       => '1',
			'items_desktop'        => '4',
			'items_small_desktop'  => '4',
			'items_tablet'         => '3',
			'items_mobile'         => '2',
			'items_small_mobile'   => '1',
			'navigation'           => 'yes',
			'items_margin'         => '30',
			'pagination'           => 'no',
			'autoplay'             => 'no',
			'loop'                 => 'no',
			's'                    => '',
			'filters'              => '',
	    );
	}
}

if ( ! function_exists( 'koganic_get_owl_attributes' ) ) {
	function koganic_get_owl_attributes( $atts = array()) {
        unset($atts['filters']);
		foreach ( $atts as $key => $value ) {
			$output[] = 'data-' . $key . '="' . $value . '"';
		}

		return implode( ' ', $output );
	}
}