<?php
/**
* ------------------------------------------------------------------------------------------------
* HTML block shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'koganic_footer_layout_shortcode' ) ) {
	function koganic_footer_layout_shortcode($atts) {
		extract(shortcode_atts(array(
			'id' => 0
		), $atts));

		//return koganic_get_footer_layout($id);
		return '1111';
	}
	add_shortcode( 'footer_layout', 'koganic_footer_layout_shortcode' );
}
