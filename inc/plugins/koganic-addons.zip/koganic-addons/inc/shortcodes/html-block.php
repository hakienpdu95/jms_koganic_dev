<?php
/**
* ------------------------------------------------------------------------------------------------
* HTML block shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'koganic_html_block_shortcode' ) ) {
	function koganic_html_block_shortcode($atts) {
		extract(shortcode_atts(array(
			'id' => 0
		), $atts));

		// $id = '1731';
		// $content = get_post_field('post_content', $id);

  //       $content = do_shortcode($content);

		// return $content;

		//return $id; 
		return koganic_get_html_block($id);
	}
	add_shortcode( 'html_block', 'koganic_html_block_shortcode' );
}
