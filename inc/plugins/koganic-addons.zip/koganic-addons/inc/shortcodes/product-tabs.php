<?php

if ( ! function_exists( 'koganic_shortcode_product_tabs' ) ) {
	function koganic_shortcode_product_tabs($atts = array(), $content = null) {
		$output = '';

		extract( shortcode_atts( array(
			'title'         => '',
			'title_style'	=> '',
			'el_class'      => '',
			'css'           => '',
			'line_bottom'	 => 'big',
			'color'			=> '',
			'css_animation'	 => '',
			'size'			=> 'large'
		), $atts ) );

		$classes = array('jmsproducttabs-elements');

		if ( isset($title_style) && $title_style != '' ) {
			$classes[] = 'tab-design-' . esc_attr($title_style);
		}

		if ( isset($el_class) && $el_class != '' ) {
			$classes[] = esc_attr( $el_class );
		}

		if ( '' !== $css_animation ) {
			$classes[] = getCSSAnimation( $css_animation );
		}

		if ( ! empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }

        $title_class = array('addon-title');
 
        if ( isset($color) && $color != '' ) {
            $title_class[] = 'title-color-' . esc_attr($color);
        }
 
        if ( isset($size) && $size != '' ) {
            $title_class[] = 'title-size-' . esc_attr($size);
        }

         if ( isset( $line_bottom ) && $line_bottom != '' ) {
			$title_class[] = 'line-bottom-'. esc_attr($line_bottom);
		}

		// Extract tab titles
	    preg_match_all( '/jms_product_tab([^\]]+)/i', $content, $matches, PREG_OFFSET_CAPTURE );
	    $tab_titles = array();

	    if ( isset( $matches[1] ) ) {
	      	$tab_titles = $matches[1];
	    }

		$tabs_nav = '';
	    $first_tab_title = '';
	    $tabs_nav .= '<div class="tabs-navigation-wrapper"><ul class="tab-title">';
	    $i = 0;
	    foreach ( $tab_titles as $tab ) {
	    	$i++;
			$tab_atts = shortcode_parse_atts( $tab[0] );
			$encoded_atts = json_encode( $tab_atts );

			if( $i == 1 && isset( $tab_atts['title'] ) ) $first_tab_title = $tab_atts['title'];
			$class = ( $i == 1 ) ? 'active' : '';

			if ( isset( $tab_atts['title'] ) ) {
				$tabs_nav .= '<li class="'. esc_attr( $class ) .'" data-atts="'. esc_attr( $encoded_atts ) .'"><span class="tab-label">' . $tab_atts['title'] . '</span></li>';
			}
	    }

	    $tabs_nav .= '</ul></div>';

        ob_start(); ?>

        <div class="<?php echo esc_attr( implode(' ', $classes) ); ?>">
			<div class="jms-tabs-title<?php if ( isset($title) && $title == '' ) echo ' no-tabs-name'; ?>">
				<div class="koganic-tabs-header">
					<?php if ( isset($title) && $title != '' ): ?>
						<div class="<?php echo esc_attr( implode(' ', $title_class) ); ?>">
                            <h3 class="title"><?php echo esc_html($title); ?></h3>
                        </div>
					<?php endif; ?>
					<?php echo ($tabs_nav); ?>
				</div>
			</div>
			<div class="koganic-products-tab-loader loading"></div>
			<?php
				if ( isset( $tab_titles[0][0] ) ) {
					$first_tab_atts = shortcode_parse_atts( $tab_titles[0][0] );
					echo koganic_shortcode_product_tab( $first_tab_atts );
				}
			?>
        </div>

        <?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
	add_shortcode( 'jms_product_tabs', 'koganic_shortcode_product_tabs' );
}

// koganic_shortcode_product_tab
if ( ! function_exists( 'koganic_shortcode_product_tab' ) ) {
	function koganic_shortcode_product_tab($atts) {
		$output = '';

		$doing_ajax = (defined( 'DOING_AJAX' ) && DOING_AJAX);

		$parsed_atts = shortcode_atts( array_merge( array(
			'title'     => '',
		), koganic_get_default_product_shortcode_atts()), $atts );

		extract( $parsed_atts );

		$parsed_atts['not_ajax'] = 'yes';

		ob_start();

		if( ! $doing_ajax ) echo '<div class="product-tab-content">';
        	echo koganic_shortcode_products( $parsed_atts );
		if( ! $doing_ajax ) echo '</div>';

		$output = ob_get_clean();
	    if( $doing_ajax ) {
	    	$output =  array(
	    		'html' => $output
	    	);
	    }
	    return $output;
	}
	add_shortcode( 'jms_product_tab', 'koganic_shortcode_product_tab' );
}

if( ! function_exists( 'koganic_get_products_tab_ajax' ) ) {
	function koganic_get_products_tab_ajax() {
		if( ! empty( $_POST['atts'] ) ) {
			$atts = $_POST['atts'];
			$data = koganic_shortcode_product_tab($atts);
			echo json_encode($data);
			die();
		}
	}
	add_action( 'wp_ajax_koganic_get_products_tab', 'koganic_get_products_tab_ajax' );
	add_action( 'wp_ajax_nopriv_koganic_get_products_tab', 'koganic_get_products_tab_ajax' );
}

