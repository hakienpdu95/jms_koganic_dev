<?php
/**
* ------------------------------------------------------------------------------------------------
* Buttons shortcode
* ------------------------------------------------------------------------------------------------
*/
if ( ! function_exists( 'koganic_shortcode_button' ) ) {
	function koganic_shortcode_button( $atts, $content = null ) {
		$output = $use_link = '';

        extract( shortcode_atts( array(
			'title'                  => 'BUTTON',
            'link'                   => '',
            'font_family_button'     => '',
            'size_button'            => '',
            'spacing_button'         => '',
            'weight_button'          => '',
            'color_button'           => '',
            'bgcolor_button'         => '',
            'bdcolor_button'         => '',
            'color_button_hover'     => '',
            'bgcolor_button_hover'   => '',
            'bdcolor_button_hover'   => '',
            'padding_top'            => '10',
            'padding_right'          => '30',
            'padding_bottom'         => '10',
            'padding_left'           => '30',
            'border_top'             => '1',
            'border_right'           => '1',
            'border_left'            => '1',
            'border_bottom'          => '1',
			'border_radius'          => '',
			'align'                  => 'center',
            'css_animation'          => '',
			'el_class'               => '',
            'css' 			         => ''
		), $atts) );

        $link = ( '||' === $link ) ? '' : $link;
        $link = vc_build_link( $link );

        $use_link = false;
        if ( strlen( $link['url'] ) > 0 ) {
        	$use_link = true;
        	$a_href = $link['url'];
        	$a_href = apply_filters( 'vc_btn_a_href', $a_href );
        	$a_title = $link['title'];
        	$a_title = apply_filters( 'vc_btn_a_title', $a_title );
        	$a_target = $link['target'];
        	$a_rel = $link['rel'];
        }

        $attributes = array();

        if ( $use_link ) {
        	$attributes[] = 'href="' . trim( $a_href ) . '"';
        	$attributes[] = 'title="' . esc_attr( trim( $a_title ) ) . '"';
        	if ( ! empty( $a_target ) ) {
        		$attributes[] = 'target="' . esc_attr( trim( $a_target ) ) . '"';
        	}
        	if ( ! empty( $a_rel ) ) {
        		$attributes[] = 'rel="' . esc_attr( trim( $a_rel ) ) . '"';
        	}
        }

        $classes = array('koganic-button-wrapper ');

        if ( isset($align) && $align != '' ){
            $classes[] = 'text-' . esc_attr($align);
        }

        if( isset($el_class) && $el_class != '' ){
            $classes[] = esc_attr($el_class);
        }

        if ( ! empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }
        
        if ( '' !== $css_animation ) {
            $classes[] = getCSSAnimation( $css_animation );
        }
        if ( isset($font_family_button) && '' !== $font_family_button ) {
            $classes[] = esc_attr($font_family_button) . '-font';
        }
        if ( isset($color_button) && '' !== $color_button ) {
            $classes[] = 'button-color-'. esc_attr($color_button);
        }
        if ( isset($bgcolor_button) && '' !== $bgcolor_button ) {
            $classes[] = 'background-color-'. esc_attr($bgcolor_button);
        }
        if ( isset($bdcolor_button) && '' !== $bdcolor_button ) {
            $classes[] = 'border-color-'. esc_attr($bdcolor_button);
        }
        if ( isset($color_button_hover) && '' !== $color_button_hover ) {
            $classes[] = 'button-color-hover-'. esc_attr($color_button_hover);
        }
        if ( isset($bgcolor_button_hover) && '' !== $bgcolor_button_hover ) {
            $classes[] = 'background-color-hover-'. esc_attr($bgcolor_button_hover);
        }
        if ( isset($bdcolor_button_hover) && '' !== $bdcolor_button_hover ) {
            $classes[] = 'border-color-hover-'. esc_attr($bdcolor_button_hover);
        }

        $btn_style = array();

        if ( isset($size_button) && '' !== $size_button ) {
            $btn_style[] = 'font-size: '. esc_attr($size_button).'px';
        }
        if ( isset($padding_top) && '' !== $padding_top ) {
            $btn_style[] = 'padding-top: '. esc_attr($padding_top).'px';
        }
        if ( isset($padding_right) && '' !== $padding_right ) {
            $btn_style[] = 'padding-right: '. esc_attr($padding_right).'px';
        }
        if ( isset($padding_bottom) && '' !== $padding_bottom ) {
            $btn_style[] = 'padding-bottom: '. esc_attr($padding_bottom).'px';
        }
        if ( isset($padding_left) && '' !== $padding_left ) {
            $btn_style[] = 'padding-left: '. esc_attr($padding_left).'px';
        }
        if ( isset($border_top) && '' !== $border_top ) {
            $btn_style[] = 'border-top: '. esc_attr($border_top).'px solid';
        }
        if ( isset($border_right) && '' !== $border_right ) {
            $btn_style[] = 'border-right: '. esc_attr($border_right).'px solid';
        }
        if ( isset($border_bottom) && '' !== $border_bottom ) {
            $btn_style[] = 'border-bottom: '. esc_attr($border_bottom).'px solid';
        }
        if ( isset($border_left) && '' !== $border_left ) {
            $btn_style[] = 'border-left: '. esc_attr($border_left).'px solid';
        }
        if ( isset($border_radius) && '' !== $border_radius ) {
            $btn_style[] = 'border-radius: '. esc_attr($border_radius).'px';
        }
        if ( isset($weight_button) && '' !== $weight_button ) {
            $btn_style[] = 'font-weight: '. esc_attr($weight_button);
        }
        if ( isset($spacing_button) && '' !== $spacing_button ) {
            $btn_style[] = 'letter-spacing: '. esc_attr($spacing_button).'px';
        }
		
		ob_start();
		?>

        <div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
			<a <?php echo implode( ' ', $attributes ); ?> class="" style="<?php echo implode(';',$btn_style); ?>"><?php echo esc_html( $title ); ?></a>
		</div>

		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
    add_shortcode( 'koganic_buttons', 'koganic_shortcode_button' );
}
