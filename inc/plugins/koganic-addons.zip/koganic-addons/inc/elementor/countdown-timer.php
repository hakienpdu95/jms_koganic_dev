<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Countdown_Widget' ) ) {

	class Elementor_Countdown_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {

			parent::__construct( $data, $args );

			if ( ! wp_script_is( 'countdown', 'registered' ) ) {
				wp_register_script( 'countdown' , get_template_directory_uri() . '/assets/3rd-party/jquery.countdown.min.js', array(), false, true  );
			}
			if ( ! wp_script_is( 'moment', 'registered' ) ) {
				wp_register_script( 'moment', get_template_directory_uri() . '/assets/3rd-party/moment.min.js', array( 'jquery' ), '', true );
			}
			if ( ! wp_script_is( 'moment-timezone', 'registered' ) ) {
				wp_register_script( 'moment-timezone', get_template_directory_uri() . '/assets/3rd-party/moment-timezone-with-data.min.js', array( 'jquery' ), '', true );
			}
		}

		public function get_script_depends() {
			return [ 'countdown','moment','moment-timezone' ];
		}

		public function get_name() {
			return 'countdown_timer';
		}

		public function get_title() {
			return __( 'Countdown timer', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-countdown';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'date',
				[
					'label'       => __( 'Date', 'koganic-addons' ),
					'type'        => Controls_Manager::DATE_TIME,
					'default'     => gmdate( 'Y-m-d H:i', strtotime( '+3 day' ) + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ),
					'description' => sprintf( __( 'Date set according to your timezone: %s.', 'koganic-addons' ), Utils::get_timezone_string() ),
				]
			);

			$this->add_control(
				'color_scheme',
				[
					'label'       => __( 'Color Scheme', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''      => __( 'Choose', 'koganic-addons' ),
						'light' => __( 'Light', 'koganic-addons' ),
						'dark'  => __( 'Dark', 'koganic-addons' ),
					],
					'default'     => '',
					'label_block' => true,
				]
			);

			$this->add_control(
				'size',
				[
					'label'       => __( 'Size', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''       => __( 'Choose', 'koganic-addons' ),
						'small'  => __( 'Small', 'koganic-addons' ),
						'medium' => __( 'Medium', 'koganic-addons' ),
						'large'  => __( 'Large', 'koganic-addons' ),
						'xlarge' => __( 'Xlarge', 'koganic-addons' ),
					],
					'default'     => '',
					'label_block' => true,
				]
			);

			$this->add_control(
				'align',
				[
					'label'          => __( 'Align', 'koganic-addons' ),
					'type'           => Controls_Manager::CHOOSE,
					'default'        => 'center',
					'options'        => [
						'left'   => [
							'title' => __( 'Left', 'koganic-addons' ),
							'icon'  => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'koganic-addons' ),
							'icon'  => 'eicon-text-align-center',
						],
						'right'  => [
							'title' => __( 'Right', 'koganic-addons' ),
							'icon'  => 'eicon-text-align-right',
						],
					],
					'style_transfer' => true,
				]
			);

			$this->add_control(
				'style',
				[
					'label'       => __( 'Style', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''            => __( 'Choose', 'koganic-addons' ),
						'standard'    => __( 'Standard', 'koganic-addons' ),
						'transparent' => __( 'Transparent', 'koganic-addons' ),
						'primary'     => __( 'Primary', 'koganic-addons' ),
					],
					'default'     => '',
					'label_block' => true,
				]
			);

			$this->end_controls_section();

		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			$this->add_render_attribute( 'class', 'class', 'koganic-countdown-timer' );
			if ( ! empty( $settings['color_scheme'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'color-scheme-' . esc_attr( $settings['color_scheme'] ) );
			}
			if ( ! empty( $settings['align'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'text-' . esc_attr( $settings['align'] ) );
			}
			if ( ! empty( $settings['size'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'countdown-size-' . esc_attr( $settings['size'] ) );
			}
			if ( ! empty( $settings['style'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'countdown-style-' . esc_attr( $settings['style'] ) );
			}
			$timezone = 'GMT';
			$date = get_gmt_from_date( $settings['date'] . ':00' );
			?>
            <div <?php echo $this->get_render_attribute_string( 'class' ); ?> >
                <div class="koganic-countdown" data-end-date="<?php echo esc_attr( $date ) ?>" data-timezone="<?php echo esc_attr( $timezone ) ?>"></div>
            </div>
			<?php
		}

		protected function content_template() {}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Countdown_Widget() );
}