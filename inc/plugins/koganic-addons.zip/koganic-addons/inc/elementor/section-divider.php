<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Testimonial_Widget' ) ) {

	class Elementor_Divider_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );
		}

		public function get_name() {
			return 'divider';
		}

		public function get_title() {
			return __( 'Section Divider', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-gallery-grid';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'position',
				[
					'label'        => __( 'Position', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'top'    => __( 'Top', 'koganic-addons' ),
						'bottom' => __( 'Bottom', 'koganic-addons' ),
					],
					'default'      => 'top',
					'save_default' => true,
				]
			);

			$this->add_control(
				'content_overlap',
				[
					'label'        => __( 'Overlap', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);

			$this->add_control(
				'color',
				[
					'label'     => __( 'Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .svg-wrap-'.$this->get_id() .' svg' => 'fill: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'style',
				[
					'label'        => __( 'Position', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'waves-small' => __( 'Waves Small', 'koganic-addons' ),
						'waves-wide'  => __( 'Waves Wide', 'koganic-addons' ),
						'circle'      => __( 'Circle', 'koganic-addons' ),
						'triangle'    => __( 'Triangle', 'koganic-addons' ),
						'clouds'      => __( 'Clouds', 'koganic-addons' ),
					],
					'default'      => 'waves-small',
					'save_default' => true,
				]
			);

			$this->add_control(
				'custom_height',
				[
					'label'     => __( 'Custom height', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min'  => 1,
							'max'  => 9999,
							'step' => 1,
						],
					],
					'default'   => [
						'unit' => 'px',
						'size' => '',
					],
					'condition' => [
						'style' => array( 'curved-line', 'diagonal-right', 'half-circle', 'diagonal-left' ),
					],
					'selectors' => [
						'{{WRAPPER}} .svg-wrap-'.$this->get_id() .' svg' => 'height: {{SIZE}}{{UNIT}}',
					],
				]
			);
			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();

			$folder = $file = '';

			$folder = get_template_directory() . '/assets/images/svg';
			$file   = $folder . '/' . esc_attr( $settings['style'] ) . '-' . esc_attr( $settings['position'] ) . '.svg';

			if ( file_exists( $file ) ) {
				$svg = koganic_get_svg( $file );
			} else {
				return false;
			}

			$divider_id = 'svg-wrap-' . $this->get_id();

			$this->add_render_attribute( 'class', 'class', [ "koganic-row-divider", $divider_id ] );

			if ( ! empty( $settings['position'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'divider-position-' . esc_attr( $settings['position'] ) );
			}
			if ( ! empty( $settings['style'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'divider-style-' . esc_attr( $settings['style'] ) );
			}
			if ( ! empty( $settings['content_overlap'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'divider-overlap' );
			}
			?>
            <div <?php echo $this->get_render_attribute_string( 'class' ); ?>>
				<?php echo( $svg ); ?>
            </div>
			<?php
		}

	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Divider_Widget() );
}