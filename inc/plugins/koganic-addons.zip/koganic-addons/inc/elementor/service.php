<?php

namespace Elementor;

use Elementor\Core\Schemes;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Service_Widget' ) ) {

	class Elementor_Service_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );
		}

		public function get_name() {
			return 'service';
		}

		public function get_title() {
			return __( 'Icon and Text', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-icon-box';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'icon_type',
				[
					'label'        => __( 'Icon type', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'icon' => __( 'Icon', 'koganic-addons' ),
						'image' => __( 'Image', 'koganic-addons' ),
					],
					'default'      => 'icon',
					'save_default' => true,
				]
			);

			$this->add_control(
				'selected_icon',
				[
					'label' => __( 'Icon', 'koganic-addons' ),
					'type' => Controls_Manager::ICONS,
					'fa4compatibility' => 'icon',
					'default' => [
						'value' => 'fas fa-star',
						'library' => 'fa-solid',
					],
					'condition'   => array(
						'icon_type' => 'icon',
					),
				]
			);
			$this->add_control(
				'icon_image',
				[
					'label'   => __( 'Icon image', 'koganic-addons' ),
					'type'    => Controls_Manager::MEDIA,
					'dynamic' => [
						'active' => true,
					],
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
					'condition'   => array(
						'icon_type' => 'image',
					),
				]
			);
			$this->add_control(
				'icon_color',
				[
					'label'     => __( 'Custom color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'scheme' => [
						'type' => Schemes\Color::get_type(),
						'value' => Schemes\Color::COLOR_1,
					],
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .vc_icon_element-icon, {{WRAPPER}} .vc_icon_element-icon' => 'fill: {{VALUE}}; color: {{VALUE}}; border-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'icon_size',
				[
					'label'        => __( 'Icon size', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'default' => __( 'Default', 'koganic-addons' ),
						'small' => __( 'Small', 'koganic-addons' ),
						'large' => __( 'Large', 'koganic-addons' ),
						'extra-large' => __( 'Extra Large', 'koganic-addons' ),
					],
					'default'      => 'default',
					'save_default' => true,
				]
			);

			$this->add_responsive_control(
				'alignment',
				[
					'label' => __( 'Icon/Image alignment', 'koganic-addons' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'koganic-addons' ),
							'icon' => 'eicon-h-align-left',
						],
						'top' => [
							'title' => __( 'Top', 'koganic-addons' ),
							'icon' => 'eicon-v-align-top',
						],
						'right' => [
							'title' => __( 'Right', 'koganic-addons' ),
							'icon' => 'eicon-h-align-right',
						],
					],
					'default' => 'left',
				]
			);
			$this->end_controls_section();

			$this->start_controls_section(
				'section_content',
				[
					'label' => __( 'Title', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);
			$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'default'     =>  __( 'Title', 'koganic-addons' ),
					'label_block' => true,
					'placeholder' => __( 'Title', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'subtitle',
				[
					'label'       => __( 'Subtitle', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXTAREA,
					'input_type'  => 'text',
					'default'     =>  __( 'Subtitle', 'koganic-addons' ),
					'label_block' => true,
					'placeholder' => __( 'Subtitle', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'title_size',
				[
					'label'        => __( 'Title size', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'default' => __( 'Default', 'koganic-addons' ),
						'small' => __( 'Small', 'koganic-addons' ),
						'large' => __( 'Large', 'koganic-addons' ),
						'extra-large' => __( 'Extra Large', 'koganic-addons' ),
					],
					'default'      => 'default',
					'save_default' => true,
				]
			);

			$this->add_responsive_control(
				'text_alignment',
				[
					'label' => __( 'Text alignment', 'koganic-addons' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'koganic-addons' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'koganic-addons' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'koganic-addons' ),
							'icon' => 'eicon-text-align-right',
						],
					],
					'default' => 'left',
				]
			);

			$this->add_control(
				'title_color',
				[
					'label'     => __( 'Title color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'scheme' => [
						'type' => Schemes\Color::get_type(),
						'value' => Schemes\Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} .service-title' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'subtitle_color',
				[
					'label'     => __( 'Title color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'scheme' => [
						'type' => Schemes\Color::get_type(),
						'value' => Schemes\Color::COLOR_1,
					],
					'selectors' => [
						'{{WRAPPER}} .service-subtitle' => 'color: {{VALUE}}',
					],
				]
			);
			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();

			$this->add_render_attribute( 'class', 'class', 'service-elements' );
			$this->add_render_attribute( 'icon_class', 'class', 'service-box-icon' );
			$this->add_render_attribute( 'title_class', 'class', 'service-box-content' );

			if ( ! empty( $settings['alignment'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'service-align-' . esc_attr( $settings['alignment'] ) );
			}

			if ( ! empty( $settings['icon_size'] ) ) {
				$this->add_render_attribute( 'icon_class', 'class', 'size-icon-' . esc_attr( $settings['icon_size'] ) );
			}

			if ( empty( $settings['icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
				$settings['icon'] = 'fa fa-star';
            }

			if ( ! empty( $settings['title_size'] ) ) {
				$this->add_render_attribute( 'title_class', 'class', 'size-title-' . esc_attr( $settings['title_size'] ) );
			}

			if ( ! empty( $settings['text_alignment'] ) ) {
				$this->add_render_attribute( 'title_class', 'class', 'text-' . esc_attr( $settings['text_alignment'] ) );
			}
			$has_icon = ! empty( $settings['icon'] ) || ! empty( $settings['icon_image']['url'] );
			if ( ! empty( $settings['icon'] ) ) {
				$this->add_render_attribute( 'icon', 'class', $settings['icon'] );
				$this->add_render_attribute( 'icon', 'aria-hidden', 'true' );
			}

			if ( !! empty( $settings['icon'] ) && ! empty( $settings['selected_icon']['value'] ) ) {
				$has_icon = true;
			}
			$migrated = isset( $settings['__fa4_migrated']['selected_icon'] );
			$is_new = empty( $settings['icon'] ) && Icons_Manager::is_migration_allowed();
			?>
            <div <?php echo $this->get_render_attribute_string( 'class' ); ?>>
			    <?php if ( $has_icon ) : ?>
                <div <?php echo $this->get_render_attribute_string( 'icon_class' ); ?>>
                    <?php if('image' === $settings['icon_type']): ?>
                        <?php
	                        if(!empty($settings['icon_image']['id'])){
		                        echo wp_get_attachment_image( $settings['icon_image']['id'], 'full' );
                            }else{
		                        echo '<img src="' . $settings['icon_image']['url'] . '">';
                            }
                        ?>
                    <?php else: ?>
                        <span class="vc_icon_element-icon">
                        <?php if ( $is_new || $migrated ) :
	                        Icons_Manager::render_icon( $settings['selected_icon'], [ 'aria-hidden' => 'true' ] );
                        else : ?>
                            <i <?php echo $this->get_render_attribute_string( 'icon' ); ?>></i>
                        <?php endif; ?>
                    </span>
                    <?php endif; ?>
                </div>
			    <?php endif; ?>
                <div <?php echo $this->get_render_attribute_string( 'title_class' ); ?>>
                    <div class="service-box-inner">
	                    <?php if ( !empty($settings['title']) ) :
		                    $this->add_render_attribute( 'title', 'class', 'service-title' );
		                    $this->add_inline_editing_attributes( 'title', 'none' );
		                    ?>
                            <h4 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html($settings['title']); ?></h4>
	                    <?php endif; ?>

	                    <?php if ( !empty($settings['subtitle']) ) :
		                    $this->add_render_attribute( 'subtitle', 'class', 'service-subtitle' );
		                    $this->add_inline_editing_attributes( 'subtitle', 'none' );
		                    ?>
                            <p <?php echo $this->get_render_attribute_string( 'subtitle' ); ?>><?php echo esc_html($settings['subtitle']); ?></p>
	                    <?php endif; ?>
                    </div>
                </div>
            </div>
			<?php
		}

		protected function content_template() {
            ?>
            <#
            view.addRenderAttribute( 'class', 'class', 'service-elements' );
            view.addRenderAttribute( 'icon_class', 'class', 'service-box-icon' );
            view.addRenderAttribute( 'title_class', 'class', 'service-box-content' );

            if( settings.alignment && '' !== settings.alignment){
                view.addRenderAttribute( 'class', 'class', 'service-align-'+settings.alignment );
            }
            if( settings.icon_size && '' !== settings.icon_size){
                view.addRenderAttribute( 'icon_class', 'class', 'size-icon-'+settings.icon_size );
            }
            if( settings.title_size){
                view.addRenderAttribute( 'title_class', 'class', 'size-title-'+settings.title_size );
            }
            if( settings.text_alignment){
                view.addRenderAttribute( 'title_class', 'class', 'text-'+settings.text_alignment );
            }
            iconHTML = elementor.helpers.renderIcon( view, settings.selected_icon, { 'aria-hidden': true }, 'i' , 'object' ),
            migrated = elementor.helpers.isIconMigrated( settings, 'selected_icon' ),
            #>
            <div {{{ view.getRenderAttributeString( 'class' ) }}}>
                <# if ( settings.icon || settings.selected_icon || settings.icon_image.url ) { #>
                <div {{{ view.getRenderAttributeString( 'icon_class' ) }}}>
                    <# if( settings.icon_type == 'image' ){ #>
                         <img src="{{ settings.icon_image.url }}" >
                    <# } else { #>
                        <span class="vc_icon_element-icon">
                            <# if ( iconHTML && iconHTML.rendered && ( ! settings.icon || migrated ) ) { #>
                            {{{ iconHTML.value }}}
                            <# } else { #>
                            <i class="{{ settings.icon }}" aria-hidden="true"></i>
                            <# } #>
                        </span>
                     <# } #>
                </div>
                <# } #>

                <div {{{ view.getRenderAttributeString( 'title_class' ) }}}>
                    <div class="service-box-inner">
                        <# if ( '' !== settings.title ) {
                            view.addRenderAttribute( 'title', 'class', 'service-title' );
                            view.addInlineEditingAttributes( 'title', 'none' );
                        #>
                            <h4 {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</h4>
                        <# } #>

                        <# if ( '' !== settings.subtitle ) {
                            view.addRenderAttribute( 'subtitle', 'class', 'service-subtitle' );
                            view.addInlineEditingAttributes( 'subtitle', 'none' );
                        #>
                            <p {{{ view.getRenderAttributeString( 'subtitle' ) }}}>{{{ settings.subtitle }}}</p>
                        <# } #>
                    </div>
                </div>
            </div>
            <?php
        }
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Service_Widget() );
}