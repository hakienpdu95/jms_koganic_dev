<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Instagram_Widget' ) ) {

	class Elementor_Instagram_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );
			wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
		}

		public function get_script_depends() {
			return [ 'script-handle' ];
		}

		public function get_name() {
			return 'instagram';
		}

		public function get_title() {
			return __( 'Instagram', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-instagram-post';
		}

		public function get_categories() {
			return [ 'yanka' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'access_token',
				[
					'label'       => __( 'Access Token', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'label_block' => true,
					'description' => sprintf( __( 'Lookup Access Token <a target="_blank" href="%s">here</a>', 'koganic-addons' ), 'https://www.wpzoom.com/instagram-auth' ),
				]
			);

			$this->add_control(
				'slider',
				[
					'label'        => __( 'Enable Slider', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
				]
			);

			$this->add_control(
				'limit',
				[
					'label'       => __( 'Per Page', 'plugin-domain' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => esc_html__( 'How much items per page to show', 'koganic-addons' ),
					'min'         => 1,
					'max'         => 100,
					'step'        => 1,
					'default'     => 6,
					'condition'   => [
						'slider' => '',
					],
				]
			);

			$this->add_control(
				'columns',
				[
					'label'       => __( 'Columns', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => esc_html__( 'This parameter is not working if slider has enabled', 'koganic-addons' ),
					'options'     => [
						2 => __( '2 columns', 'koganic-addons' ),
						3 => __( '3 columns', 'koganic-addons' ),
						4 => __( '4 columns', 'koganic-addons' ),
						5 => __( '5 columns', 'koganic-addons' ),
						6 => __( '6 columns', 'koganic-addons' ),
						7 => __( '7 columns', 'koganic-addons' ),
						8 => __( '8 columns', 'koganic-addons' ),
						9 => __( '9 columns', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 2,
					'condition'   => [
						'slider' => '',
					],
				]
			);

			$this->add_control(
				'gutter',
				[
					'label'       => __( 'Gutter Width', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						'0'  => __( '0px', 'koganic-addons' ),
						'10' => __( '10px', 'koganic-addons' ),
						'20' => __( '20px', 'koganic-addons' ),
						'30' => __( '30px', 'koganic-addons' ),
						'40' => __( '40px', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => '0',
				]
			);

			$this->add_control(
				'rounded',
				[
					'label'        => __( 'Rounded corners for images', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);
			$this->end_controls_section();

			$this->start_controls_section(
				'section_slider',
				[
					'label' => __( 'Slider Setting', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->add_control(
				'items_desktop',
				[
					'label'       => __( 'Items Show On Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on desktop', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
						6 => __( '6 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 6,
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->add_control(
				'items_small_desktop',
				[
					'label'       => __( 'Items Show On Small Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 4,
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->add_control(
				'items_tablet',
				[
					'label'       => __( 'Items Show On Tablet Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 3,
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->add_control(
				'items_mobile',
				[
					'label'       => __( 'Items Show On Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 2,
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->add_control(
				'items_small_mobile',
				[
					'label'       => __( 'Items Show On Small Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small mobile. Screen resolution of device < 445px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->add_control(
				'navigation',
				[
					'label'        => __( 'Enable Navigation', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->add_control(
				'style_navigation',
				[
					'label'     => __( 'Arrow Styles', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'icon_arrow'     => __( 'Icon Arrow', 'koganic-addons' ),
						'icon_box_arrow' => __( 'Icon Arrow Box', 'koganic-addons' ),
					],
					'default'   => 'icon_arrow',
					'condition' => [
						'navigation' => 'yes',
					],
				]
			);

			$this->add_control(
				'pagination',
				[
					'label'        => __( 'Enable Dots Pagination', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => __( 'Enables autoplay mode', 'koganic-addons' ),
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'        => __( 'Autoplay', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->add_control(
				'loop',
				[
					'label'        => __( 'Loop', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'koganic-addons' ),
					'condition'   => [
						'slider' => 'yes',
					],
				]
			);

			$this->end_controls_section();

		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			if ( empty($settings['access_token'] ) ) {
				return;
			}

			$this->add_render_attribute( 'classes_wrap', 'class', [ 'instagram-pic-wrapper', 'pr' ] );
			$this->add_render_attribute( 'classes', 'class', [ 'instagram-wrap', 'clearfix' ] );
			$this->add_render_attribute( 'slider_wrap', 'class', [
				'instagram-carousel-' . $this->get_id(),
				'owl-theme',
				'owl-carousel'
			] );

			if ( ! empty( $settings['rounded'] ) && $settings['rounded'] == 'yes') {
				$this->add_render_attribute( 'classes_wrap', 'class', 'instagram-rounded' );
			}

			if ( ! empty( $settings['gutter'] )) {
				$this->add_render_attribute( 'classes', 'class', 'layout-spacing-'.$settings['gutter'] );
			}else{
				$this->add_render_attribute( 'classes', 'class', 'no-space' );
			}

			if ( ! empty( $settings['columns'] )) {
				$this->add_render_attribute( 'classes', 'class', 'layout-columns-'.$settings['columns'] );
			}

			if ( ! empty( $settings['slider'] ) && $settings['slider'] == 'yes') {
				if ( ! empty( $settings['items_desktop'] ) ) {
					$attr_slider['itemDesktop'] = intval( $settings['items_desktop'] );
					$attr_slider['smartSpeed'] = 250;
				}

				if ( ! empty( $settings['items_small_desktop'] ) ) {
					$attr_slider['itemSmallDesktop'] = intval( $settings['items_small_desktop'] );
				}

				if ( ! empty( $settings['items_tablet'] ) ) {
					$attr_slider['itemTablet'] = intval( $settings['items_tablet'] );
				}

				if ( ! empty( $settings['items_mobile'] ) ) {
					$attr_slider['itemMobile'] = intval( $settings['items_mobile'] );
				}

				if ( ! empty( $settings['items_small_mobile'] ) ) {
					$attr_slider['itemSmallMobile'] =  intval( $settings['items_small_mobile'] );
				}

				if ( ! empty( $settings['gutter'] ) ) {
					$attr_slider['margin'] =  intval( $settings['gutter'] );
				}

				if ( isset( $settings['navigation'] ) && $settings['navigation'] == 'yes' ) {
					$attr_slider['navigation'] = true;
				} else {
					$attr_slider['navigation'] = false;
				}

				if ( isset( $settings['pagination'] ) && $settings['pagination'] == 'yes' ) {
					$attr_slider['pagination'] = true;
				} else {
					$attr_slider['pagination'] = false;
				}

				if ( isset( $settings['autoplay'] ) && $settings['autoplay'] == 'yes' ) {
					$attr_slider['autoplay'] = true;
				} else {
					$attr_slider['autoplay'] = false;
				}

				if ( isset( $settings['loop'] ) && $settings['loop'] == 'yes' ) {
					$attr_slider['loop'] = true;
				} else {
					$attr_slider['loop'] = false;
				}

				if ( ! empty( $attr_slider ) ) {
					$attr_json = wp_json_encode( $attr_slider );
					$data_slider = function_exists( 'wc_esc_json' ) ? wc_esc_json( $attr_json ) : _wp_specialchars( $attr_json, ENT_QUOTES, 'UTF-8', true );
					$this->add_render_attribute( 'slider_wrap', 'data-carousel', $data_slider );
				}
			}
			?>
        <div <?php echo $this->get_render_attribute_string( 'classes_wrap' ); ?>>
			<?php if ( ! empty( $settings['slider'] ) && $settings['slider'] == 'yes'):?>
            <div <?php echo $this->get_render_attribute_string( 'slider_wrap' ); ?>>
			<?php else: ?>
            <div <?php echo $this->get_render_attribute_string( 'classes' ); ?>>
		<?php endif;?>

			<?php
		if ( ! empty( $settings['access_token'] ) ) {
			$limit = ! empty( $settings['limit'] ) ? $settings['limit'] : 12 ;

			$api = add_query_arg(
				array(
					'fields' => 'id,media_type,media_url,permalink,likes,username,timestamp',
					'access_token'         => $settings['access_token'],
					'limit' => $limit
				),
				'https://graph.instagram.com/me/media'
			);
			$getphoto = wp_remote_get( $api );


		if ( is_wp_error( $getphoto ) || 200 != wp_remote_retrieve_response_code( $getphoto ) ) {
			echo '<p>'. esc_html_e('Incorrect token specified.', 'koganic-addons') .'</p>';
		}else{
			$photos = json_decode( wp_remote_retrieve_body( $getphoto ), true);

			if (isset($photos['data']) && count($photos['data'])) {
				$items = array();
				foreach ( $photos['data'] as $media ) {
					if ($media['media_type'] === 'IMAGE') {
						$items[] = $media;
					}elseif($media['media_type'] === 'CAROUSEL_ALBUM'){
						$album = wp_remote_get(
							add_query_arg(
								array(
									'fields' => 'id,media_type,media_url,permalink,likes,username,timestamp',
									'access_token'         => $settings['access_token'],
								),
								"https://graph.instagram.com/{$media['id']}/children"
							)
						);
						if ( !is_wp_error( $album ) || 200 === wp_remote_retrieve_response_code( $album ) ) {
							$album_obj = json_decode( wp_remote_retrieve_body( $getphoto ), true);
							if (isset($album_obj['data']) && count($album_obj['data'])) {
								foreach ($album_obj['data'] as $children) {
									if ($children['media_type'] == "IMAGE") {
										$items[] =  $children;
										if (count($items) >= $limit) break;
									}
								}
							}
						}
					}
					if (count($items) >= $limit) break;
				}
			}

		if ( isset( $items ) ) {
		foreach ( $items as $item ) {
			$link     = $item['permalink'];
			$image    = $item['media_url'];

		if ( ! empty( $settings['slider'] ) && $settings['slider'] == 'yes') : ?>
            <div class="item">
			<?php else : ?>
            <div class="item mb_<?php echo esc_attr( $settings['gutter'] ); ?>">
				<?php endif; ?>
                <div class="instagram-picture pr oh">
                    <a href="<?php echo esc_url( $link ); ?>" target="_blank"></a>
                    <img src="<?php echo esc_url( $image ); ?>" alt="Instagram" />
                </div>
            </div>
			<?php
		}
		}
		}
		}
			?>

            </div>
            </div>
			<?php
		}


	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Instagram_Widget() );
}