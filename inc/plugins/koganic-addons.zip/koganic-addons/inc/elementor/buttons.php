<?php

namespace Elementor;
use Elementor\Core\Schemes;
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Brand_Widget' ) ) {

	class Elementor_Button_Widget extends Widget_Base {

		public function get_name() {
			return 'jms_button';
		}

		public function get_title() {
			return __( 'Button', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-button';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'placeholder' => __( 'Title', 'koganic-addons' ),
					'default' => __( 'BUTTON', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'link',
				[
					'label'       => __( 'Link', 'koganic-addons' ),
					'type'        => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'font_family_button',
				[
					'label'   => __( 'Font Family', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						''        => __( 'Default', 'koganic-addons' ),
						'primary' => __( 'Font Primary', 'koganic-addons' ),
						'second'  => __( 'Font Second', 'koganic-addons' ),
					],
					'default' => '',
				]
			);

			$this->add_control(
				'size_button',
				[
					'label'      => __( 'Font Size', 'koganic-addons' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', 'rem' ],
					'range'      => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'selectors'  => [
						'{{WRAPPER}} .koganic-button' => 'font-size: {{SIZE}}{{UNIT}}',
					],
				]
			);
			$this->add_control(
				'spacing_button',
				[
					'label'     => __( 'Letter Spacing', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min'  => - 5,
							'max'  => 10,
							'step' => 0.1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .koganic-button' => 'letter-spacing: {{SIZE}}{{UNIT}}',
					],
				]
			);

			$this->add_control(
				'weight_button',
				[
					'label'        => __( 'Font Weight', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'inherit' => __( 'Default', 'koganic-addons' ),
						'300'     => __( 'Light', 'koganic-addons' ),
						'400'     => __( 'Regular', 'koganic-addons' ),
						'500'     => __( 'Medium', 'koganic-addons' ),
						'600'     => __( 'Semibold', 'koganic-addons' ),
						'700'     => __( 'Bold', 'koganic-addons' ),
						'800'     => __( 'Extra Bold', 'koganic-addons' ),
						'900'     => __( 'Black', 'koganic-addons' ),
					],
					'default'      => 'inherit',
					'save_default' => true,
					'selectors'  => [
						'{{WRAPPER}} .koganic-button' => 'font-weight: {{VALUE}};',
					],
				]
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name'      => 'border',
					'fields_options' => [
						'border' => [
							'default' => 'solid',
						],
						'width' => [
							'default' => [
								'top' => '1',
								'right' => '1',
								'bottom' => '1',
								'left' => '1',
								'isLinked' => false,
							],
						],
					],
					'selector'  => '{{WRAPPER}} .koganic-button',
					'separator' => 'before',
				]
			);

			$this->add_control(
				'border_radius',
				[
					'label'      => __( 'Border Radius', 'koganic-addons' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .koganic-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->start_controls_tabs( 'tabs_button_style' );
			$this->start_controls_tab(
				'tab_button_normal',
				[
					'label' => __( 'Normal', 'elementor' ),
				]
			);
			$this->add_control(
				'color_button',
				[
					'label'     => __( 'Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .koganic-button' => 'color: {{VALUE}};',
					]
				]
			);

			$this->add_control(
				'bgcolor_button',
				[
					'label'     => __( 'Background Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .koganic-button' => 'background-color: {{VALUE}};',
					]
				]
			);

			$this->add_control(
				'bdcolor_button',
				[
					'label'     => __( 'Border Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .koganic-button' => 'background-color: {{VALUE}};',
					]
				]
			);
			$this->end_controls_tab();
			$this->start_controls_tab(
				'tab_button_hover',
				[
					'label' => __( 'Hover', 'koganic-addons' ),
				]
			);
			$this->add_control(
				'btn_color_hover',
				[
					'label'     => __( 'Color Hover', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .koganic-button:hover, {{WRAPPER}} .koganic-button:focus' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'btn_bgcolor_hover',
				[
					'label'     => __( 'Background Color Hover', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .koganic-button:hover, {{WRAPPER}} .koganic-button:focus' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'btn_bdcolor_hover',
				[
					'label'     => __( 'Border Color Hover', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .koganic-button:hover, {{WRAPPER}} .koganic-button:focus' => 'border-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();
			$this->end_controls_tabs();


			$this->add_control(
				'align',
				[
					'label'        => __( 'Align', 'koganic-addons' ),
					'type'         => Controls_Manager::CHOOSE,
					'options' => [
						'left'    => [
							'title' => __( 'Left', 'koganic-addons' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'koganic-addons' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'koganic-addons' ),
							'icon' => 'eicon-text-align-right',
						],
					],
					'style_transfer' => true,
					'separator'  => 'before',
				]
			);
			$this->add_responsive_control(
				'padding_button',
				[
					'label'      => __( 'Padding', 'koganic-addons' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .koganic-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'default' => [
						'top' => '10',
						'right' => '30',
						'bottom' => '10',
						'left' => '30',
						'unit' => 'px',
						'isLinked' => '',
					]
				]
			);
			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();

			$this->add_render_attribute( 'wrapper', 'class', 'koganic-button-wrapper' );

			if ( !empty( $settings['font_family_button'] )) {
				$this->add_render_attribute( 'wrapper', 'class', esc_attr($settings['font_family_button']) . '-font' );
			}
			if ( !empty( $settings['color_button'] )) {
				$this->add_render_attribute( 'wrapper', 'class', 'button-color-'. esc_attr($settings['color_button']) );
			}

			if ( !empty( $settings['align'] )) {
				$this->add_render_attribute( 'wrapper', 'class', 'text-'. esc_attr($settings['align']) );
			}
			?>
				<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
					<?php
					$this->add_render_attribute( 'title', 'class', 'koganic-button' );
					$this->add_link_attributes( 'title', $settings['link'] );
					$this->add_inline_editing_attributes( 'title', 'none' );

					?>
					<a <?php echo $this->get_render_attribute_string( 'title' ); ?>>
						<?php echo esc_html( $settings['title'] ); ?>
					</a>
				</div>
			<?php
		}

		protected function content_template_() {
			?>
            <#
            view.addRenderAttribute( 'wrapper', 'class', 'koganic-button-wrapper' );
            view.addRenderAttribute( 'title', 'class', 'koganic-button' );
            view.addInlineEditingAttributes( 'title', 'none' );
            #>
            <div {{{ view.getRenderAttributeString( 'wrapper' ) }}}>
                <a  {{{ view.getRenderAttributeString( 'title' ) }}} href="{{ settings.link.url }}" role="button"></a>
            </div>
			<?php
		}


	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Button_Widget() );
}