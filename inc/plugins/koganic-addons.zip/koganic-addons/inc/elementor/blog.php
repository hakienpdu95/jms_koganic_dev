<?php

namespace Elementor;

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Blog_Widget' ) ) {

	class Elementor_Blog_Widget extends Widget_Base {
		public function __construct( $data = [], $args = null ) {

			parent::__construct( $data, $args );

			if ( ! wp_script_is( 'script-handle', 'registered' ) ) {
				wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
			}
		}

		public function get_script_depends() {
			return [ 'script-handle' ];
		}

		public function get_name() {
			return 'blog';
		}

		public function get_title() {
			return __( 'Blog Carousel', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-posts-grid';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}

		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'orderby',
				[
					'label'   => __( 'Order By', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'title'         => __( 'Title', 'koganic-addons' ),
						'date'          => __( 'Date', 'koganic-addons' ),
						'ID'            => __( 'ID', 'koganic-addons' ),
						'author'        => __( 'Author', 'koganic-addons' ),
						'modified'      => __( 'Modified', 'koganic-addons' ),
						'rand'          => __( 'Random', 'koganic-addons' ),
						'comment_count' => __( 'Comment count', 'koganic-addons' ),
						'menu_order'    => __( 'Menu order', 'koganic-addons' ),
					],
					'default' => 'title',
				]
			);

			$this->add_control(
				'order',
				[
					'label'   => __( 'Order', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'ASC'  => __( 'Ascending', 'koganic-addons' ),
						'DESC' => __( 'Descending', 'koganic-addons' ),
					],
					'default' => 'DESC',
				]
			);

			$this->add_control(
				'total_items',
				[
					'label'       => __( 'Per Page', 'koganic-addons' ),
					'type'        => Controls_Manager::NUMBER,
					'min'         => 1,
					'max'         => 100,
					'step'        => 1,
					'default'     => 6,
					'description' => __( 'How much items per page to show (-1 to show all blogs)', 'koganic-addons' )
				]
			);

			$this->add_control(
				'number_of_rows',
				[
					'label'   => __( 'Show No. Of blogs row', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'1' => __( '1 Row', 'koganic-addons' ),
						'2' => __( '2 Row', 'koganic-addons' ),
						'3' => __( '3 Row', 'koganic-addons' ),
					],
					'default' => '1',
				]
			);

			$this->add_control(
				'layout_of_blog',
				[
					'label'   => __( 'Layout Blog', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'1' => __( 'Default', 'koganic-addons' ),
						'2' => __( 'Grid', 'koganic-addons' ),
					],
					'default' => '1',
				]
			);

			$this->add_group_control(
				Group_Control_Image_Size::get_type(),
				[
					'name' => 'img_size',
					//'exclude' => [ 'custom' ],
					'default' => 'medium',
				]
			);

			$this->add_control(
				'hover_effect',
				[
					'label'        => __( 'Hover Effect', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'1'    => __( 'Effect 1', 'koganic-addons' ),
						'2'    => __( 'Effect 2', 'koganic-addons' ),
						'3'    => __( 'Effect 3', 'koganic-addons' ),
						'4'    => __( 'Effect 4', 'koganic-addons' ),
						'5'    => __( 'Effect 5', 'koganic-addons' ),
						'6'    => __( 'Effect 6', 'koganic-addons' ),
						'7'    => __( 'Effect 7', 'koganic-addons' ),
						'8'    => __( 'Effect 8', 'koganic-addons' ),
						'9'    => __( 'Effect 9', 'koganic-addons' ),
						'10'   => __( 'Effect 10', 'koganic-addons' ),
						'11'   => __( 'Effect 11', 'koganic-addons' ),
						'12'   => __( 'Effect 12', 'koganic-addons' ),
						'13'   => __( 'Effect 13', 'koganic-addons' ),
						'14'   => __( 'Effect 14', 'koganic-addons' ),
						'15'   => __( 'Effect 15', 'koganic-addons' ),
						'16'   => __( 'Effect 16', 'koganic-addons' ),
						'17'   => __( 'Effect 17', 'koganic-addons' ),
						'none' => __( 'Disable', 'koganic-addons' ),
					],
					'default'      => '1',
					'save_default' => true,
					'description'  => esc_html__( 'Please consult link: ("your-domain"/banners) to choose effect.', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'show_author',
				[
					'label'        => __( 'Show author?', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);

			$this->add_control(
				'show_comment',
				[
					'label'        => __( 'Show comment?', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => '',
				]
			);
			$this->add_control(
				'show_date',
				[
					'label'        => __( 'Show date?', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);

			$this->add_control(
				'show_category',
				[
					'label'        => __( 'show_category?', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);

			$this->add_control(
				'show_excerpt',
				[
					'label'        => __( 'Show excerpt?', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => '',
				]
			);

			$this->add_control(
				'excerpt',
				[
					'label'     => __( 'Limit the character length', 'koganic-addons' ),
					'type'      => Controls_Manager::NUMBER,
					'min'       => 5,
					'max'       => 100,
					'step'      => 1,
					'default'   => 20,
					'condition' => [
						'show_excerpt' => 'yes',
					],
				]
			);

			$this->add_control(
				'show_readmore',
				[
					'label'        => __( 'Show Read more button?', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => '',
				]
			);

			$this->end_controls_section();

			$this->start_controls_section(
				'section_slider',
				[
					'label' => __( 'Slider Setting', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);
			$this->add_control(
				'items_space',
				[
					'label'       => __( 'Gutter', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						0  => __( '0px', 'koganic-addons' ),
						10 => __( '10px', 'koganic-addons' ),
						20 => __( '20px', 'koganic-addons' ),
						30 => __( '30px', 'koganic-addons' ),
						40 => __( '40px', 'koganic-addons' ),
						50 => __( '50px', 'koganic-addons' ),
						60 => __( '60px', 'koganic-addons' ),
						70 => __( '70px', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 40,
				]
			);

			$this->add_control(
				'items_desktop',
				[
					'label'       => __( 'Items Show On Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on desktop', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
						6 => __( '6 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 3,
				]
			);

			$this->add_control(
				'items_small_desktop',
				[
					'label'       => __( 'Items Show On Small Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 3,
				]
			);

			$this->add_control(
				'items_tablet',
				[
					'label'       => __( 'Items Show On Tablet Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 2,
				]
			);

			$this->add_control(
				'items_mobile',
				[
					'label'       => __( 'Items Show On Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 2,
				]
			);

			$this->add_control(
				'items_small_mobile',
				[
					'label'       => __( 'Items Show On Small Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small mobile. Screen resolution of device < 445px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
				]
			);

			$this->add_control(
				'navigation',
				[
					'label'        => __( 'Enable Navigation', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);

			$this->add_control(
				'style_navigation',
				[
					'label'     => __( 'Arrow Styles', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'icon_arrow'     => __( 'Icon Arrow', 'koganic-addons' ),
						'icon_box_arrow' => __( 'Icon Arrow Box', 'koganic-addons' ),
					],
					'default'   => 'icon_arrow',
					'condition' => [
						'navigation' => 'yes',
					],
				]
			);

			$this->add_control(
				'pagination',
				[
					'label'        => __( 'Enable Dots Pagination', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => __( 'Enables autoplay mode', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'        => __( 'Autoplay', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);

			$this->add_control(
				'loop',
				[
					'label'        => __( 'Loop', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'koganic-addons' ),
				]
			);

			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			$this->add_render_attribute( 'class', 'class', 'jmsblog-box' );
			$this->add_render_attribute( 'class', 'class', 'layout-' . esc_attr( $settings['layout_of_blog'] ) );
			$this->add_render_attribute( 'slider_wrap', 'class', [
				'blogs-carousel-' . $this->get_id(),
				'owl-theme',
				'owl-carousel'
			] );

			if ( isset( $settings['style_navigation'] ) && $settings['style_navigation'] == 'icon_arrow' ) {
				$this->add_render_attribute( 'class', 'class', 'icon_arrow' );
			} elseif ( isset( $settings['style_navigation'] ) && $settings['style_navigation'] == 'icon_box_arrow' ) {
				$this->add_render_attribute( 'class', 'class', 'icon_box_arrow' );
			}

			if ( ! empty( $settings['hover_effect'] ) ) {
				$this->add_render_attribute( 'classes_effect', 'class', [
                    'article-inner',
					'box-effect',
					'image-effect-' . esc_attr( $settings['hover_effect'] )
				] );
			}
			// attr slider
			$attr_slider = array();

			if ( ! empty( $settings['items_desktop'] ) ) {
				$attr_slider['itemDesktop'] = intval( $settings['items_desktop'] );
				$attr_slider['smartSpeed'] = 250;
			}

			if ( ! empty( $settings['items_small_desktop'] ) ) {
				$attr_slider['itemSmallDesktop'] = intval( $settings['items_small_desktop'] );
			}

			if ( ! empty( $settings['items_tablet'] ) ) {
				$attr_slider['itemTablet'] = intval( $settings['items_tablet'] );
			}

			if ( ! empty( $settings['items_mobile'] ) ) {
				$attr_slider['itemMobile'] = intval( $settings['items_mobile'] );
			}

			if ( ! empty( $settings['items_small_mobile'] ) ) {
				$attr_slider['itemSmallMobile'] =  intval( $settings['items_small_mobile'] );
			}

			if ( ! empty( $settings['items_space'] ) ) {
				$attr_slider['margin'] =  intval( $settings['items_space'] );
			}

			if ( isset( $settings['navigation'] ) && $settings['navigation'] == 'yes' ) {
				$attr_slider['navigation'] = true;
			} else {
				$attr_slider['navigation'] = false;
			}

			if ( isset( $settings['pagination'] ) && $settings['pagination'] == 'yes' ) {
				$attr_slider['pagination'] = true;
			} else {
				$attr_slider['pagination'] = false;
			}

			if ( isset( $settings['autoplay'] ) && $settings['autoplay'] == 'yes' ) {
				$attr_slider['autoplay'] = true;
			} else {
				$attr_slider['autoplay'] = false;
			}

			if ( isset( $settings['loop'] ) && $settings['loop'] == 'yes' ) {
				$attr_slider['loop'] = true;
			} else {
				$attr_slider['loop'] = false;
			}

			if ( ! empty( $attr_slider ) ) {
				$attr_json = wp_json_encode( $attr_slider );
				$data_slider = function_exists( 'wc_esc_json' ) ? wc_esc_json( $attr_json ) : _wp_specialchars( $attr_json, ENT_QUOTES, 'UTF-8', true );
				$this->add_render_attribute( 'slider_wrap', 'data-carousel', $data_slider );
			}
			$sticky = get_option( 'sticky_posts' );

			$args = array(
				'posts_per_page' => ( !empty($settings['total_items']) && intval($settings['total_items']) ) ? $settings['total_items'] : 3,
				'orderby'        => !empty($settings['orderby']) ?  $settings['orderby'] : 'title',
				'order'          => !empty($settings['order']) ?  $settings['order'] : 'desc',
				'post__not_in'   => $sticky,
				'ignore_sticky_posts' => 1,
				'post_type'      => 'post',
				'post_status'    => 'publish',
			);

			$posts = new \WP_Query( $args );
			?>
			<div <?php echo $this->get_render_attribute_string( 'class' ); ?> >
				<?php if ( $posts->have_posts() ) : ?>
				<div <?php echo $this->get_render_attribute_string( 'slider_wrap' ); ?> >
					<?php
					$row = 1;
					while ( $posts->have_posts() ) : $posts->the_post();
					?>
                        <?php if($row == 1): ?>
                            <div class="item-wrap">
                        <?php endif; ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post-loop blog-design-slider blog-style-flat' ); ?>>
                            <div <?php echo $this->get_render_attribute_string( 'classes_effect' ); ?> >
						        <?php if ( has_post_thumbnail() && ! post_password_required() && ! is_attachment() ) : ?>
                                    <header class="entry-header pr">
                                        <figure class="entry-thumbnail">
                                            <div class="post-img-wrap item-effect">
                                                <a href="<?php echo esc_url( get_permalink() ); ?>">
											        <?php
											        if ( !empty($settings['img_size_size'])) {
												        echo $this->koganic_get_post_thumbnail( $settings['img_size_size'],$settings['img_size_custom_dimension']);
											        } else {
												        echo the_post_thumbnail();
											        }
											        ?>
                                                </a>
                                            </div>
                                        </figure>
                                    </header><!-- .entry-header -->
						        <?php endif; ?>

                                <div class="article-body-container">
                                	<div class="box-body">
						            <?php if( isset($settings['show_author']) || isset($settings['show_date']) || isset($settings['show_comment']) ) : ?>
                                        <ul class="blog-meta entry-meta-list">

								            <?php if( isset($settings['show_author']) && $settings['show_author'] == 'yes' ) : ?>
                                                <li class="meta-author">
										            <?php esc_html_e('Posted: by', 'koganic'); ?>
                                                    <a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID'))); ?>"><?php echo esc_html( get_the_author() ); ?></a>
                                                </li>
								            <?php endif; ?>

								            <?php if( isset($settings['show_date']) && $settings['show_date'] == 'yes' ) : ?>
                                                <li class="meta-date"><span class="time updated"> <?php echo get_the_date('M j'); ?></span></li>
								            <?php endif; ?>

								            <?php if( isset($settings['show_comment']) && $settings['show_comment'] == 'yes' ) : ?>
                                                <li class="meta-comment">
                                                    <a href="<?php echo get_comments_link(); ?>"><?php echo get_comments_number(get_the_ID()) . ' ' . esc_html__( 'comments', 'koganic-addons' ); ?></a>
                                                </li>
								            <?php endif; ?>

                                        </ul>
						            <?php endif; ?>

	                                <?php if (isset($settings['show_category']) && get_the_category_list( ', ' ) && $settings['show_category'] == 'yes' ) : ?>
                                        <h4 class="blog-categories"><?php echo get_the_category_list( ', ' ); ?></h4>
	                                <?php endif ?>

                                    <h3 class="blog-title entry-title">
                                        <a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"><?php the_title(); ?></a>
                                    </h3>


	                                <?php if( isset($settings['show_excerpt']) && $settings['show_excerpt'] == 'yes' ) : ?>
                                        <div class="blog-excerpt entry-content">
                                            <p><?php koganic_post_excerpt( intval($settings['excerpt']) ); ?></p>
                                        </div>
	                                <?php endif; ?>

	                                <?php if( isset($settings['show_readmore']) && $settings['show_readmore'] == 'yes' ) : ?>
                                        <p class="read-more-section"><a class="btn-read-more more-link" href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html__('read more', 'koganic-addons'); ?></a></p>
	                                <?php endif; ?>
	                                </div>
                                </div>
                            </div>
                        </article>
						<?php if( $row == (int) $settings['number_of_rows'] || $posts->current_post+1 == $posts->post_count) : ?>
							<?php $row = 0; ?>
                            </div>
						<?php endif; ?>
					<?php
						$row++;
						endwhile; // end of the loop.
						wp_reset_postdata();
					?>
				</div>
				<?php else: ?>
					<p class="alert alert-danger"><?php esc_html_e( 'No posts were found matching your selection.', 'koganic-addons' ); ?></p>
				<?php endif; ?>
			</div>
			<?php
		}

		private function koganic_get_post_thumbnail($size = 'medium' , $size_custom_dimension = '', $attach_id = false){
			global $post, $koganic_loop;
			if ( has_post_thumbnail() ) {
				if( method_exists('Elementor\Group_Control_Image_Size','get_attachment_image_src')) {
					$image_sizes = get_intermediate_image_sizes();
					$image_sizes[] = 'full';
					$settings = [
                        'thumbnail_size' => $size,
                        'thumbnail_custom_dimension' => $size_custom_dimension
                    ];
					if( ! $attach_id ) $attach_id = get_post_thumbnail_id();
					if( ! empty( $koganic_loop['img_size'] ) ) $size = $koganic_loop['img_size'];

					if ( ! empty( $attach_id) && in_array( $size, $image_sizes ) ) {
						$img = wp_get_attachment_image( $attach_id, $size, false );
                    }else{
						$image_src = Group_Control_Image_Size::get_attachment_image_src( $attach_id, 'thumbnail', $settings );
						if ( ! empty( $image_src ) ) {
							$image_class_html = ' class="attachment-large wp-post-image"';
							$img = sprintf( '<img src="%s" title="%s" alt="%s"%s/>', esc_attr( $image_src ) ,Control_Media::get_image_title( ['id'=>$attach_id] ), Control_Media::get_image_alt( ['id'=>$attach_id] ), $image_class_html );
						}
                    }
				} else {
					$img = get_the_post_thumbnail( $post->ID, $size );
				}

				return $img;
			}
		}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Blog_Widget() );
}