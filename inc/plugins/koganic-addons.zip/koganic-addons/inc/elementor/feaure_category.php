<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Feature_Categories_Widget' ) ) {

	class Elementor_Feature_Categories_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );

			wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
		}

		public function get_script_depends() {
			return [ 'script-handle' ];
		}

		public function get_name() {
			return 'feature_categories';
		}

		public function get_title() {
			return __( 'Feature Categories', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-product-categories';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}

		private function get_available_category() {
			$categories = get_terms( 'product_cat' );

			$options = [];

			foreach ( $categories as $category ) {
				$options[ $category->term_id ] = $category->name;
			}

			return $options;
		}

		protected function _register_controls() {
			$cats = $this->get_available_category();
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'categories_design',
				[
					'label'       => __( 'Design', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						'grid'     => __( 'Grid', 'koganic-addons' ),
						'carousel' => __( 'Carousel', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 'grid',
				]
			);

			$this->add_control(
				'columns',
				[
					'label'       => __( 'Columns', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						1 => __( '1 Column', 'koganic-addons' ),
						2 => __( '2 Columns', 'koganic-addons' ),
						3 => __( '3 Columns', 'koganic-addons' ),
						4 => __( '4 Columns', 'koganic-addons' ),
						5 => __( '5 Columns', 'koganic-addons' ),
						6 => __( '6 Columns', 'koganic-addons' ),
					],
					'default'     => 3,
					'condition'   => [
						'categories_design' => 'grid',
					],
					'description' => __( 'The `columns` field is used to display the columns of categories.', 'koganic' ),
				]
			);

			$this->add_control(
				'orderby',
				[
					'label'       => __( 'Order by', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''              => '',
						'date'          => __( 'Date', 'koganic-addons' ),
						'ID'            => __( 'ID', 'koganic-addons' ),
						'author'        => __( 'Author', 'koganic-addons' ),
						'title'         => __( 'Title', 'koganic-addons' ),
						'modified'      => __( 'Modified', 'koganic-addons' ),
						'menu_order'    => __( 'Menu order', 'koganic-addons' ),
						'comment_count' => __( 'Comment count', 'koganic-addons' ),
						'include'       => __( 'As IDs or slugs provided order', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => '',
				]
			);

			$this->add_control(
				'order',
				[
					'label'        => __( 'Sort order', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''     => '',
						'ASC'  => __( 'Ascending', 'koganic-addons' ),
						'DESC' => __( 'Descending', 'koganic-addons' ),
					],
					'default'      => '',
					'save_default' => true,
					'description'  => sprintf( wp_kses( __( 'Designates the ascending or descending order. More at %s.', 'koganic-addons' ), array(
						'a' => array(
							'href'   => array(),
							'target' => array()
						)
					) ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
				]
			);

			$this->add_control(
				'spacing',
				[
					'label'     => __( 'Product spacing', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						0  => __( '0px', 'koganic-addons' ),
						10 => __( '10px', 'koganic-addons' ),
						20 => __( '20px', 'koganic-addons' ),
						30 => __( '30px', 'koganic-addons' ),
						40 => __( '40px', 'koganic-addons' ),
					],
					'default'   => 30,
					'condition' => [
						'categories_design' => 'grid',
					],
				]
			);

			$this->add_control(
				'hide_empty',
				[
					'label'        => __( 'Hide empty', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);

			$this->add_control(
				'ids',
				[
					'label'       => __( 'Categories', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT2,
					'options'     => $cats,
					'default'     => [],
					'label_block' => true,
					'multiple'    => true,
					'description' => esc_html__( 'List of product categories', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'hover_effect',
				[
					'label'        => __( 'Hover Effect', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'1'    => __( 'Effect 1', 'koganic-addons' ),
						'2'    => __( 'Effect 2', 'koganic-addons' ),
						'3'    => __( 'Effect 3', 'koganic-addons' ),
						'4'    => __( 'Effect 4', 'koganic-addons' ),
						'5'    => __( 'Effect 5', 'koganic-addons' ),
						'6'    => __( 'Effect 6', 'koganic-addons' ),
						'7'    => __( 'Effect 7', 'koganic-addons' ),
						'8'    => __( 'Effect 8', 'koganic-addons' ),
						'9'    => __( 'Effect 9', 'koganic-addons' ),
						'10'   => __( 'Effect 10', 'koganic-addons' ),
						'11'   => __( 'Effect 11', 'koganic-addons' ),
						'12'   => __( 'Effect 12', 'koganic-addons' ),
						'13'   => __( 'Effect 13', 'koganic-addons' ),
						'14'   => __( 'Effect 14', 'koganic-addons' ),
						'15'   => __( 'Effect 15', 'koganic-addons' ),
						'16'   => __( 'Effect 16', 'koganic-addons' ),
						'17'   => __( 'Effect 17', 'koganic-addons' ),
						'none' => __( 'Disable', 'koganic-addons' ),
					],
					'default'      => '1',
					'save_default' => true,
					'description'  => esc_html__( 'Please consult link: ("your-domain"/banners) to choose effect.', 'koganic-addons' ),
				]
			);

			$this->end_controls_section();

			$this->start_controls_section(
				'section_slider',
				[
					'label'     => __( 'Slider Setting', 'koganic-addons' ),
					'tab'       => Controls_Manager::TAB_CONTENT,
					'condition' => [
						'categories_design' => 'carousel',
					],
				]
			);
			$this->add_control(
				'items_space',
				[
					'label'       => __( 'Gutter', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						0  => __( '0px', 'koganic-addons' ),
						10 => __( '10px', 'koganic-addons' ),
						20 => __( '20px', 'koganic-addons' ),
						30 => __( '30px', 'koganic-addons' ),
						40 => __( '40px', 'koganic-addons' ),
						50 => __( '50px', 'koganic-addons' ),
						60 => __( '60px', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 40,
				]
			);

			$this->add_control(
				'items_desktop',
				[
					'label'       => __( 'Items Show On Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on desktop', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
						6 => __( '6 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 4,
					'condition'   => [
						'categories_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'items_small_desktop',
				[
					'label'       => __( 'Items Show On Small Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 4,
					'condition'   => [
						'categories_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'items_tablet',
				[
					'label'       => __( 'Items Show On Tablet Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 3,
					'condition'   => [
						'categories_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'items_mobile',
				[
					'label'       => __( 'Items Show On Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 2,
					'condition'   => [
						'categories_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'items_small_mobile',
				[
					'label'       => __( 'Items Show On Small Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small mobile. Screen resolution of device < 445px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
					'condition'   => [
						'categories_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'navigation',
				[
					'label'        => __( 'Enable Navigation', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'categories_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'style_navigation',
				[
					'label'     => __( 'Arrow Styles', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'icon_arrow'     => __( 'Icon Arrow', 'koganic-addons' ),
						'icon_box_arrow' => __( 'Icon Arrow Box', 'koganic-addons' ),
					],
					'default'   => 'icon_arrow',
					'condition' => [
						'navigation' => 'yes',
					],
				]
			);

			$this->add_control(
				'pagination',
				[
					'label'        => __( 'Enable Dots Pagination', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => __( 'Enables autoplay mode', 'koganic-addons' ),
					'condition'    => [
						'categories_design' => 'carousel',
					],

				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'        => __( 'Autoplay', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'categories_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'loop',
				[
					'label'        => __( 'Loop', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'koganic-addons' ),
					'condition'    => [
						'categories_design' => 'carousel',
					],
				]
			);
			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();

			$this->add_render_attribute( 'wrapper', 'class', 'jmsproductcategories-elements' );

			if ( isset( $settings['style_navigation'] ) && $settings['style_navigation'] == 'icon_arrow' ) {
				$this->add_render_attribute( 'wrapper', 'class', 'icon_arrow' );
			} elseif ( isset( $settings['style_navigation'] ) && $settings['style_navigation'] == 'icon_box_arrow' ) {
				$this->add_render_attribute( 'wrapper', 'class', 'icon_box_arrow' );
			}
			$classes_effect = array();
			if ( ! empty( $settings['hover_effect'] ) ) {
				$classes_effect[] = 'box-effect image-effect-' . esc_attr( $settings['hover_effect'] );
			}

			if ( ! empty( $settings['ids'] ) ) {
				$ids = explode( ',', $settings['ids'] );
				$ids = array_map( 'trim', $settings['ids'] );
			} else {
				$ids = array();
			}
			// get terms
			$hide_empty = ( $settings['hide_empty'] == 'yes' || $settings['hide_empty'] == 1 ) ? 1 : 0;
			$order      = ! empty( $settings['order'] ) ? $settings['order'] : 'ASC';
			$args       = array(
				'order'      => $order,
				'hide_empty' => $hide_empty,
				'include'    => $ids,
				'pad_counts' => true,
				'child_of'   => false
			);
			if ( ! empty( $settings['orderby'] ) ) {
				$args['orderby'] = $settings['orderby'];
			}
			$product_categories = get_terms( 'product_cat', $args );

			// attr slider
			$attr_slider = array();
			if ( isset( $settings['categories_design'] ) && $settings['categories_design'] == 'carousel' ) {
				if ( ! empty( $settings['items_desktop'] ) ) {
					$attr_slider['itemDesktop'] = intval( $settings['items_desktop'] );
					$attr_slider['smartSpeed'] = 250;
				}

				if ( ! empty( $settings['items_small_desktop'] ) ) {
					$attr_slider['itemSmallDesktop'] = intval( $settings['items_small_desktop'] );
				}

				if ( ! empty( $settings['items_tablet'] ) ) {
					$attr_slider['itemTablet'] = intval( $settings['items_tablet'] );
				}

				if ( ! empty( $settings['items_mobile'] ) ) {
					$attr_slider['itemMobile'] = intval( $settings['items_mobile'] );
				}

				if ( ! empty( $settings['items_small_mobile'] ) ) {
					$attr_slider['itemSmallMobile'] =  intval( $settings['items_small_mobile'] );
				}

				if ( ! empty( $settings['items_space'] ) ) {
					$attr_slider['margin'] =  intval( $settings['items_space'] );
				}

				if ( isset( $settings['navigation'] ) && $settings['navigation'] == 'yes' ) {
					$attr_slider['navigation'] = true;
				} else {
					$attr_slider['navigation'] = false;
				}

				if ( isset( $settings['pagination'] ) && $settings['pagination'] == 'yes' ) {
					$attr_slider['pagination'] = true;
				} else {
					$attr_slider['pagination'] = false;
				}

				if ( isset( $settings['autoplay'] ) && $settings['autoplay'] == 'yes' ) {
					$attr_slider['autoplay'] = true;
				} else {
					$attr_slider['autoplay'] = false;
				}

				if ( isset( $settings['loop'] ) && $settings['loop'] == 'yes' ) {
					$attr_slider['loop'] = true;
				} else {
					$attr_slider['loop'] = false;
				}
				$this->add_render_attribute( 'slider_wrap', 'class', [
					'product-categories-carousel-' . $this->get_id(),
					'owl-theme',
					'owl-carousel'
				] );
				if ( ! empty( $attr_slider ) ) {
					$attr_json = wp_json_encode( $attr_slider );
					$data_slider = function_exists( 'wc_esc_json' ) ? wc_esc_json( $attr_json ) : _wp_specialchars( $attr_json, ENT_QUOTES, 'UTF-8', true );
					$this->add_render_attribute( 'slider_wrap', 'data-carousel', $data_slider );
				}
			}else{
				$this->add_render_attribute( 'slider_wrap', 'class', ['products','row','product-design-grid','masonry-container'] );
				if ( ! empty( $settings['columns']  ) ) {
					$this->add_render_attribute( 'slider_wrap', 'class', 'layout-columns-'.esc_attr( $settings['columns'] ));
                }
				if ( ! empty( $settings['spacing']  ) ) {
					$this->add_render_attribute( 'slider_wrap', 'class', 'layout-spacing-'.esc_attr( $settings['spacing'] ));
				}
            }
			?>

        <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> >
			<div <?php echo $this->get_render_attribute_string( 'slider_wrap' ); ?>>
			<?php foreach ( $product_categories as $category ): ?>
                <div class="category-item item mb-<?php echo esc_attr( $settings['spacing'] ); ?> <?php echo esc_attr( implode( ' ', $classes_effect ) ); ?>">
					<?php
					wc_get_template( 'content-product_cat.php', array(
						'category' => $category
					) );
					?>
                </div>
			<?php endforeach; ?>
            </div>
        </div>
        <?php
		}

		protected function content_template() {
		}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Feature_Categories_Widget() );
}