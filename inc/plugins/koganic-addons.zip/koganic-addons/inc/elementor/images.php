<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Image_Carousel_Widget' ) ) {

	class Elementor_Image_Carousel_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );

			if ( ! wp_script_is( 'script-handle', 'registered' ) ) {
				wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
			}
		}

		public function get_script_depends() {
			return [ 'script-handle' ];
		}
		
		public function get_name() {
			return 'images_carousel';
		}

		public function get_title() {
			return __( 'Image Carousel', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-featured-image';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$repeater = new Repeater();

			$repeater->add_control(
				'image_brand',
				[
					'label'       => __( 'Image', 'koganic-addons' ),
					'type'        => Controls_Manager::MEDIA,
					'default'     => [
						'url' => Utils::get_placeholder_image_src(),
					],
					'description' => __( 'Select image from media library.', 'koganic-addons' ),
				]
			);

			$repeater->add_group_control(
				Group_Control_Image_Size::get_type(),
				[
					'name'      => 'image_brand',
					'exclude'   => [ 'custom' ],
					'separator' => 'none',
					'default'   => 'full',
				]
			);

			$repeater->add_control(
				'link_brand',
				[
					'label'         => __( 'Link', 'koganic-addons' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default'       => [
						'url'         => '',
						'is_external' => false,
						'nofollow'    => false,
					],
				]
			);
			$repeater->add_control(
				'title_brand',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'placeholder' => __( 'Title', 'koganic-addons' ),
				]
			);
			$repeater->add_control(
				'paragraph_content_1',
				[
					'label'       => __( 'Paragraph 1', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
				]
			);

			$repeater->add_control(
				'paragraph_content_2',
				[
					'label'       => __( 'Paragraph 2', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
				]
			);

			$repeater->add_control(
				'button_content',
				[
					'label'       => __( 'Button Text', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
				]
			);
			$this->add_control(
				'images_carousel',
				[
					'label'   => '',
					'type'    => Controls_Manager::REPEATER,
					'fields'  => $repeater->get_controls(),
					'default' => [
						[
							'title_brand'         => __( 'Image 1', 'koganic-addons' ),
							'image_brand'         => [
								'url' => Utils::get_placeholder_image_src()
							],
						],
						[
							'title_brand'         => __( 'Image 2', 'koganic-addons' ),
							'image_brand'         => [
								'url' => Utils::get_placeholder_image_src()
							],
						],
						[
							'title_brand'         => __( 'Image 3', 'koganic-addons' ),
							'image_brand'         => [
								'url' => Utils::get_placeholder_image_src()
							],
						],
						[
							'title_brand'         => __( 'Image 4', 'koganic-addons' ),
							'image_brand'         => [
								'url' => Utils::get_placeholder_image_src()
							],
						],
						[
							'title_brand'         => __( 'Image 5', 'koganic-addons' ),
							'image_brand'         => [
								'url' => Utils::get_placeholder_image_src()
							],
						],
						[
							'title_brand'         => __( 'Image 6', 'koganic-addons' ),
							'image_brand'         => [
								'url' => Utils::get_placeholder_image_src()
							],
						],
					],
				]
			);

			$this->add_control(
				'images_style',
				[
					'label'       => __( 'Choose Style', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''            => __( 'Default', 'koganic-addons' ),
						'movecontent' => __( 'Move Content', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => '',
				]
			);
			$this->end_controls_section();

			$this->start_controls_section(
				'section_slider',
				[
					'label' => __( 'Slider Setting', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);
			$this->add_control(
				'items_space',
				[
					'label'       => __( 'Gutter', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						0  => __( '0px', 'koganic-addons' ),
						10 => __( '10px', 'koganic-addons' ),
						20 => __( '20px', 'koganic-addons' ),
						30 => __( '30px', 'koganic-addons' ),
						40 => __( '40px', 'koganic-addons' ),
						50 => __( '50px', 'koganic-addons' ),
						60 => __( '60px', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 40,
				]
			);

			$this->add_control(
				'items_desktop',
				[
					'label'       => __( 'Items Show On Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on desktop', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
						6 => __( '6 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 6,
				]
			);

			$this->add_control(
				'items_small_desktop',
				[
					'label'       => __( 'Items Show On Small Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 5,
				]
			);

			$this->add_control(
				'items_tablet',
				[
					'label'       => __( 'Items Show On Tablet Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 3,
				]
			);

			$this->add_control(
				'items_mobile',
				[
					'label'       => __( 'Items Show On Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 2,
				]
			);

			$this->add_control(
				'items_small_mobile',
				[
					'label'       => __( 'Items Show On Small Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small mobile. Screen resolution of device < 445px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 2,
				]
			);

			$this->add_control(
				'navigation',
				[
					'label'        => __( 'Enable Navigation', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);

			$this->add_control(
				'style_navigation',
				[
					'label'     => __( 'Arrow Styles', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'icon_arrow'     => __( 'Icon Arrow', 'koganic-addons' ),
						'icon_box_arrow' => __( 'Icon Arrow Box', 'koganic-addons' ),
					],
					'default'   => 'icon_arrow',
					'condition' => [
						'navigation' => 'yes',
					],
				]
			);

			$this->add_control(
				'pagination',
				[
					'label'        => __( 'Enable Dots Pagination', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => __( 'Enables autoplay mode', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'        => __( 'Autoplay', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);

			$this->add_control(
				'loop',
				[
					'label'        => __( 'Loop', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'koganic-addons' ),
				]
			);
			$this->end_controls_section();

		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			if ( ! $settings['images_carousel'] ) {
				return;
			}
			$this->add_render_attribute( 'class', 'class', 'image-carousel-box' );
			$this->add_render_attribute( 'slider_wrap', 'class', [
				'images-carousel-' . $this->get_id(),
				'owl-theme',
				'owl-carousel'
			] );

			if ( isset( $settings['style_navigation'] ) && $settings['style_navigation'] == 'icon_arrow' ) {
				$this->add_render_attribute( 'class', 'class', 'icon_arrow' );
			} elseif ( isset( $settings['style_navigation'] ) && $settings['style_navigation'] == 'icon_box_arrow' ) {
				$this->add_render_attribute( 'class', 'class', 'icon_box_arrow' );
			}

			$attr_slider = array();

			if ( ! empty( $settings['items_desktop'] ) ) {
				$attr_slider['itemDesktop'] = intval( $settings['items_desktop'] );
				$attr_slider['smartSpeed'] = 250;
			}

			if ( ! empty( $settings['items_small_desktop'] ) ) {
				$attr_slider['itemSmallDesktop'] = intval( $settings['items_small_desktop'] );
			}

			if ( ! empty( $settings['items_tablet'] ) ) {
				$attr_slider['itemTablet'] = intval( $settings['items_tablet'] );
			}

			if ( ! empty( $settings['items_mobile'] ) ) {
				$attr_slider['itemMobile'] = intval( $settings['items_mobile'] );
			}

			if ( ! empty( $settings['items_small_mobile'] ) ) {
				$attr_slider['itemSmallMobile'] =  intval( $settings['items_small_mobile'] );
			}

			if ( ! empty( $settings['items_space'] ) ) {
				$attr_slider['margin'] =  intval( $settings['items_space'] );
			}

			if ( isset( $settings['navigation'] ) && $settings['navigation'] == 'yes' ) {
				$attr_slider['navigation'] = true;
			} else {
				$attr_slider['navigation'] = false;
			}

			if ( isset( $settings['pagination'] ) && $settings['pagination'] == 'yes' ) {
				$attr_slider['pagination'] = true;
			} else {
				$attr_slider['pagination'] = false;
			}

			if ( isset( $settings['autoplay'] ) && $settings['autoplay'] == 'yes' ) {
				$attr_slider['autoplay'] = true;
			} else {
				$attr_slider['autoplay'] = false;
			}

			if ( isset( $settings['loop'] ) && $settings['loop'] == 'yes' ) {
				$attr_slider['loop'] = true;
			} else {
				$attr_slider['loop'] = false;
			}

			if ( ! empty( $attr_slider ) ) {
				$attr_json = wp_json_encode( $attr_slider );
				$data_slider = function_exists( 'wc_esc_json' ) ? wc_esc_json( $attr_json ) : _wp_specialchars( $attr_json, ENT_QUOTES, 'UTF-8', true );
				$this->add_render_attribute( 'slider_wrap', 'data-carousel', $data_slider );
			}

			?>
            <div <?php echo $this->get_render_attribute_string( 'class' ); ?> >
			<?php if ( count( $settings['images_carousel'] ) ): ?>
                <div <?php echo $this->get_render_attribute_string( 'slider_wrap' ); ?> >
					<?php
					foreach ( $settings['images_carousel'] as $index => $item ):
						$link_key = 'link_' . $index;
						if ( ! empty( $item['link_brand']['url'] ) ) {
							$this->add_link_attributes( $link_key, $item['link_brand'] );
						}
						if ( ! empty( $item['image_brand']['id'] ) ) {
							$image_url = Group_Control_Image_Size::get_attachment_image_src( $item['image_brand']['id'], 'image_brand', $item );
						} else {
							$image_url = $item['image_brand']['url'];
						}
						?>
                        <div class="item tc <?php echo esc_attr($settings['images_style']); ?>">
                            <a <?php echo $this->get_render_attribute_string( $link_key ); ?> class="jms-link-image">
								<?php if ( $image_url ): ?>
                                    <img src="<?php echo esc_url( $image_url ); ?>"
                                         alt="<?php echo esc_attr( $item['title_brand'] ) ?>">
								<?php endif; ?>
                            </a>
                            <div class="pt-description">
                                <a class="pt-title"
                                   tabindex="0" <?php echo $this->get_render_attribute_string( $link_key ); ?>>
                                    <div class="pt-title-small"><?php echo esc_html( $item['title_brand'] ); ?></div>
                                    <div class="pt-title-large">
                                        <span><?php echo esc_html( $item['paragraph_content_1'] ); ?></span></div>
                                </a>
                                <p><?php echo esc_html( $item['paragraph_content_2'] ); ?></p>
								<?php if ( ! empty( $item['button_content'] ) ) { ?>
                                    <a <?php echo $this->get_render_attribute_string( $link_key ); ?> class="btn" tabindex="0"><?php echo esc_html( $item['button_content'] ); ?></a>
								<?php } ?>
                            </div>
                        </div>
					<?php endforeach; ?>
                </div>
                <script type="text/javascript">
					jQuery( document ).ready(function( $ ) {
						jQuery(".images-carousel-<?php echo esc_js( $this->get_id() ); ?>").on('initialized.owl.carousel', function( event ){
						    var imgHeight = $(this).find(".item .jms-link-image > img")[0].height;
							var posTop = imgHeight/2;
								posTop += 10;
							jQuery(".images-carousel-<?php echo esc_js( $this->get_id() ); ?> .owl-nav [class*='owl-']").css('top',posTop + "px");
						});
					});        		
        		</script>
			<?php endif; ?>
            </div>
			<?php
		}

	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Image_Carousel_Widget() );
}