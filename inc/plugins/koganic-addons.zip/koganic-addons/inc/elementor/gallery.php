<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Gallery_Widget' ) ) {

	class Elementor_Gallery_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );
			wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
		}

		public function get_script_depends() {
			return [ 'script-handle' ];
		}

		public function get_name() {
			return 'images-gallery';
		}

		public function get_title() {
			return __( 'Images gallery', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-gallery-grid';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'images',
				[
					'label' => __( 'Images', 'koganic-addons' ),
					'type'  => Controls_Manager::GALLERY,
					//'show_label' => false,
				]
			);
			$this->add_group_control(
				Group_Control_Image_Size::get_type(),
				[
					'name'      => 'thumbnail',
					'exclude'   => [ 'custom' ],
					'separator' => 'none',
				]
			);

			$this->add_control(
				'gallery_type',
				[
					'label'        => __( 'View', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'grid'    => __( 'Default grid', 'koganic-addons' ),
						'masonry' => __( 'Masonry grid', 'koganic-addons' ),
					],
					'save_default' => true,
					'default'      => 'grid',
				]
			);

			$this->add_control(
				'spacing',
				[
					'label'   => __( 'Space between images (px)', 'koganic-addons' ),
					'type'    => Controls_Manager::SLIDER,
					'range'   => [
						'px' => [
							'min'  => 0,
							'max'  => 40,
							'step' => 10,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 10,
					],
				]
			);
			$gallery_columns = range( 1, 6 );
			$gallery_columns = array_combine( $gallery_columns, $gallery_columns );

			$this->add_control(
				'columns',
				[
					'label'   => __( 'Columns', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 3,
					'options' => $gallery_columns,
				]
			);

			$this->add_control(
				'on_click',
				[
					'label'        => __( 'On click action', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'none'     => __( 'None', 'koganic-addons' ),
						'lightbox' => __( 'Lightbox', 'koganic-addons' ),
					],
					'save_default' => true,
					'default'      => 'lightbox',
				]
			);

			$this->add_control(
				'target_blank',
				[
					'label'        => __( 'Open in new tab', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'on_click' => 'links',
					],
				]
			);

			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			if ( ! $settings['images'] ) {
				return;
			}
			$this->add_render_attribute( 'class', 'class', "koganic-gallery" );

			if ( ! empty( $settings['gallery_type'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'gallery-design-' . esc_attr( $settings['gallery_type'] ) );
			}

			if ( ! empty( $settings['columns'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'layout-columns-' . esc_attr( $settings['columns'] ) );
			}

			if ( ! empty( $settings['spacing']['size'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'layout-spacing-' . esc_attr( $settings['spacing']['size'] ) );
			}
			?>
            <div <?php echo $this->get_render_attribute_string( 'class' ); ?> >
                <div class="gallery-wrapper">
					<?php
					foreach ( $settings['images'] as $index => $image ):
						$image_url = Group_Control_Image_Size::get_attachment_image_src( $image['id'], 'thumbnail', $settings );
						$image_html = '<img class="koganic-gallery-image" src="' . esc_attr( $image_url ) . '" alt="' . esc_attr( Control_Media::get_image_alt( $image ) ) . '" />';

						$link = [ 'url' => wp_get_attachment_url( $image['id'] ) ];
                        $link_key = 'link_' . $index;
                        $lightbox = $settings['on_click'] === 'lightbox' ? 'yes' : 'no';
                        if($lightbox){
	                        $this->add_lightbox_data_attributes( $link_key, $image['id'], $lightbox , $this->get_id() );

	                        if ( Plugin::$instance->editor->is_edit_mode() ) {
		                        $this->add_render_attribute( $link_key, [
			                        'class' => 'elementor-clickable',
		                        ] );
	                        }

	                        $this->add_link_attributes( $link_key, $link );
                        }
						?>
                        <div class="product-item item <?php echo 'mb-' . esc_attr( $settings['spacing']['size'] ); ?>">
                            <?php if($lightbox): ?>
                                <a <?php echo $this->get_render_attribute_string( $link_key ); ?>>
                            <?php endif; ?>
                                <?php echo wp_kses( $image_html, array( 'img' => array('class' => true,'width' => true,'height' => true,'src' => true,'alt' => true) ) );?>
						    <?php if($lightbox): ?>
                                </a>
                            <?php endif; ?>
                        </div>
					<?php endforeach; ?>
                </div>
            </div>
			<?php
		}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Gallery_Widget() );
}