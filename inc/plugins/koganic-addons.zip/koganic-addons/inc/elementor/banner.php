<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Banner_Widget' ) ) {

	class Elementor_Banner_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );

			wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
		}

		public function get_script_depends() {
			return [ 'script-handle' ];
		}

		public function get_name() {
			return 'banner';
		}

		public function get_title() {
			return __( 'Banner', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-banner';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'image',
				[
					'label'   => __( 'Image', 'koganic-addons' ),
					'type'    => Controls_Manager::MEDIA,
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
				]
			);
			$this->add_group_control(
				Group_Control_Image_Size::get_type(),
				[
					'name'      => 'image',
					'default'   => 'full',
					'separator' => 'none',
				]
			);
			$this->add_control(
				'pr_promo_type',
				[
					'label'       => __( 'Banner Box', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''  => __( 'Default', 'koganic-addons' ),
						'1' => __( 'Banner Type 01', 'koganic-addons' ),
						'2' => __( 'Banner Type 02', 'koganic-addons' ),
						'3' => __( 'Banner Type 03', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => '',
				]
			);

			$this->add_control(
				'content_form',
				[
					'label'        => __( 'Content Form', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'1' => __( 'Default', 'koganic-addons' ),
						'2' => __( 'Special', 'koganic-addons' ),
					],
					'default'      => '1',
					'save_default' => true,
				]
			);

			$this->add_control(
				'content',
				[
					'label'     => __( 'Content Special', 'koganic-addons' ),
					'type'      => Controls_Manager::WYSIWYG,
					'default'   => '',
					'condition' => [
						'content_form' => '2',
					],
				]
			);
			$this->add_control(
				'link',
				[
					'label'         => __( 'Link to', 'koganic-addons' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'plugin-domain' ),
					'show_external' => true,
				]
			);

			$this->add_control(
				'content_hidden',
				[
					'label'        => __( 'Hidden Content', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => esc_html__( 'When hover banner, content will be showed up', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'hover_effect',
				[
					'label'        => __( 'Hover Effect', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'1'    => __( 'Effect 1', 'koganic-addons' ),
						'2'    => __( 'Effect 2', 'koganic-addons' ),
						'3'    => __( 'Effect 3', 'koganic-addons' ),
						'4'    => __( 'Effect 4', 'koganic-addons' ),
						'5'    => __( 'Effect 5', 'koganic-addons' ),
						'6'    => __( 'Effect 6', 'koganic-addons' ),
						'7'    => __( 'Effect 7', 'koganic-addons' ),
						'8'    => __( 'Effect 8', 'koganic-addons' ),
						'9'    => __( 'Effect 9', 'koganic-addons' ),
						'10'   => __( 'Effect 10', 'koganic-addons' ),
						'11'   => __( 'Effect 11', 'koganic-addons' ),
						'12'   => __( 'Effect 12', 'koganic-addons' ),
						'13'   => __( 'Effect 13', 'koganic-addons' ),
						'14'   => __( 'Effect 14', 'koganic-addons' ),
						'15'   => __( 'Effect 15', 'koganic-addons' ),
						'16'   => __( 'Effect 16', 'koganic-addons' ),
						'17'   => __( 'Effect 17', 'koganic-addons' ),
						'none' => __( 'Disable', 'koganic-addons' ),
					],
					'default'      => '1',
					'save_default' => true,
					'description'  => esc_html__( 'Please consult link: ("your-domain"/banners) to choose effect.', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'padding_content',
				[
					'label'       => __( 'Padding Content', 'koganic-addons' ),
					'type'        => Controls_Manager::DIMENSIONS,
					'size_units'  => [ 'px', 'em' ],
					'selectors'   => [
						'{{WRAPPER}} .banner-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'description' => esc_html__( 'The content will be pushed back inside.', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'content_width',
				[
					'label'        => __( 'Banner content width', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'10'  => __( '10%', 'koganic-addons' ),
						'20'  => __( '20%', 'koganic-addons' ),
						'30'  => __( '30%', 'koganic-addons' ),
						'40'  => __( '40%', 'koganic-addons' ),
						'50'  => __( '50%', 'koganic-addons' ),
						'60'  => __( '60%', 'koganic-addons' ),
						'70'  => __( '70%', 'koganic-addons' ),
						'80'  => __( '80%', 'koganic-addons' ),
						'90'  => __( '90%', 'koganic-addons' ),
						'100' => __( '100%', 'koganic-addons' ),
					],
					'default'      => '100',
					'save_default' => true,
				]
			);

			$this->end_controls_section();

			$this->start_controls_section(
				'section_title',
				[
					'label'     => __( 'Title Style', 'koganic-addons' ),
					'tab'       => Controls_Manager::TAB_CONTENT,
					'condition' => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'label_block' => true,
					'placeholder' => __( 'Title', 'koganic-addons' ),
					'condition'   => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'title_font_family',
				[
					'label'        => __( 'Font Family', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''        => __( 'Default', 'koganic-addons' ),
						'primary' => __( 'Font Primary', 'koganic-addons' ),
						'second'  => __( 'Font Second', 'koganic-addons' ),
						'third'  => __( 'Font Third', 'koganic-addons' ),
					],
					'default'      => '',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'title_type',
				[
					'label'        => __( 'Title Type', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''  => __( 'Default', 'koganic-addons' ),
						'1' => __( 'Background Opacity White', 'koganic-addons' ),
						'2' => __( 'Background Opacity Black', 'koganic-addons' ),
						'3' => __( 'Title Underline', 'koganic-addons' ),
						'4' => __( 'Title Hover', 'koganic-addons' ),
					],
					'default'      => '',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'title_size',
				[
					'label'      => __( 'Title Font Size', 'koganic-addons' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', 'rem' ],
					'range'      => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'selectors'  => [
						'{{WRAPPER}} .title p' => 'font-size: {{SIZE}}{{UNIT}}',
					],
					'condition'  => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'title_spacing',
				[
					'label'     => __( 'Letter Spacing', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min'  => - 5,
							'max'  => 10,
							'step' => 0.1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .title p' => 'letter-spacing: {{SIZE}}{{UNIT}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'title_margin',
				[
					'label'     => __( 'Margin Top', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min' => 0,
							'max' => 500,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .title' => 'margin-top: {{SIZE}}{{UNIT}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'title_color',
				[
					'label'     => __( 'Title Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .title p' => 'color: {{VALUE}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'title_weight',
				[
					'label'        => __( 'Font Weight', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'inherit' => __( 'Default', 'koganic-addons' ),
						'300'     => __( 'Light', 'koganic-addons' ),
						'400'     => __( 'Regular', 'koganic-addons' ),
						'500'     => __( 'Medium', 'koganic-addons' ),
						'600'     => __( 'Semibold', 'koganic-addons' ),
						'700'     => __( 'Bold', 'koganic-addons' ),
						'800'     => __( 'Extra Bold', 'koganic-addons' ),
						'900'     => __( 'Black', 'koganic-addons' ),
					],
					'default'      => 'inherit',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
					'selectors'  => [
						'{{WRAPPER}} .title p' => 'font-weight: {{VALUE}};',
					],
				]
			);
			$this->end_controls_section();

			$this->start_controls_section(
				'section_subtitle',
				[
					'label'     => __( 'Subtitle Style', 'koganic-addons' ),
					'tab'       => Controls_Manager::TAB_CONTENT,
					'condition' => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'subtitle',
				[
					'label'       => __( 'Subtitle', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'label_block' => true,
					'placeholder' => __( 'Subtitle', 'koganic-addons' ),
					'condition'   => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subtitle_font_family',
				[
					'label'        => __( 'Font Family', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''        => __( 'Default', 'koganic-addons' ),
						'primary' => __( 'Font Primary', 'koganic-addons' ),
						'second'  => __( 'Font Second', 'koganic-addons' ),
					],
					'default'      => '',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subtitle_type',
				[
					'label'        => __( 'Subtitle Type', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''  => __( 'Default', 'koganic-addons' ),
						'1' => __( 'Background Opacity White', 'koganic-addons' ),
						'2' => __( 'Background Opacity Black', 'koganic-addons' ),
						'3' => __( 'Title Underline', 'koganic-addons' ),
						'4' => __( 'Title Hover', 'koganic-addons' ),
					],
					'default'      => '',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'subtitle_size',
				[
					'label'      => __( 'Subtitle Font Size', 'koganic-addons' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', 'rem' ],
					'range'      => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'selectors'  => [
						'{{WRAPPER}} .subtitle p' => 'font-size: {{SIZE}}{{UNIT}}',
					],
					'condition'  => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'subtitle_spacing',
				[
					'label'     => __( 'Letter Spacing', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min'  => - 5,
							'max'  => 10,
							'step' => 0.1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .subtitle p' => 'letter-spacing: {{SIZE}}{{UNIT}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subtitle_margin',
				[
					'label'     => __( 'Margin Top (px)', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min' => 0,
							'max' => 500,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .subtitle' => 'margin-top: {{SIZE}}{{UNIT}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subtitle_color',
				[
					'label'     => __( 'Subtitle Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .subtitle p' => 'color: {{VALUE}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subtitle_weight',
				[
					'label'        => __( 'Font Weight', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'inherit' => __( 'Default', 'koganic-addons' ),
						'300'     => __( 'Light', 'koganic-addons' ),
						'400'     => __( 'Regular', 'koganic-addons' ),
						'500'     => __( 'Medium', 'koganic-addons' ),
						'600'     => __( 'Semibold', 'koganic-addons' ),
						'700'     => __( 'Bold', 'koganic-addons' ),
						'800'     => __( 'Extra Bold', 'koganic-addons' ),
						'900'     => __( 'Black', 'koganic-addons' ),
					],
					'default'      => 'inherit',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
					'selectors'  => [
						'{{WRAPPER}} .subtitle p' => 'font-weight: {{VALUE}};',
					],
				]
			);

			$this->end_controls_section();

			$this->start_controls_section(
				'section_sub_subtitle',
				[
					'label'     => __( 'Sub-Subtitle Style', 'koganic-addons' ),
					'tab'       => Controls_Manager::TAB_CONTENT,
					'condition' => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'subsubtitle',
				[
					'label'       => __( 'Sub-Subtitle', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'label_block' => true,
					'placeholder' => __( 'Subtitle', 'koganic-addons' ),
					'condition'   => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subsubtitle_font_family',
				[
					'label'        => __( 'Font Family', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''        => __( 'Default', 'koganic-addons' ),
						'primary' => __( 'Font Primary', 'koganic-addons' ),
						'second'  => __( 'Font Second', 'koganic-addons' ),
					],
					'default'      => '',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subsubtitle_type',
				[
					'label'        => __( 'Sub-Subtitle Type', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''  => __( 'Default', 'koganic-addons' ),
						'1' => __( 'Background Opacity White', 'koganic-addons' ),
						'2' => __( 'Background Opacity Black', 'koganic-addons' ),
						'3' => __( 'Title Underline', 'koganic-addons' ),
						'4' => __( 'Title Hover', 'koganic-addons' ),
					],
					'default'      => '',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'subsubtitle_size',
				[
					'label'      => __( 'Sub-Subtitle Font Size', 'koganic-addons' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', 'rem' ],
					'range'      => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'selectors'  => [
						'{{WRAPPER}} .subsubtitle p' => 'font-size: {{SIZE}}{{UNIT}}',
					],
					'condition'  => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'subsubtitle_spacing',
				[
					'label'     => __( 'Letter Spacing', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min'  => - 5,
							'max'  => 10,
							'step' => 0.1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .subsubtitle p' => 'letter-spacing: {{SIZE}}{{UNIT}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subsubtitle_margin',
				[
					'label'     => __( 'Margin Top (px)', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min' => 0,
							'max' => 500,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .subsubtitle' => 'margin-top: {{SIZE}}{{UNIT}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subsubtitle_color',
				[
					'label'     => __( 'Sub-Subtitle Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .subsubtitle p' => 'color: {{VALUE}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'subsubtitle_weight',
				[
					'label'        => __( 'Font Weight', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'inherit' => __( 'Default', 'koganic-addons' ),
						'300'     => __( 'Light', 'koganic-addons' ),
						'400'     => __( 'Regular', 'koganic-addons' ),
						'500'     => __( 'Medium', 'koganic-addons' ),
						'600'     => __( 'Semibold', 'koganic-addons' ),
						'700'     => __( 'Bold', 'koganic-addons' ),
						'800'     => __( 'Extra Bold', 'koganic-addons' ),
						'900'     => __( 'Black', 'koganic-addons' ),
					],
					'default'      => 'inherit',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
					'selectors'  => [
						'{{WRAPPER}} .subsubtitle p' => 'font-weight: {{VALUE}};',
					],
				]
			);

			$this->end_controls_section();
			$this->start_controls_section(
				'section_buttons',
				[
					'label'     => __( 'Button text', 'koganic-addons' ),
					'tab'       => Controls_Manager::TAB_CONTENT,
					'condition' => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'btn_text',
				[
					'label'       => __( 'Button text', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'label_block' => true,
					'placeholder' => __( 'Button text', 'koganic-addons' ),
					'condition'   => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'btn_font_family',
				[
					'label'        => __( 'Font Family', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''        => __( 'Default', 'koganic-addons' ),
						'primary' => __( 'Font Primary', 'koganic-addons' ),
						'second'  => __( 'Font Second', 'koganic-addons' ),
					],
					'default'      => '',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'btn_link',
				[
					'label'       => __( 'Button link', 'koganic-addons' ),
					'type'        => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
					'default'     => [
						'url' => '#',
					],
					'condition'   => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'btn_size',
				[
					'label'      => __( 'Button Font Size', 'koganic-addons' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', 'rem' ],
					'range'      => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'selectors'  => [
						'{{WRAPPER}} .button-banner-wrapper .button-banner' => 'font-size: {{SIZE}}{{UNIT}}',
					],
					'condition'  => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'btn_spacing',
				[
					'label'     => __( 'Letter Spacing', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min'  => - 5,
							'max'  => 10,
							'step' => 0.1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .button-banner-wrapper .button-banner' => 'letter-spacing: {{SIZE}}{{UNIT}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'btn_margin',
				[
					'label'     => __( 'Margin Top (px)', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min' => 0,
							'max' => 500,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .button-banner-wrapper' => 'margin-top: {{SIZE}}{{UNIT}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'btn_weight',
				[
					'label'        => __( 'Font Weight', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'default' => __( 'Default', 'koganic-addons' ),
						'300'     => __( 'Light', 'koganic-addons' ),
						'400'     => __( 'Regular', 'koganic-addons' ),
						'500'     => __( 'Medium', 'koganic-addons' ),
						'600'     => __( 'Semibold', 'koganic-addons' ),
						'700'     => __( 'Bold', 'koganic-addons' ),
						'800'     => __( 'Extra Bold', 'koganic-addons' ),
						'900'     => __( 'Black', 'koganic-addons' ),
					],
					'default'      => '',
					'save_default' => true,
					'condition'    => [
						'content_form' => '1',
					],
				]
			);
			$this->start_controls_tabs( 'tabs_button_style' );
			$this->start_controls_tab(
				'tab_button_normal',
				[
					'label' => __( 'Normal', 'elementor' ),
				]
			);
			$this->add_control(
				'btn_color',
				[
					'label'     => __( 'Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .button-banner-wrapper .button-banner' => 'color: {{VALUE}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);

			$this->add_control(
				'btn_bgcolor',
				[
					'label'     => __( 'Background Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .button-banner-wrapper .button-banner' => 'background-color: {{VALUE}}',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);
			$this->end_controls_tab();
			$this->start_controls_tab(
				'tab_button_hover',
				[
					'label' => __( 'Hover', 'koganic-addons' ),
				]
			);
			$this->add_control(
				'btn_color_hover',
				[
					'label'     => __( 'Color Hover', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .button-banner-wrapper .button-banner:hover, {{WRAPPER}} .button-banner-wrapper .button-banner:focus' => 'color: {{VALUE}};',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'btn_bgcolor_hover',
				[
					'label'     => __( 'Background Color Hover', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .button-banner-wrapper .button-banner:hover, {{WRAPPER}} .button-banner-wrapper .button-banner:focus' => 'background-color: {{VALUE}};',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);
			$this->add_control(
				'btn_bdcolor_hover',
				[
					'label'     => __( 'Border Color Hover', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .button-banner-wrapper .button-banner:hover, {{WRAPPER}} .button-banner-wrapper .button-banner:focus' => 'border-color: {{VALUE}};',
					],
					'condition' => [
						'content_form' => '1',
					],
				]
			);
			$this->end_controls_tab();
			$this->end_controls_tabs();

			$this->add_responsive_control(
				'btn_padding',
				[
					'label'      => __( 'Padding', 'koganic-addons' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .button-banner-wrapper .button-banner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator'  => 'before',
				]
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name'      => 'btn_border',
					'selector'  => '{{WRAPPER}} .button-banner-wrapper .button-banner',
					'separator' => 'before',
				]
			);

			$this->add_control(
				'btn_border_radius',
				[
					'label'      => __( 'Border Radius', 'koganic-addons' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .button-banner-wrapper .button-banner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->end_controls_section();


			$this->start_controls_section(
				'section_positioning',
				[
					'label' => __( 'Positioning', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);
			$this->add_control(
				'box_align',
				[
					'label'        => __( 'Text Align', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''   => __( 'Left', 'koganic-addons' ),
						'tc' => __( 'Center', 'koganic-addons' ),
						'tr' => __( 'Right', 'koganic-addons' ),
					],
					'default'      => 'tl',
					'save_default' => true,
				]
			);
			$this->add_control(
				'vertical_alignment',
				[
					'label'        => __( 'Content vertical alignment', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						''       => __( 'Top', 'koganic-addons' ),
						'middle' => __( 'Middle', 'koganic-addons' ),
						'bottom' => __( 'Bottom', 'koganic-addons' ),
					],
					'save_default' => true,
				]
			);
			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();

			$this->add_render_attribute( 'wrapper', 'class', 'banner-box pr oh' );
			$this->add_render_attribute( 'text_wrapper', 'class', 'banner-text' );
			$this->add_render_attribute( 'title_class', 'class', 'title' );
			$this->add_render_attribute( 'subtitle_class', 'class', 'subtitle' );
			$this->add_render_attribute( 'subsubtitle_class', 'class', 'subsubtitle' );
			$this->add_render_attribute( 'button_class', 'class', 'button-banner-wrapper' );

			if ( isset( $settings['content_hidden'] ) && $settings['content_hidden'] == 'yes' ) {
				$this->add_render_attribute( 'wrapper', 'class', 'box-content-hidden' );
			}
			if ( ! empty( $settings['hover_effect'] ) ) {
				$this->add_render_attribute( 'wrapper', 'class', 'box-effect image-effect-' . esc_attr( $settings['hover_effect'] ) );
			}
			if ( ! empty( $settings['vertical_alignment'] ) ) {
				$this->add_render_attribute( 'wrapper', 'class', 'banner-vertical-' . esc_attr( $settings['vertical_alignment'] ) );
			}
			if ( ! empty( $settings['banner_style'] ) ) {
				$this->add_render_attribute( 'wrapper', 'class', 'banner-' . esc_attr( $settings['banner_style'] ) );
			}

			// box content

			if ( ! empty( $settings['box_align'] ) ) {
				$this->add_render_attribute( 'text_wrapper', 'class', esc_attr( $settings['box_align'] ) );
			}

			if ( ! empty( $settings['pr_promo_type'] ) ) {
				$this->add_render_attribute( 'text_wrapper', 'class', 'pr-promo-type' . esc_attr( $settings['pr_promo_type'] ) );
				$this->add_render_attribute( 'wrapper', 'class', 'box-type-' . esc_attr( $settings['pr_promo_type'] ) );
			} else {
				$this->add_render_attribute( 'text_wrapper', 'class', 'pr-promo-type' );
			}

			// Title style
			if ( '' !== $settings['title_type'] ) {
				$this->add_render_attribute( 'title_class', 'class', 'type-title-'.$settings['title_type'] );
			}

			if ( isset( $settings['title_font_family'] ) && '' !== $settings['title_font_family'] ) {
				$this->add_render_attribute( 'title_class', 'class', $settings['title_font_family'] . '-font' );
			}

			// SubTitle style
			if ( '' !== $settings['subtitle_type'] ) {
				$this->add_render_attribute( 'subtitle_class', 'class', 'type-title-'.$settings['subtitle_type'] );
			}

			if ( isset( $settings['subtitle_font_family'] ) && '' !== $settings['subtitle_font_family'] ) {
				$this->add_render_attribute( 'subtitle_class', 'class', $settings['subtitle_font_family'] . '-font' );
			}

			// SubsubTitle style
			if ( '' !== $settings['subsubtitle_type'] ) {
				$this->add_render_attribute( 'subsubtitle_class', 'class', 'type-title-'.$settings['subsubtitle_type'] );
			}

			if ( isset( $settings['subsubtitle_font_family'] ) && '' !== $settings['subsubtitle_font_family'] ) {
				$this->add_render_attribute( 'subsubtitle_class', 'class', $settings['subsubtitle_font_family'] . '-font' );
			}

			$has_image = ! ! $settings['image']['url'];

			$allowed_html   = array(
				'a'      => array(
					'href'  => array(),
					'title' => array()
				),
				'span'   => array(
					'class' => array()
				),
				'br'     => array(),
				'em'     => array(),
				'strong' => array(),
			);

			// Link
			$onclick = '';
			if ( ! empty( $settings['link']['url'] ) && !Plugin::$instance->editor->is_edit_mode() ) {
				$onclick = 'onclick="window.location.href=\''. esc_url( $settings['link']['url'] ).'\'"';
			}
			?>
            <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> <?php echo '' . $onclick; ?>>
				<?php if ( $has_image ) : ?>
                    <div class="banner-image item-effect">
						<?php
						$image_html = Group_Control_Image_Size::get_attachment_image_html( $settings, 'image' );
						echo $image_html;
						?>
                    </div>
				<?php endif; ?>

				<?php if ( $settings['content_form'] == '1' ): ?>
					<?php if ( ! empty( $settings['title'] ) || ! empty( $settings['subtitle'] ) || ! empty( $settings['subsubtitle'] ) || ! empty( $settings['btn_text'] ) ) : ?>
                        <div <?php echo $this->get_render_attribute_string( 'text_wrapper' ); ?>>
                            <div class="banner-inner content-width-<?php echo esc_attr( $settings['content_width'] ); ?>">
                                <div class="content-background"></div>
                                <div class="content">
									<?php
									if ( ! empty( $settings['title'] ) ) :
										$this->add_inline_editing_attributes( 'title', 'none' );
										?>
                                        <div <?php echo $this->get_render_attribute_string( 'title_class' ); ?>>
                                            <p <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo wp_kses( $settings['title'], $allowed_html ) ?></p>
                                        </div>
									<?php endif; ?>

									<?php
									if ( ! empty( $settings['subtitle'] ) ) :
										$this->add_inline_editing_attributes( 'subtitle', 'none' );
										?>
                                        <div <?php echo $this->get_render_attribute_string( 'subtitle_class' ); ?>>
                                            <p <?php echo $this->get_render_attribute_string( 'subtitle' ); ?>><?php echo wp_kses( $settings['subtitle'], $allowed_html ) ?></p>
                                        </div>
									<?php endif; ?>

									<?php
									if ( ! empty( $settings['subsubtitle'] ) ) :
										$this->add_inline_editing_attributes( 'subsubtitle', 'none' );
										?>
                                        <div <?php echo $this->get_render_attribute_string( 'subsubtitle_class' ); ?>>
                                            <p <?php echo $this->get_render_attribute_string( 'subsubtitle' ); ?>><?php echo wp_kses( $settings['subsubtitle'], $allowed_html ) ?></p>
                                        </div>
									<?php endif; ?>

									<?php
									if ( ! empty( $settings['btn_text'] ) ) :
										$this->add_render_attribute( 'btn_text', 'class', 'button-banner' );
										$this->add_link_attributes( 'btn_text', $settings['btn_link'] );
										$this->add_inline_editing_attributes( 'btn_text', 'none' );
										?>
                                        <div <?php echo $this->get_render_attribute_string( 'button_class' ); ?>>
                                            <a <?php echo $this->get_render_attribute_string( 'btn_text' ); ?>>
                                            	<span class="text"><?php echo esc_html( $settings['btn_text'] ); ?></span>
                                            	<i class="icon-arrow-right icons"></i>
                                            </a>
                                        </div>
									<?php endif; ?>
                                </div>
                            </div>
                        </div>
					<?php endif; ?>
				<?php else: ?>
                    <div <?php echo $this->get_render_attribute_string( 'text_wrapper' ); ?>>
                        <div class="banner-inner">
                            <div class="content-background"></div>
                            <?php
                            $editor_content = $this->get_settings_for_display( 'content' );
                            $editor_content = $this->parse_text_editor( $editor_content );
                            $this->add_render_attribute( 'content', 'class', 'content' );
                            $this->add_inline_editing_attributes( 'content', 'advanced' );
                            ?>
                            <div <?php echo $this->get_render_attribute_string( 'content' ); ?>><?php echo $editor_content; ?></div>
                        </div>
                    </div>
				<?php endif; ?>
            </div>
			<?php
		}

		public function render_plain_content() {
			echo $this->get_settings( 'content' );
		}

		protected function content_template() {
			?>
            <#
            view.addRenderAttribute( 'wrapper', 'class', 'banner-box pr oh' );
            view.addRenderAttribute( 'text_wrapper', 'class', 'banner-text' );
            view.addRenderAttribute( 'title_class', 'class', 'title' );
            view.addRenderAttribute( 'subtitle_class', 'class', 'subtitle' );
            view.addRenderAttribute( 'subsubtitle_class', 'class', 'subsubtitle' );
            view.addRenderAttribute( 'button_class', 'class', 'button-banner-wrapper' );

            if( settings.content_hidden && settings.content_hidden == 'yes' ){
                view.addRenderAttribute( 'wrapper', 'class', 'box-content-hidden' );
            }
            if( settings.hover_effect ){
                view.addRenderAttribute( 'wrapper', 'class', 'box-effect image-effect-'+settings.hover_effect );
            }
            if( settings.hover_effect ){
                view.addRenderAttribute( 'wrapper', 'class', 'box-effect image-effect-'+settings.hover_effect );
            }
            if( settings.vertical_alignment ){
                view.addRenderAttribute( 'wrapper', 'class', 'banner-vertical-'+settings.vertical_alignment );
            }
            if( settings.banner_style ){
                view.addRenderAttribute( 'wrapper', 'class', 'banner-'+settings.banner_style );
            }

            if( settings.box_align ){
                view.addRenderAttribute( 'text_wrapper', 'class', settings.box_align );
            }
            if( settings.pr_promo_type ){
                view.addRenderAttribute( 'text_wrapper', 'class', 'pr-promo-type'+settings.pr_promo_type );
            }else{
                view.addRenderAttribute( 'text_wrapper', 'class', 'pr-promo-type');
            }

            if( settings.title_type ){
                view.addRenderAttribute( 'title_class', 'class', 'type-title-'+settings.title_type );
            }
            if( settings.title_font_family ){
                view.addRenderAttribute( 'title_class', 'class', settings.title_font_family + '-font');
            }

            if( settings.subtitle_type ){
                view.addRenderAttribute( 'subtitle_class', 'class', 'type-title-'+settings.subtitle_type );
            }
            if( settings.subtitle_font_family ){
                view.addRenderAttribute( 'subtitle_class', 'class', settings.subtitle_font_family + '-font');
            }

            if( settings.subsubtitle_type ){
                view.addRenderAttribute( 'subsubtitle_class', 'class', 'type-title-'+settings.subsubtitle_type );
            }
            if( settings.subsubtitle_font_family ){
                view.addRenderAttribute( 'subsubtitle_class', 'class', settings.subsubtitle_font_family + '-font');
            }

            var image = {
                id: settings.image.id,
                url: settings.image.url,
                size: settings.image_size,
                dimension: settings.image_custom_dimension,
                model: view.getEditModel()
            };
            if ( settings.image.url ) {
            var image_url = elementor.imagesManager.getImageUrl( image );
            var imageHtml = '<img src="' + image_url + '" alt="' + settings.title + '"/>';
            }
            #>
            <div {{{ view.getRenderAttributeString( 'wrapper' ) }}}>
            <# if (  settings.image.url ) { #>
            <div class="banner-image item-effect">
                {{{ imageHtml }}}
            </div>
            <# } #>

            <# if (  settings.content_form && settings.content_form == '1' ) { #>
                <# if( settings.title || settings.subtitle || settings.subsubtitle || settings.btn_text ){ #>
                <div {{{ view.getRenderAttributeString( 'text_wrapper' ) }}}>
                    <div class="banner-inner content-width-{{ settings.content_width }}">
                        <div class="content-background"></div>
                        <div class="content">
                            <# if ( '' !== settings.title ) { view.addInlineEditingAttributes( 'title', 'none' ); #>
                                <div {{{ view.getRenderAttributeString('title_class' ) }}}>
                                    <p {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.title }}}</p>
                                </div>
                            <# } #>

                            <# if ( '' !== settings.subtitle ) { view.addInlineEditingAttributes( 'subtitle', 'none' ); #>
                                <div {{{ view.getRenderAttributeString('subtitle_class' ) }}}>
                                    <p {{{ view.getRenderAttributeString( 'subtitle' ) }}}>{{{ settings.subtitle }}}</p>
                                 </div>
                            <# } #>

                            <# if ( '' !== settings.subsubtitle ) { view.addInlineEditingAttributes( 'subsubtitle', 'none' ); #>
                                <div {{{ view.getRenderAttributeString( 'subsubtitle_class' ) }}}>
                                    <p {{{ view.getRenderAttributeString( 'subsubtitle' ) }}}>{{{ settings.subsubtitle }}}</p>
                                </div>
                            <# } #>

                            <# if ( '' !== settings.btn_text ) {
                                view.addInlineEditingAttributes( 'btn_text', 'none' );
                                view.addRenderAttribute( 'btn_text', 'class', 'button-banner' );
                                var target = settings.btn_link.is_external ? ' target="_blank"' : '';
                                var nofollow = settings.btn_link.nofollow ? ' rel="nofollow"' : '';
                            #>
                            <div {{{ view.getRenderAttributeString( 'button_class' ) }}}>
                                <a href="{{ settings.btn_link.url }}" {{ target }}{{ nofollow }} {{{ view.getRenderAttributeString( 'btn_text' ) }}}>{{{ settings.btn_text }}}</a>
                            </div>
                            <# } #>
                        </div>
                    </div>
                </div>
                <# } #>
            <#  }else{ #>
                <div {{{ view.getRenderAttributeString( 'text_wrapper' ) }}}>
                    <div class="banner-inner">
                        <div class="content-background"></div>
                        <#
                        view.addRenderAttribute( 'content', 'class', 'content' );
                        view.addInlineEditingAttributes( 'content', 'advanced' );
                        #>
                        <div {{{ view.getRenderAttributeString( 'content' ) }}}>{{{ settings.content }}}</div>
                    </div>
                </div>
            <# } #>
            </div>
			<?php
		}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Banner_Widget() );
}