<?php

namespace Elementor;
use Elementor\Core\Schemes;
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Title_Widget' ) ) {

	class Elementor_Title_Widget extends Widget_Base {

		public function get_name() {
			return 'jms_title';
		}

		public function get_title() {
			return __( 'Title', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-t-letter';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'placeholder' => __( 'Title', 'koganic-addons' ),
					'default' => __( 'Custom Title', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'title_font_family',
				[
					'label'   => __( 'Font Family', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						''        => __( 'Default', 'koganic-addons' ),
						'primary' => __( 'Font Primary', 'koganic-addons' ),
						'second'  => __( 'Font Second (Archivo)', 'koganic-addons' ),
						'third'  => __( 'Font Third (SVN Skill)', 'koganic-addons' ),
						'fourth'  => __( 'Font Fourth (SFUCenturySchoolbookBT)', 'koganic-addons' ),
					],
					'default' => '',
				]
			);
			$this->add_control(
				'title_type',
				[
					'label'   => __( 'Title Type', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						''        => __( 'Default', 'koganic-addons' ),
						'1' => __( 'Background Opacity White', 'koganic-addons' ),
						'2'  => __( 'Background Opacity Black', 'koganic-addons' ),
						'3'  => __( 'Border bottom', 'koganic-addons' ),
					],
					'default' => '',
				]
			);

			$this->add_control(
				'title_size',
				[
					'label'      => __( 'Font Size', 'koganic-addons' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em', 'rem' ],
					'range'      => [
						'px' => [
							'min' => 1,
							'max' => 200,
						],
					],
					'selectors'  => [
						'{{WRAPPER}} .title' => 'font-size: {{SIZE}}{{UNIT}}',
					],
				]
			);
			$this->add_control(
				'title_line_height',
				[
					'label' => __( 'Line Height', 'koganic-addons' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px', 'em' ],
					'selectors' => [
						'{{WRAPPER}} .title' => 'line-height: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'title_spacing',
				[
					'label'     => __( 'Letter Spacing', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min'  => - 5,
							'max'  => 10,
							'step' => 0.1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .title' => 'letter-spacing: {{SIZE}}{{UNIT}}',
					],
				]
			);
			$this->add_control(
				'title_margin',
				[
					'label'     => __( 'Margin Bottom', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min' => 0,
							'max' => 500,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
					],
				]
			);

			$this->add_control(
				'weight_button',
				[
					'label'        => __( 'Font Weight', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'inherit' => __( 'Default', 'koganic-addons' ),
						'300'     => __( 'Light', 'koganic-addons' ),
						'400'     => __( 'Regular', 'koganic-addons' ),
						'500'     => __( 'Medium', 'koganic-addons' ),
						'600'     => __( 'Semibold', 'koganic-addons' ),
						'700'     => __( 'Bold', 'koganic-addons' ),
						'800'     => __( 'Extra Bold', 'koganic-addons' ),
						'900'     => __( 'Black', 'koganic-addons' ),
					],
					'default'      => 'inherit',
					'save_default' => true,
					'selectors'  => [
						'{{WRAPPER}} .title' => 'font-weight: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'title_width',
				[
					'label'     => __( 'Width', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1920,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .title' => 'max-width: {{SIZE}}{{UNIT}}',
					],
				]
			);

			$this->add_control(
				'title_color',
				[
					'label'     => __( 'Title Color', 'koganic-addons' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .title' => 'color: {{VALUE}};',
					]
				]
			);

			$this->add_control(
				'title_align',
				[
					'label'        => __( 'Align', 'koganic-addons' ),
					'type'         => Controls_Manager::CHOOSE,
					'options' => [
						'left'    => [
							'title' => __( 'Left', 'koganic-addons' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'koganic-addons' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'koganic-addons' ),
							'icon' => 'eicon-text-align-right',
						],
					],
					'style_transfer' => true,
					'separator'  => 'before',
				]
			);

			$this->add_control(
				'title_use_theme_fonts',
				[
					'label'        => __( 'Use theme default font family?', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
					'description' => __( 'Use font family for title.', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'title_google_fonts',
				[
					'label' => __( 'Font Family', 'koganic-addons' ),
					'type' => Controls_Manager::FONT,
					'default' => "'Open Sans', sans-serif",
					'selectors' => [
						'{{WRAPPER}} .title' => 'font-family: {{VALUE}}',
					],
					'condition' => [
						'title_use_theme_fonts!' => 'yes',
					],
				]
			);

			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();

			$this->add_render_attribute( 'wrapper', 'class', 'addon-title' );

			if ( !empty( $settings['title_type'] )) {
				$this->add_render_attribute( 'wrapper', 'class', 'title-type-' . esc_attr($settings['title_type'])  );
			}
			if ( !empty( $settings['title_align'] )) {
				$this->add_render_attribute( 'wrapper', 'class', 'text-'. esc_attr($settings['title_align']) );
			}
			if ( !empty( $settings['title_font_family '] )) {
				$this->add_render_attribute( 'wrapper', 'class', esc_attr($settings['title_font_family ']).'-font' );
			}
			?>
			<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
				<?php
				$this->add_render_attribute( 'title', 'class', 'title' );
				$this->add_inline_editing_attributes( 'title', 'none' );

				?>
                <div class="line-wrap">
                    <span class="left-line"></span>
                    <h3 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html( $settings['title']); ?></h3>
                    <span class="right-line"></span>
                </div>
			</div>
			<?php
		}

		protected function content_template_() {
			?>
			<#
			view.addRenderAttribute( 'wrapper', 'class', 'addon-title' );
			view.addRenderAttribute( 'title', 'class', 'title' );
			view.addInlineEditingAttributes( 'title', 'none' );
			#>
			<div {{{ view.getRenderAttributeString( 'wrapper' ) }}}>
            <div class="line-wrap">
                <span class="left-line"></span>
			    <h3  {{{ view.getRenderAttributeString( 'title' ) }}} ></h3>
                <span class="right-line"></span>
            </div>
			</div>
			<?php
		}


	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Title_Widget() );
}