<?php

namespace Elementor;

use Elementor\Core\Schemes;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Pricing_Tables_Widget' ) ) {

	class Elementor_Pricing_Tables_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );
		}

		public function get_name() {
			return 'pricing_tables';
		}

		public function get_title() {
			return __( 'Pricing tables', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-price-table';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$repeater = new Repeater();

			$repeater->add_control(
				'name',
				[
					'label'       => __( 'Pricing plan name', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'price_value',
				[
					'label'       => __( 'Price value', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'price_suffix',
				[
					'label'       => __( 'Price suffix', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'default'     => 'per month',
					'description' => __( 'For example: per month', 'koganic-addons' )
				]
			);
			$repeater->add_control(
				'currency',
				[
					'label'       => __( 'Price currency', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'description' => __( 'For example: $', 'koganic-addons' )
				]
			);

			$repeater->add_control(
				'features_list',
				[
					'label'       => __( 'Featured list', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXTAREA,
					'rows'        => 5,
					'description' => __( 'Start each feature text from a new line', 'koganic-addons' )
				]
			);

			$repeater->add_control(
				'link',
				[
					'label'         => __( 'Button link', 'koganic-addons' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default'       => [
						'url'         => '',
						'is_external' => false,
						'nofollow'    => false,
					],
					'description'   => __( 'Enter URL if you want this box to have a link.', 'koganic-addons' ),
				]
			);

			$repeater->add_control(
				'button_label',
				[
					'label'       => __( 'Button label', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
				]
			);

			$repeater->add_control(
				'label',
				[
					'label'       => __( 'Label text', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'description' => __( 'For example: Best option!', 'koganic-addons' )
				]
			);

			$repeater->add_control(
				'label_color',
				[
					'label'       => __( 'Label color', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''       => '',
						'red'    => __( 'Red', 'koganic-addons' ),
						'green'  => __( 'Green', 'koganic-addons' ),
						'blue'   => __( 'Blue', 'koganic-addons' ),
						'yellow' => __( 'Yellow', 'koganic-addons' ),
					],
					'default'     => 'red',
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'best_option',
				[
					'label'        => __( 'Best option', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description' => __( 'If "YES" this table will be highlighted', 'koganic-addons' ),
				]
			);
			$repeater->add_control(
				'style',
				[
					'label'       => __( 'Style', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''       => '',
						'default'    => __( 'Default', 'koganic-addons' ),
						'no-background'  => __( 'No background', 'koganic-addons' ),
					],
					'default'     => 'default',
					'label_block' => true,
				]
			);

			$this->add_control(
				'pricing_tables',
				[
					'label'       => '',
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => [
						[
							'name' => __( 'Name', 'koganic-addons' ),
							'link'  => [],
                            'price_value' => 10,
                            'price_suffix' => 'per month',
                            'currency' => '$',
                            'features_list' => "Line 1\r\nLine 2",
                            'button_label' => __( 'Buy now', 'koganic-addons' ),
                            'label' => '',
                            'label_color' => 'red',
                            'style' => 'default'
						],
						[
							'name' => __( 'Name', 'koganic-addons' ),
							'link'  => [],
							'price_value' => 20,
							'price_suffix' => 'per month',
							'currency' => '$',
							'features_list' => "Line 1\r\nLine 2",
							'button_label' => __( 'Buy now', 'koganic-addons' ),
							'label' => 'HOT',
							'label_color' => 'red',
							'style' => 'default'
						],
						[
							'name' => __( 'Name', 'koganic-addons' ),
							'link'  => [],
							'price_value' => 30,
							'price_suffix' => 'per month',
							'currency' => '$',
							'features_list' => "Line 1\r\nLine 2",
							'button_label' => __( 'Buy now', 'koganic-addons' ),
							'label' => '',
							'label_color' => 'red',
							'style' => 'default'
						],
					],
					'title_field' => '{{{ name }}}',
				]
			);

			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			if ( ! $settings['pricing_tables'] ) {
				return;
			}
			$this->add_render_attribute( 'class', 'class', 'pricing-tables-wrapper' );
			?>
			<div <?php echo $this->get_render_attribute_string( 'class' ); ?> >
				<div class="pricing-tables">
					<?php
						if ( count( $settings['pricing_tables'] ) ) {
							foreach ( $settings['pricing_tables'] as $index => $item ) {
								$this->render_plan( $index, $item );
							}
						}
					?>
				</div>
			</div>
			<?php
		}

		private function render_plan( $index, $item ) {
		    $element_key = 'plan_class_'.$index;
			$this->add_render_attribute( $element_key, 'class', 'koganic-price-table' );
			if ( !empty( $item['label'] )) {
				$this->add_render_attribute( $element_key, 'class', 'price-with-label');
			}
			if ( !empty( $item['label_color'] )) {
				$this->add_render_attribute( $element_key, 'class', 'label-color-'.esc_attr($item['label_color']));
			}
			if ( !empty( $item['style'] )) {
				$this->add_render_attribute( $element_key, 'class', 'price-style-'. esc_attr($item['style']) );
			}
			if ( isset( $item['best_option'] ) && $item['best_option'] == 'yes') {
				$this->add_render_attribute( $element_key, 'class', 'actived');
			}
			$features = preg_split('/[\n\r]+/',trim($item['features_list']));
			?>
			<div <?php echo $this->get_render_attribute_string( $element_key ); ?> >
				<div class="koganic-plan">
					<div class="koganic-plan-name">
						<span class="koganic-plan-title"><?php echo esc_html($item['name']); ?></span>
					</div>
				</div>
				<div class="koganic-plan-inner">
					<?php if ( ! empty( $item['label'] ) ): ?>
						<div class="price-label"><span><?php echo esc_html($item['label']); ?></span></div>
					<?php endif ?>
					<div class="koganic-plan-price">
						<?php if ( $item['currency'] ): ?>
							<span class="koganic-price-currency">
								<?php echo esc_html($item['currency']); ?>
							</span>
						<?php endif ?>

						<?php if ( $item['price_value'] ): ?>
							<span class="koganic-price-value">
								<?php echo esc_html($item['price_value']); ?>
							</span>
						<?php endif ?>

						<?php if ( $item['price_suffix'] ): ?>
							<span class="koganic-price-suffix">
								<?php echo esc_html($item['price_suffix']); ?>
							</span>
						<?php endif ?>
					</div>
					<?php if ( !empty( $features[0] ) ): ?>
						<div class="koganic-plan-features">
							<?php foreach ($features as $value): ?>
								<div class="koganic-plan-feature">
									<?php
									$allowed_html = array(
										'a' => array(
											'href' => array(),
											'title' => array()
										),
										'br' => array(),
										'em' => array(),
										'strong' => array(),
									);

									echo wp_kses($value, $allowed_html);
									?>
								</div>
							<?php endforeach; ?>
						</div>
					<?php endif ?>
					<div class="koganic-plan-footer">
						<?php if ( $item['button_label'] ): ?>
                            <?php
							$link_key = 'link_' . $index;
							$this->add_render_attribute( $link_key, 'class', 'button price-plan-btn');
							if ( ! empty( $item['link']['url'] ) ) {
								$this->add_link_attributes( $link_key, $item['link'] );
							}
                            ?>
							<a <?php echo $this->get_render_attribute_string( $link_key ); ?> ><?php echo esc_html($item['button_label']); ?></a>
						<?php endif ?>
					</div>
				</div>
			</div>
			<?php
		}

		protected function content_template() {}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Pricing_Tables_Widget() );
}