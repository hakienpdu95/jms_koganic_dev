<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Googole_Map_Widget' ) ) {

	class Elementor_Googole_Map_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {

			parent::__construct( $data, $args );

			//$google_key = 'AIzaSyAUY-T_NsSduIoG2I5ER_q9FScsd7IAs5A';//koganic_get_option( 'google_map_api_key' );
			$google_key = koganic_get_option( 'google_map_api_key' );
            if(!empty($data['settings']['google_key'])){
                $google_key =  $data['settings']['google_key'];
            }
			if (!wp_script_is( 'script-handle', 'registered' )) {
				wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
            }
			if (!wp_script_is( 'google.map.api', 'registered' ) && $google_key) {
				wp_register_script( 'google.map.api', 'https://maps.google.com/maps/api/js?key=' . $google_key . '', array(), '', false );
            }
			if (!wp_script_is( 'maplace', 'registered' )) {
				wp_register_script( 'maplace', get_template_directory_uri() . '/assets/3rd-party/maplace/maplace.min.js', [ 'jquery' ], '1.0.0', true );
            }
		}

		public function get_script_depends() {
			return ['google.map.api','maplace','script-handle'];
		}

		public function get_name() {
			return 'google_map';
		}

		public function get_title() {
			return __( 'Google Map', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-google-maps';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);
			$this->add_control(
				'lat',
				[
					'label'       => __( 'Latitude (required)', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'label_block' => true,
                    'default' => '45.9',
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'lon',
				[
					'label'       => __( 'Longitude (required)', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'label_block' => true,
					'default' => '10.9',
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'google_key',
				[
					'label'       => __( 'Google API key (required)', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'label_block' => true,
					'description' => wp_kses( __( 'Obtain API key <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">here</a> to use our Google Map VC element.', 'koganic-addons' ), array(
						'a' => array(
							'href'   => array(),
							'target' => array()
						)
					) ),
					'default' => koganic_get_option( 'google_map_api_key' )
				]
			);
			$this->add_control(
				'zoom',
				[
					'label' => __( 'Zoom', 'elementor' ),
					'type' => Controls_Manager::SLIDER,
					'default' => [
						'size' => 15
					],
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 20,
						],
					],
					'description' => esc_html__( 'Zoom level when focus the marker 0 - 19', 'koganic-addons' ),
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'height',
				[
					'label'     => __( 'Height', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min'  => 1,
							'max'  => 2000,
							'step' => 1,
						],
					],
					'default'   => [
						'unit' => 'px',
						'size' => '400',
					],
					'selectors' => [
						'{{WRAPPER}} .google-map-container' => 'height: {{SIZE}}{{UNIT}}',
					],
				]
			);

			$this->add_control(
				'style_json',
				[
					'label' => __( 'Styles (JSON)', 'plugin-domain' ),
					'type' => Controls_Manager::CODE,
					'rows' => 10,
					'language' => 'json',
					'description' => wp_kses( __('Styled maps allow you to customize the presentation of the standard Google base maps, changing the visual display of such elements as roads, parks, and built-up areas.<br>
You can find more Google Maps styles on the website: <a target="_blank" href="http://snazzymaps.com/">Snazzy Maps</a>Just copy JSON code and paste it here.', 'koganic-addons'), array(
						'a' => array(
							'href' => array(),
							'target' => array()
						)
					) ),
                    'frontend_available' => true,
				]
			);

			$this->add_control(
				'scroll',
				[
					'label'        => __( 'Zoom with mouse wheel', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'content',
				[
					'label' => __( 'Content', 'koganic-addons' ),
					'type' => Controls_Manager::TEXTAREA,
					'rows' => 5,
					'placeholder' => __( 'Content', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'content_vertical',
				[
					'label'   => __( 'Content on the map vertical position', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						''       => __( 'Default', 'koganic-addons' ),
						'top'    => __( 'Top', 'koganic-addons' ),
						'middle' => __( 'Middle', 'koganic-addons' ),
						'bottom' => __( 'Bottom', 'koganic-addons' ),
					],
					'default' => '',
					'label_block' => true,
				]
			);

			$this->add_control(
				'content_horizontal',
				[
					'label'   => __( 'Content on the map horizontal position', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						''       => __( 'Default', 'koganic-addons' ),
						'left'   => __( 'Left', 'koganic-addons' ),
						'center' => __( 'Center', 'koganic-addons' ),
						'right'  => __( 'Right', 'koganic-addons' ),
					],
					'default' => '',
					'label_block' => true,
				]
			);

			$this->add_control(
				'content_width',
				[
					'label'     => __( 'Content width', 'koganic-addons' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => [
						'px' => [
							'min'  => 1,
							'max'  => 1920,
							'step' => 1,
						],
					],
					'default'   => [
						'unit' => 'px',
						'size' => '300',
					],
					'selectors' => [
						'{{WRAPPER}} .koganic-google-map-content' => 'max-width: {{SIZE}}{{UNIT}}',
					],
				]
			);

			$this->add_control(
				'google_icon',
				[
					'label' => __( 'Google icon', 'koganic-addons' ),
					'type' => Controls_Manager::HIDDEN,
					'default' => KOGANIC_URL . '/assets/images/google-icon.png',
					'frontend_available' => true,
				]
			);

			$this->end_controls_section();

		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			$this->add_render_attribute( 'class', 'class', 'jmsgooglemap-elements' );
			if ( !empty( $settings['content_vertical'] )) {
				$this->add_render_attribute( 'class', 'class', 'content-vertical-'. esc_attr($settings['content_vertical']) );
			}
			if ( !empty( $settings['content_horizontal'] )) {
				$this->add_render_attribute( 'class', 'class', 'content-horizontal-'. esc_attr($settings['content_horizontal']) );
			}
			if ( !empty( $settings['content'] )) {
				$this->add_render_attribute( 'class', 'class', 'map-container-with-content');
			}

			?>
            <div <?php echo $this->get_render_attribute_string( 'class' ); ?> >

                <div class="google-map-container">

                    <div class="koganic-google-map-wrapper">
                        <div class="koganic-google-map without-content google-map-<?php echo $this->get_id() ?>"></div>
                    </div>

                    <?php if($settings['content'] !== ''): ?>
                    <div class="koganic-google-map-content-wrap">
                        <div class="koganic-google-map-content">
                            <?php echo esc_html($settings['content']); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
			<?php
		}
		protected function content_template() {}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Googole_Map_Widget() );
}