<?php
namespace Elementor;

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Team_Widget' ) ) {

	class Elementor_Team_Widget extends Widget_Base {

		public function get_name() {
			return 'team';
		}

		public function get_title() {
			return __( 'Team Member', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-person';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}

		protected function _register_controls() {
			$this->start_controls_section(
				'content_section',
				[
					'label' => __( 'Content', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'name',
				[
					'label'       => __( 'Name', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'default'     =>  __( 'Name', 'koganic-addons' ),
					'label_block' => true,
					'placeholder' => __( 'User name', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'position',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'default'     =>  __( 'Position', 'koganic-addons' ),
					'label_block' => true,
					'placeholder' => __( 'User title', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'image',
				[
					'label'   => __( 'User Avatar', 'koganic-addons' ),
					'type'    => Controls_Manager::MEDIA,
					'dynamic' => [
						'active' => true,
					],
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
				]
			);
			$this->add_group_control(
				Group_Control_Image_Size::get_type(),
				[
					'name'      => 'thumbnail',
					'default'   => 'medium',
					'separator' => 'none',
				]
			);

			$this->add_control(
				'align',
				[
					'label'        => __( 'Align', 'koganic-addons' ),
					'type'         => Controls_Manager::CHOOSE,
					'default'      => 'center',
					'options' => [
						'left'    => [
							'title' => __( 'Left', 'koganic-addons' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'koganic-addons' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'koganic-addons' ),
							'icon' => 'eicon-text-align-right',
						],
					],
					'style_transfer' => true,
				]
			);

			$this->add_control(
				'koganic_color_scheme',
				[
					'label'   => __( 'Color Scheme', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'light' => 'Light',
						'dark'  => 'Dark',
					],
					'default' => 'dark',
				]
			);

			$this->add_control(
				'content',
				[
					'label'       => __( 'Text', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXTAREA,
					'dynamic'     => [
						'active' => true,
					],
					'default'     => '',
					'placeholder' => __( 'You can add some member bio here.', 'koganic-addons' ),
					'separator'   => 'none',
					'rows'        => 5,
				]
			);

			$this->add_control(
				'facebook',
				[
					'label'       => __( 'Facebook link', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'url',
					'placeholder' => __( 'Facebook', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'twitter',
				[
					'label'       => __( 'Twitter link', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'url',
					'placeholder' => __( 'Twitter', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'google_plus',
				[
					'label'       => __( 'Google+ link', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'url',
					'placeholder' => __( 'Google+', 'koganic-addons' ),
				]
			);
			$this->add_control(
				'linkedin',
				[
					'label'       => __( 'Linkedin link', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'url',
					'placeholder' => __( 'Linkedin', 'koganic-addons' ),
				]
			);
			$this->add_control(
				'skype',
				[
					'label'       => __( 'Skype link', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'url',
					'placeholder' => __( 'Skype', 'koganic-addons' ),
				]
			);
			$this->add_control(
				'instagram',
				[
					'label'       => __( 'Instagram link', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'url',
					'placeholder' => __( 'Instagram', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'layout',
				[
					'label'   => __( 'Layout', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'default' => 'Default',
						'hover'   => 'With hover',
					],
					'default' => 'default',
				]
			);

			$this->add_control(
				'size',
				[
					'label'   => __( 'Social buttons size', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'default'      => 'Default',
						'small' => 'Small',
						'large' => 'Large',
					],
					'default' => 'default',
				]
			);

			$this->add_control(
				'style',
				[
					'label'   => __( 'Social buttons style', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'default'            => 'Default',
						'colored'     => 'Colored',
						'colored-alt' => 'Colored alternative',
						'bordered'    => 'Bordered',
					],
					'default' => 'default',
				]
			);

			$this->add_control(
				'form',
				[
					'label'   => __( 'Social buttons form', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'circle' => 'Circle',
						'square' => 'Square',
					],
					'default' => 'circle',
				]
			);

			$this->end_controls_section();
		}
		protected function render_shortcode() {
			$settings = $this->get_settings_for_display();

			if ( ! $settings['image']['url'] && ! $settings['name']) {
				return;
			}
			if ( ! ! $settings['image']['url']){
				$image_html = Group_Control_Image_Size::get_attachment_image_html( $settings,'thumbnail', 'image' );
				$this->add_render_attribute( 'shortcode', 'image', $image_html);
            }

            if ( $settings['name'] ) {
                $this->add_render_attribute( 'shortcode', 'name', $settings['name'] );
            }

            if ( $settings['position'] ) {
                $this->add_render_attribute( 'shortcode', 'position', $settings['position'] );
            }

			if ( $settings['align'] ) {
				$this->add_render_attribute( 'shortcode', 'align', $settings['align'] );
			}

			if ( $settings['koganic_color_scheme'] ) {
				$this->add_render_attribute( 'shortcode', 'koganic_color_scheme', $settings['koganic_color_scheme'] );
			}

			if ( $settings['layout'] ) {
				$this->add_render_attribute( 'shortcode', 'layout', $settings['layout'] );
			}

			if ( $settings['style'] ) {
				$this->add_render_attribute( 'shortcode', 'style', $settings['style'] );
			}

			if ( $settings['size'] ) {
				$this->add_render_attribute( 'shortcode', 'size', $settings['size'] );
			}

			if ( $settings['form'] ) {
				$this->add_render_attribute( 'shortcode', 'form', $settings['form'] );
			}

            if ( $settings['facebook'] ) {
                $this->add_render_attribute( 'shortcode', 'facebook', $settings['facebook'] );
            }

            if ( $settings['twitter'] ) {
                $this->add_render_attribute( 'shortcode', 'twitter', $settings['twitter'] );
            }

            if ( $settings['linkedin'] ) {
                $this->add_render_attribute( 'shortcode', 'linkedin', $settings['linkedin'] );
            }

            if ( $settings['skype'] ) {
                $this->add_render_attribute( 'shortcode', 'skype', $settings['skype'] );
            }

            if ( $settings['google_plus'] ) {
                $this->add_render_attribute( 'shortcode', 'google_plus', $settings['google_plus'] );
            }

            if ( $settings['instagram'] ) {
                $this->add_render_attribute( 'shortcode', 'instagram', $settings['instagram'] );
            }

            echo do_shortcode( '[team_member ' . $this->get_render_attribute_string( 'shortcode' ) . ']' );


		}
        protected function render() {
	        $settings = $this->get_settings_for_display();
	        $this->add_render_attribute( 'wrapper', 'class', 'team-member' );
	        if ( $settings['layout'] ) {
		        $this->add_render_attribute( 'wrapper', 'class', 'member-layout-' . $settings['layout'] );
	        }
	        if ( $settings['koganic_color_scheme'] ) {
		        $this->add_render_attribute( 'wrapper', 'class', 'color-scheme-' . $settings['koganic_color_scheme'] );
	        }
	        if ( $settings['align'] ) {
		        $this->add_render_attribute( 'wrapper', 'class', 'text-' . $settings['align'] );
	        }

	        $has_name = ! ! $settings['name'];
	        $has_image = ! ! $settings['image']['url'];
	        $has_position = ! ! $settings['position'];
	        $has_content = ! ! $settings['content'];

	        $has_linkedin = ! ! $settings['linkedin'];
	        $has_twitter = ! ! $settings['twitter'];
	        $has_facebook = ! ! $settings['facebook'];
	        $has_skype = ! ! $settings['skype'];
	        $has_google_plus = ! ! $settings['google_plus'];
	        $has_instagram = ! ! $settings['instagram'];

	        if ( ! $has_image && ! $has_name) {
		        return;
	        }

	        ?>
            <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
		        <?php if ( $has_image ) : ?>
                    <div class="member-image-wrapper">
                        <div class="member-image">
					        <?php
					        $image_html = Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail','image' );
					        echo $image_html;
					        ?>
                        </div>
                    </div>
		        <?php endif; ?>
                <div class="member-details">
			        <?php if ( $has_name ) :
				        $this->add_render_attribute( 'name', 'class', 'member-name' );
				        $this->add_inline_editing_attributes( 'name', 'none' );
				        $team_name_html = $settings['name'];
				        ?>
                        <h4 <?php echo $this->get_render_attribute_string( 'name' ); ?>><?php echo $team_name_html; ?></h4>
			        <?php endif; ?>
			        <?php if ( $has_position ) :
				        $this->add_render_attribute( 'position', 'class', 'member-position' );
				        $this->add_inline_editing_attributes( 'position', 'none' );
				        $team_position_html = $settings['position'];
				        ?>
                        <span <?php echo $this->get_render_attribute_string( 'position' ); ?>><?php echo $team_position_html; ?></span>
			        <?php endif; ?>

			        <?php if ($has_linkedin || $has_twitter || $has_facebook || $has_skype  || $has_google_plus || $has_instagram ) : ?>
                        <div class="member-social">
                            <div class="koganic-social-icons flex icons-design-<?php echo esc_attr( $settings['style'] ); ?> icons-size-<?php echo esc_attr($settings['size'] ); ?> social-form-<?php echo esc_attr( $settings['form'] ); ?>">
						        <?php if ($has_facebook) :  ?>
                                    <div class="koganic-social-icon social-facebook"><a href="<?php echo esc_url( $settings['facebook'] ); ?>"><i class="fa fa-facebook"></i></a></div>
						        <?php endif; ?>
						        <?php if ($has_twitter) : ?>
                                    <div class="koganic-social-icon social-twitter"><a href="<?php echo esc_url( $settings['twitter'] ); ?>"><i class="fa fa-twitter"></i></a></div>
						        <?php endif; ?>
						        <?php if ($has_google_plus) : ?>
                                    <div class="koganic-social-icon social-google-plus"><a href="<?php echo esc_url( $settings['twitter'] ); ?>"><i class="fa fa-google-plus"></i></a></div>
						        <?php endif; ?>
						        <?php if ($has_linkedin) : ?>
                                    <div class="koganic-social-icon social-linkedin"><a href="<?php echo esc_url( $settings['linkedin'] ); ?>"><i class="fa fa-linkedin"></i></a></div>
						        <?php endif; ?>
						        <?php if ($has_skype) : ?>
                                    <div class="koganic-social-icon social-skype"><a href="<?php echo esc_url( $settings['skype'] ); ?>"><i class="fa fa-skype"></i></a></div>
						        <?php endif; ?>
						        <?php if ($has_instagram) : ?>
                                    <div class="koganic-social-icon social-instagram"><a href="<?php echo esc_url( $settings['instagram'] ); ?>"><i class="fa fa-instagram"></i></a></div>
						        <?php endif; ?>
                            </div>
                        </div>
			        <?php endif; ?>
                </div>
            </div>
	        <?php
        }

		protected function content_template() {
			?>
            <#
                var classes = [ 'team-member' ];
                if( settings.layout && settings.layout !== '' ){
                    classes.push('member-layout-' + settings.layout );
                }
                if( settings.koganic_color_scheme && settings.koganic_color_scheme !== '' ){
                    classes.push( 'color-scheme-' + settings.koganic_color_scheme );
                }

                if( settings.align && settings.align !== '' ){
                    classes.push( 'text-' + settings.align );
                }

                if ( settings.image.url ) {
                    var image = {
                        id: settings.image.id,
                        url: settings.image.url,
                        size: settings.thumbnail_size,
                        dimension: settings.thumbnail_custom_dimension,
                        model: view.getEditModel()
                    };

                    var image_url = elementor.imagesManager.getImageUrl( image );

                     var imageHtml = '<img src="' + image_url + '" alt="member"/>';
                }
                var social_style = settings.style ? 'icons-design-' + settings.style : 'icons-design-default';
                var social_size = settings.size ? 'icons-size-' + settings.size : 'icons-size-default';
                var social_form = settings.form ? 'social-form-' + settings.form : 'icons-form-circle';
            #>
            <div class="{{ classes.join(' ') }}">
                <# if ( image_url ) { #>
                <div class="member-image-wrapper">
                    <div class="member-image">
                        {{{ imageHtml }}}
                    </div>
                </div>
                <# } #>
                <div class="member-details">
                    <# if ( '' !== settings.name ) {
                        view.addRenderAttribute( 'name', 'class', 'member-name' );
                        view.addInlineEditingAttributes( 'name', 'none' );
                    #>
                        <h4 {{{ view.getRenderAttributeString( 'name' ) }}}>{{{ settings.name }}}</h4>
                    <# } #>

                    <# if ( '' !== settings.position ) {
                        view.addRenderAttribute( 'position', 'class', 'member-position' );
                        view.addInlineEditingAttributes( 'position', 'none' );
                    #>
                    <span {{{ view.getRenderAttributeString( 'position' ) }}}>{{{ settings.position }}}</span>
                    <# } #>
                </div>
                <div class="member-social">
                    <div class="koganic-social-icons flex {{ social_style}} {{ social_size }} {{ social_form }}">
                        <# if ( '' !== settings.facebook ) { #>
                        <div class="koganic-social-icon social-facebook"><a href="{{{ settings.facebook }}}"><i class="fa fa-facebook"></i></a></div>
                        <# } #>
                        <# if ( '' !== settings.twitter ) { #>
                        <div class="koganic-social-icon social-twitter"><a href="{{{ settings.twitter }}}"><i class="fa fa-twitter"></i></a></div>
                        <# } #>
                        <# if ( '' !== settings.google_plus ) { #>
                        <div class="koganic-social-icon social-google-plus"><a href="{{{ settings.google_plus }}}"><i class="fa fa-google-plus"></i></a></div>
                        <# } #>
                        <# if ( '' !== settings.linkedin ) { #>
                        <div class="koganic-social-icon social-linkedin"><a href="{{{ settings.linkedin }}}"><i class="fa fa-linkedin"></i></a></div>
                        <# } #>
                        <# if ( '' !== settings.skype ) { #>
                        <div class="koganic-social-icon social-skype"><a href="{{{ settings.skype }}}"><i class="fa fa-skype"></i></a></div>
                        <# } #>
                        <# if ( '' !== settings.instagram ) { #>
                        <div class="koganic-social-icon social-instagram"><a href="{{{ settings.instagram }}}"><i class="fa fa-instagram"></i></a></div>
                        <# } #>
                    </div>
                </div>
            </div>
			<?php
		}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Team_Widget() );
}