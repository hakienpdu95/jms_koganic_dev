<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Testimonial_Widget' ) ) {

	class Elementor_Testimonial_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );
			wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
		}

		public function get_script_depends() {
			return [ 'script-handle' ];
		}

		public function get_name() {
			return 'testimonials';
		}

		public function get_title() {
			return __( 'Testimonials', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-testimonial-carousel';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$repeater = new Repeater();


			$repeater->add_control(
				'title_star',
				[
					'label'        => __( 'Title star review', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'0' => __( '4 Star - Default', 'koganic-addons' ),
						'1' => __( '5 Star', 'koganic-addons' ),
					],
					'default'      => '1',
					'save_default' => true,
				]
			);

			$repeater->add_control(
				'title_review',
				[
					'label'       => __( 'Title Review', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'placeholder' => __( 'Title Review', 'koganic-addons' ),
				]
			);

			$repeater->add_control(
				'name',
				[
					'label'       => __( 'Name', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'placeholder' => __( 'User name', 'koganic-addons' ),
				]
			);

			$repeater->add_control(
				'title',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'placeholder' => __( 'User title', 'koganic-addons' ),
				]
			);

			$repeater->add_control(
				'image',
				[
					'label'       => __( 'User Avatar', 'koganic-addons' ),
					'type'        => Controls_Manager::MEDIA,
					'default'     => [
						'url' => Utils::get_placeholder_image_src(),
					],
					'description' => __( 'Select image from media library.', 'koganic-addons' ),
				]
			);
			$repeater->add_group_control(
				Group_Control_Image_Size::get_type(),
				[
					'name'      => 'thumbnail',
					'exclude'   => [ 'custom' ],
					'separator' => 'none',
				]
			);

			$repeater->add_control(
				'content',
				[
					'label'   => __( 'Text', 'koganic-addons' ),
					'type'    => Controls_Manager::WYSIWYG,
					'default' => '',
				]
			);

			$repeater->add_control(
				'content_position',
				[
					'label'        => __( 'Enable Top Position', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);

			$this->add_control(
				'testimonials',
				[
					'label'       => '',
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => $this->get_repeater_defaults(),
					'title_field' => '{{{ title_review }}}',
				]
			);

			$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'placeholder' => __( 'Title', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'layout',
				[
					'label'        => __( 'Layout', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'slider' => __( 'Slider', 'koganic-addons' ),
						'grid'   => __( 'Grid', 'koganic-addons' ),
					],
					'default'      => 'slider',
					'save_default' => true,
				]
			);

			$this->add_control(
				'style',
				[
					'label'        => __( 'Layout', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'standard' => __( 'Standard', 'koganic-addons' ),
						'boxed'    => __( 'Boxed', 'koganic-addons' ),
						'primary'  => __( 'Primary', 'koganic-addons' ),
					],
					'default'      => 'standard',
					'save_default' => true,
				]
			);

			$this->add_control(
				'align',
				[
					'label'          => __( 'Align', 'koganic-addons' ),
					'type'           => Controls_Manager::CHOOSE,
					'default'        => 'center',
					'options'        => [
						'left'   => [
							'title' => __( 'Left', 'koganic-addons' ),
							'icon'  => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'koganic-addons' ),
							'icon'  => 'eicon-text-align-center',
						],
						'right'  => [
							'title' => __( 'Right', 'koganic-addons' ),
							'icon'  => 'eicon-text-align-right',
						],
					],
					'style_transfer' => true,
				]
			);

			$gallery_columns = range( 1, 6 );
			$gallery_columns = array_combine( $gallery_columns, $gallery_columns );

			$this->add_control(
				'columns',
				[
					'label'     => __( 'Columns', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 3,
					'options'   => $gallery_columns,
					'condition' => [
						'layout' => 'grid',
					],
				]
			);


			$this->add_control(
				'color_text',
				[
					'label'        => __( 'Color Text', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'dark'  => __( 'Dark', 'koganic-addons' ),
						'light' => __( 'Light', 'koganic-addons' ),
					],
					'save_default' => true,
					'default'      => 'dark',
				]
			);

			$this->end_controls_section();

			$this->start_controls_section(
				'section_slider',
				[
					'label'     => __( 'Slider Setting', 'koganic-addons' ),
					'tab'       => Controls_Manager::TAB_CONTENT,
					'condition' => [
						'layout' => 'slider',
					],
				]
			);

			$this->add_control(
				'items_space',
				[
					'label'       => __( 'Item Spacing', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						0  => __( '0px', 'koganic-addons' ),
						10 => __( '10px', 'koganic-addons' ),
						20 => __( '20px', 'koganic-addons' ),
						30 => __( '30px', 'koganic-addons' ),
						40 => __( '40px', 'koganic-addons' ),
						50 => __( '50px', 'koganic-addons' ),
						60 => __( '60px', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 40,
				]
			);

			$this->add_control(
				'items_desktop',
				[
					'label'       => __( 'Items Show On Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on desktop', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
						6 => __( '6 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
					'condition'   => [
						'layout' => 'slider',
					],
				]
			);

			$this->add_control(
				'items_small_desktop',
				[
					'label'       => __( 'Items Show On Small Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
					'condition'   => [
						'layout' => 'slider',
					],
				]
			);

			$this->add_control(
				'items_tablet',
				[
					'label'       => __( 'Items Show On Tablet Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
					'condition'   => [
						'layout' => 'slider',
					],
				]
			);

			$this->add_control(
				'items_mobile',
				[
					'label'       => __( 'Items Show On Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
					'condition'   => [
						'layout' => 'slider',
					],
				]
			);

			$this->add_control(
				'items_small_mobile',
				[
					'label'       => __( 'Items Show On Small Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small mobile. Screen resolution of device < 445px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
					'condition'   => [
						'layout' => 'slider',
					],
				]
			);

			$this->add_control(
				'navigation',
				[
					'label'        => __( 'Enable Navigation', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'layout' => 'slider',
					],
				]
			);

			$this->add_control(
				'style_navigation',
				[
					'label'     => __( 'Arrow Styles', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'icon_arrow'     => __( 'Icon Arrow', 'koganic-addons' ),
						'icon_box_arrow' => __( 'Icon Arrow Box', 'koganic-addons' ),
					],
					'default'   => 'icon_arrow',
					'condition' => [
						'navigation' => 'yes',
					],
				]
			);

			$this->add_control(
				'pagination',
				[
					'label'        => __( 'Enable Dots Pagination', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => __( 'Enables autoplay mode', 'koganic-addons' ),
					'condition'    => [
						'layout' => 'slider',
					],

				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'        => __( 'Autoplay', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'layout' => 'slider',
					],
				]
			);

			$this->add_control(
				'loop',
				[
					'label'        => __( 'Loop', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'koganic-addons' ),
					'condition'    => [
						'layout' => 'slider',
					],
				]
			);

			$this->end_controls_section();
		}

		protected function get_repeater_defaults() {
			$placeholder_image_src = Utils::get_placeholder_image_src();

			return [
				[
					'title_review'   => __( 'Testimonial', 'koganic-addons' ),
					'content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'koganic-addons' ),
					'name'    => __( 'John Doe', 'koganic-addons' ),
					'title'   => __( 'CEO', 'koganic-addons' ),
					'image'   => [
						'url' => $placeholder_image_src,
					],
				],
				[
					'title_review'   => __( 'Testimonial', 'koganic-addons' ),
					'content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'koganic-addons' ),
					'name'    => __( 'John Doe', 'koganic-addons' ),
					'title'   => __( 'CEO', 'koganic-addons' ),
					'image'   => [
						'url' => $placeholder_image_src,
					],
				],
				[
					'title_review'   => __( 'Testimonial', 'koganic-addons' ),
					'content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'koganic-addons' ),
					'name'    => __( 'John Doe', 'koganic-addons' ),
					'title'   => __( 'CEO', 'koganic-addons' ),
					'image'   => [
						'url' => $placeholder_image_src,
					],
				],
			];
		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			if ( ! $settings['testimonials'] ) {
				return;
			}
			$this->add_render_attribute( 'class', 'class', "jmstestimonial-box" );
			$this->add_render_attribute( 'slider_class', 'class', "testimonials" );

			if ( ! empty( $settings['layout'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'testimonials-' . esc_attr( $settings['layout'] ) );
			}
			if ( ! empty( $settings['style'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'testimonials-style-' . esc_attr( $settings['style'] ) );
			}
			if ( ! empty( $settings['columns'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'testimonials-columns-' . esc_attr( $settings['columns'] ) );
			}
			if ( ! empty( $settings['align'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'testimonials-align-' . esc_attr( $settings['align'] ) );
			}
			if ( ! empty( $settings['color_text'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'testimonials-color-' . esc_attr( $settings['color_text'] ) );
			}
			if ( ! empty( $settings['style_navigation'] ) ) {
				$this->add_render_attribute( 'class', 'class', esc_attr( $settings['style_navigation'] ) );
			}
			if ( ! empty( $settings['layout'] ) && $settings['layout'] == 'slider' ) {
				$this->add_render_attribute( 'slider_class', 'class', [
					' owl-carousel',
					'owl-theme',
					'testimonials-carousel-' . $this->get_id()
				] );
			}
			$has_title = ! ! $settings['title'];


			$attr_slider  = array();
			if ( isset(  $settings['layout'] ) && $settings['layout'] == 'slider' ) {
				if ( ! empty( $settings['items_desktop'] ) ) {
					$attr_slider['itemDesktop'] = intval( $settings['items_desktop'] );
					$attr_slider['smartSpeed'] = 250;
				}

				if ( ! empty( $settings['items_small_desktop'] ) ) {
					$attr_slider['itemSmallDesktop'] = intval( $settings['items_small_desktop'] );
				}

				if ( ! empty( $settings['items_tablet'] ) ) {
					$attr_slider['itemTablet'] = intval( $settings['items_tablet'] );
				}

				if ( ! empty( $settings['items_mobile'] ) ) {
					$attr_slider['itemMobile'] = intval( $settings['items_mobile'] );
				}

				if ( ! empty( $settings['items_small_mobile'] ) ) {
					$attr_slider['itemSmallMobile'] =  intval( $settings['items_small_mobile'] );
				}

				if ( ! empty( $settings['items_space'] ) ) {
					$attr_slider['margin'] =  intval( $settings['items_space'] );
				}

				if ( isset( $settings['navigation'] ) && $settings['navigation'] == 'yes' ) {
					$attr_slider['navigation'] = true;
				} else {
					$attr_slider['navigation'] = false;
				}

				if ( isset( $settings['pagination'] ) && $settings['pagination'] == 'yes' ) {
					$attr_slider['pagination'] = true;
				} else {
					$attr_slider['pagination'] = false;
				}

				if ( isset( $settings['autoplay'] ) && $settings['autoplay'] == 'yes' ) {
					$attr_slider['autoplay'] = true;
				} else {
					$attr_slider['autoplay'] = false;
				}

				if ( isset( $settings['loop'] ) && $settings['loop'] == 'yes' ) {
					$attr_slider['loop'] = true;
				} else {
					$attr_slider['loop'] = false;
				}
			}
			if ( ! empty( $attr_slider ) ) {
				$attr_json = wp_json_encode( $attr_slider );
				$data_slider = function_exists( 'wc_esc_json' ) ? wc_esc_json( $attr_json ) : _wp_specialchars( $attr_json, ENT_QUOTES, 'UTF-8', true );
				$this->add_render_attribute( 'slider_class', 'data-carousel', $data_slider );
			}
			?>
            <div <?php echo $this->get_render_attribute_string( 'class' ); ?>>
            	<?php 
            		if(! empty( $settings['style'] ) && $settings['style'] == 'boxed') {
            			echo '<div class="box-icon-bulb"><div></div></div>';
            		}
            	?>

				<?php
				if ( $has_title ):
					$this->add_inline_editing_attributes( 'title', 'none' );
					?>
                    <div class="addon-title">
                        <h3 <?php echo $this->get_render_attribute_string( 'title' ); ?>><?php echo esc_html( $settings['title'] ); ?></h3>
                    </div>
				<?php endif; ?>

                <div <?php echo $this->get_render_attribute_string( 'slider_class' ); ?>>
					<?php
					if ( count( $settings['testimonials'] ) ) {
						foreach ( $settings['testimonials'] as $key => $testimonial ) {
							$this->render_testimonial( $key, $testimonial );
						}
					}
					?>
                </div>
            </div>
			<?php
		}

		private function render_testimonial( $index, $setting ) {
            ?>
            <div class="testimonial-box">
                <div class="pt-reviewsbox">
                    <div class="pt-reviewsbox-description">
                        <div class="pt-reviewsbox-title">
                            <?php if(!empty($setting['title_review'])): ?>
	                            <h5 class="pt-title"><?php echo esc_html( $setting['title_review'] ); ?></h5>
                            <?php endif; ?>
                            <div class="pt-rating">
		                        <?php if( $setting['title_star'] == 0 ) : ?>
                                    <i class="pt-star"></i>
                                    <i class="pt-star"></i>
                                    <i class="pt-star"></i>
                                    <i class="pt-star"></i>
                                    <i class="pt-star grey"></i>
		                        <?php else : ?>
                                    <i class="pt-star"></i>
                                    <i class="pt-star"></i>
                                    <i class="pt-star"></i>
                                    <i class="pt-star"></i>
                                    <i class="pt-star"></i>
		                        <?php endif; ?>
                            </div>
                        </div>
	                    <?php if ($setting['content_position'] !== 'yes'){ ?>
                            <div class="pt-content">
			                    <?php echo $setting['content']; ?>
                            </div>
	                    <?php } ?>
                    </div>
                    <div class="pt-reviewsbox-author">

                        <div class="pt-img">
			                <?php
			                $image_url = Group_Control_Image_Size::get_attachment_image_src( $setting['image']['id'], 'thumbnail', $setting );
			                if ( ! $image_url ) {
				                $image_url = $setting['image']['url'];
			                }
			                $image_html = '<img class="testimonial-avatar-image" src="' . esc_attr( $image_url ) . '" alt="' . esc_attr( Control_Media::get_image_alt( $setting ) ) . '" />';
			                ?>
			                <?php echo wp_kses( $image_html, array( 'img' => array('class' => true,'width' => true,'height' => true,'src' => true,'alt' => true) ) );?>
                        </div>

                        <div class="pt-title">
                            <strong>
				                <?php if ( $setting['name'] ): ?>
					                <?php echo esc_html( $setting['name'] ); ?>
				                <?php endif ?>
                            </strong><?php if ( $setting['title'] ): ?> <span><?php echo esc_html( $setting['title'] ); ?></span><?php endif ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php
		}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Testimonial_Widget() );
}