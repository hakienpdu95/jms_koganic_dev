<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Images_Preview_Widget' ) ) {

	class Elementor_Images_Preview_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );
		}

		public function get_name() {
			return 'images_preview';
		}

		public function get_title() {
			return __( 'Image Preview Grid', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-featured-image';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$repeater = new Repeater();

			$repeater->add_control(
				'title_preview',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
					'placeholder' => __( 'Title', 'koganic-addons' ),
				]
			);


			$repeater->add_control(
				'image_preview',
				[
					'label'       => __( 'Image', 'koganic-addons' ),
					'type'        => Controls_Manager::MEDIA,
					'default'     => [
						'url' => Utils::get_placeholder_image_src(),
					],
					'description' => __( 'Select image from media library.', 'koganic-addons' ),
				]
			);

			$repeater->add_group_control(
				Group_Control_Image_Size::get_type(),
				[
					'name'      => 'image_preview',
					'exclude'   => [ 'custom' ],
					'separator' => 'none',
					'default'   => 'full',
				]
			);

			$repeater->add_control(
				'link_preview',
				[
					'label'         => __( 'Link', 'koganic-addons' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default'       => [
						'url'         => '',
						'is_external' => false,
						'nofollow'    => false,
					],
				]
			);

			$this->add_control(
				'images_preview',
				[
					'label'       => '',
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => [
						[
							'title_preview' => __( '', 'koganic-addons' ),
							'link_preview'  => [],
							'image_preview' => [
								'url' => Utils::get_placeholder_image_src()
							],
						],
					],
					'title_field' => '{{{ title_preview }}}',
				]
			);

			$this->end_controls_section();

		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			if ( ! $settings['images_preview'] ) {
				return;
			}
			$this->add_render_attribute( 'class', 'class', ['preview-layout', 'pt-grid-col-6']);
			?>
			<div class="preview-layout-wrapper">
				<div <?php echo $this->get_render_attribute_string( 'class' ); ?>>
					<?php
					if ( count( $settings['images_preview'] ) ) {
						foreach ( $settings['images_preview'] as $index => $item ) {
							?>
							<div class="element-item">
								<?php
								$link_key = 'link_' . $index;
								$this->add_render_attribute( $link_key, 'class', 'preview-layout');
								if ( ! empty( $item['link_preview']['url'] ) ) {
									$this->add_link_attributes( $link_key, $item['link_preview'] );
								}

								$image_url = Group_Control_Image_Size::get_attachment_image_src( $item['image_preview']['id'], 'image_preview', $item );
								if ( ! $image_url ) {
									$image_url = $item['image_preview']['url'];
								}
								$image_html = '<img class="lazyload loaded" data-src="' . esc_attr( $image_url ) . '" src="' . esc_attr( $image_url ) . '" alt="' . esc_attr( $item['title_preview'] ) . '" data-was-processed="true"/>';

								$repeater_setting_key = $this->get_repeater_setting_key( 'title_preview', 'images_preview', $index );
								$this->add_inline_editing_attributes( $repeater_setting_key );
								?>
								<a <?php echo $this->get_render_attribute_string( $link_key ); ?>>
									<figure>
										<?php
											if ( $item['image_preview']['url'] ) {
												echo wp_kses( $image_html, array( 'img' => array('class' => true,'width' => true,'height' => true,'src' => true,'alt' => true,'data-*' => true,) ) );
											}
										?>
										<figcaption <?php echo $this->get_render_attribute_string( $repeater_setting_key  ); ?>><?php echo esc_html($item['title_preview']); ?></figcaption>
									</figure>
								</a>
							</div>
							<?php
						}
					}
					?>
				</div>
			</div>
			<?php
		}

		protected function content_template() {
			?>
			<#
			view.addRenderAttribute( 'class', 'class', 'preview-layout pt-grid-col-6' );
			#>
			<div class="preview-layout-wrapper">
				<# if ( settings.images_preview ) { #>
				<div {{{ view.getRenderAttributeString( 'class' ) }}}>

				<# _.each( settings.images_preview, function( item, index ) {
					var textKey = view.getRepeaterSettingKey( 'title_preview', 'images_preview', index );
					view.addInlineEditingAttributes( textKey );
					if ('' !== item.image_preview.url ) {
						var image = {
							id: item.image_preview.id,
							url: item.image_preview.url,
							size: item.image_preview_size,
							dimension: item.image_preview_custom_dimension,
							model: view.getEditModel()
						};
						var ImageUrl = elementor.imagesManager.getImageUrl( image );
					}
					#>
					<div class="element-item">
						<a href="{{ item.link_preview.url }}">
							<figure>
								<# if ( item.image_preview.url) { #>
								<img src="{{ ImageUrl }}"  alt="{{ item.title_preview }}"  class="lazyload loaded">
								<#	} #>
								<figcaption {{{ view.getRenderAttributeString( textKey ) }}}>{{{ item.title_preview }}}</figcaption>
							</figure>
						</a>
					</div>
				<# } ); #>
				</div>
				<#	} #>
			</div>
			<?php
		}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Images_Preview_Widget() );
}