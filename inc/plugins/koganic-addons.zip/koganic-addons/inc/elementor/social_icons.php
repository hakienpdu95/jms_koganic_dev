<?php

namespace Elementor;

use Elementor\Core\Schemes;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Social_Widget' ) ) {

	class Elementor_Social_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );
		}

		public function get_name() {
			return 'social';
		}

		public function get_title() {
			return __( 'Social icons', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-social-icons';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'title_social',
				[
					'label'       => __( 'Title Social', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'label_block' => true,
					'placeholder' => __( 'Title Social', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'facebook',
				[
					'label' => __( 'Facebook Link', 'koganic-addons' ),
					'type' => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default' => [
						'url' => '#',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);


			$this->add_control(
				'twitter',
				[
					'label' => __( 'Twitter link', 'koganic-addons' ),
					'type' => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default' => [
						'url' => '#',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);

			$this->add_control(
				'behance',
				[
					'label' => __( 'Behance link', 'koganic-addons' ),
					'type' => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default' => [
						'url' => '#',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);

			$this->add_control(
				'google_plus',
				[
					'label' => __( 'Google+ link', 'koganic-addons' ),
					'type' => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default' => [
						'url' => '#',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);

			$this->add_control(
				'linkedin',
				[
					'label' => __( 'Linkedin link', 'koganic-addons' ),
					'type' => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);

			$this->add_control(
				'skype',
				[
					'label' => __( 'Skype link', 'koganic-addons' ),
					'type' => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);


			$this->add_control(
				'instagram',
				[
					'label' => __( 'Instagram link', 'koganic-addons' ),
					'type' => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default' => [
						'url' => '#',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);

			$this->add_control(
				'pinterest',
				[
					'label' => __( 'Pinterest link', 'koganic-addons' ),
					'type' => Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'koganic-addons' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);

			$this->add_responsive_control(
				'align',
				[
					'label' => __( 'Text alignment', 'koganic-addons' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'koganic-addons' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'koganic-addons' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'koganic-addons' ),
							'icon' => 'eicon-text-align-right',
						],
					],
					'default' => 'left',
				]
			);

			$this->add_control(
				'style',
				[
					'label'        => __( 'Style', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'default' => __( 'Default', 'koganic-addons' ),
						'icon' => __( 'Icon', 'koganic-addons' ),
						'icon-background' => __( 'Background', 'koganic-addons' ),
						'icon-background-circle' => __( 'Background circle', 'koganic-addons' ),
						'icon-background-border' => __( 'Border', 'koganic-addons' ),
					],
					'default'      => 'default',
					'save_default' => true,
				]
			);

			$this->add_control(
				'size',
				[
					'label'        => __( 'Social size', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'default' => __( 'Default', 'koganic-addons' ),
						'small' => __( 'Small', 'koganic-addons' ),
						'medium' => __( 'Medium', 'koganic-addons' ),
						'large' => __( 'Large', 'koganic-addons' ),
					],
					'default'      => 'default',
					'save_default' => true,
				]
			);

			$this->add_control(
				'color',
				[
					'label'        => __( 'Social color', 'koganic-addons' ),
					'type'         => Controls_Manager::SELECT,
					'options'      => [
						'default' => __( 'Default', 'koganic-addons' ),
						'black' => __( 'Blạck', 'koganic-addons' ),
						'white' => __( 'White', 'koganic-addons' ),
						'primary' => __( 'Primary color', 'koganic-addons' ),
					],
					'default'      => 'default',
					'save_default' => true,
				]
			);

			$this->end_controls_section();

		}

		protected function render() {
			$settings = $this->get_settings_for_display();

			$this->add_render_attribute( 'class', 'class', 'koganic-social-icons flex' );

			if ( ! empty( $settings['align'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'icon-align-' . esc_attr( $settings['align'] ) );
			}
			if ( ! empty( $settings['style'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'icon-style-' . esc_attr( $settings['style'] ) );
			}
			if ( ! empty( $settings['size'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'icon-size-' . esc_attr( $settings['size'] ) );
			}
			if ( ! empty( $settings['color'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'icon-color-' . esc_attr( $settings['color'] ) );
			}

			$has_title = ! ! $settings['title_social'];
			$has_linkedin = ! ! $settings['linkedin']['url'];
			$has_twitter = ! ! $settings['twitter']['url'];
			$has_behance = ! ! $settings['behance']['url'];
			$has_facebook = ! ! $settings['facebook']['url'];
			$has_skype = ! ! $settings['skype']['url'];
			$has_google_plus = ! ! $settings['google_plus']['url'];
			$has_instagram = ! ! $settings['instagram']['url'];
			$has_pinterest = ! ! $settings['pinterest']['url'];

			 ?>
				<div class="koganic-social-box">
					<?php if ( $has_title ) :
						$this->add_render_attribute( 'title_social', 'class', 'koganic-social-box-title' );
						$this->add_inline_editing_attributes( 'title_social', 'none' );
						?>
						<div <?php echo $this->get_render_attribute_string( 'title_social' ); ?>><?php echo esc_html($settings['title_social']); ?></div>
					<?php endif; ?>
					<?php if ($has_linkedin || $has_twitter || $has_behance || $has_facebook || $has_skype  || $has_google_plus || $has_instagram || $has_pinterest) : ?>
					<div <?php echo $this->get_render_attribute_string( 'class' ); ?>>
						<?php
							if ($has_facebook) :
							$this->add_link_attributes( 'facebook', $settings['facebook'] );
						?>
							<div class="koganic-social-icon social-facebook">
								<a <?php echo $this->get_render_attribute_string( 'facebook' ); ?>><i class="fa fa-facebook-square"></i></a>
							</div>
						<?php endif; ?>
						<?php
							if ($has_twitter) :
							$this->add_link_attributes( 'twitter', $settings['twitter'] );
							?>
							<div class="koganic-social-icon social-twitter"><a <?php echo $this->get_render_attribute_string( 'twitter' ); ?>><i class="fa fa-twitter"></i></a></div>
						<?php endif; ?>

						<?php
							if ($has_behance) :
							$this->add_link_attributes( 'behance', $settings['behance'] );
							?>
							<div class="koganic-social-icon social-behance"><a <?php echo $this->get_render_attribute_string( 'behance' ); ?>><i class="fa fa-behance"></i></a></div>
						<?php endif; ?>

						<?php
							if ($has_google_plus) :
							$this->add_link_attributes( 'google_plus', $settings['google_plus'] );
							?>
							<div class="koganic-social-icon social-google-plus"><a <?php echo $this->get_render_attribute_string( 'google_plus' ); ?>><i class="fa fa-google-plus-square"></i></a></div>
						<?php endif; ?>

						<?php
							if ($has_linkedin) :
							$this->add_link_attributes( 'linkedin', $settings['linkedin'] );
							?>
							<div class="koganic-social-icon social-linkedin"><a <?php echo $this->get_render_attribute_string( 'linkedin' ); ?>><i class="fa fa-linkedin"></i></a></div>
						<?php endif; ?>

						<?php
						if ($has_skype) :
							$this->add_link_attributes( 'skype', $settings['skype'] );
							?>
							<div class="koganic-social-icon social-skype"><a <?php echo $this->get_render_attribute_string( 'skype' ); ?>><i class="fa fa-skype"></i></a></div>
						<?php endif; ?>

						<?php
							if ($has_instagram) :
							$this->add_link_attributes( 'instagram', $settings['instagram'] );
							?>
							<div class="koganic-social-icon social-instagram">
								<a <?php echo $this->get_render_attribute_string( 'instagram' ); ?>><i class="fa fa-instagram"></i></a>
							</div>
						<?php endif; ?>

						<?php
							if ($has_pinterest) :
							$this->add_link_attributes( 'pinterest', $settings['google_plus'] );
							?>
							<div class="koganic-social-icon social-pinterest">
								<a <?php echo $this->get_render_attribute_string( 'pinterest' ); ?>><i class="fa fa-pinterest-square"></i></a>
							</div>
						<?php endif; ?>
					</div>
					<?php endif; ?>
				</div>
			<?php
		}

		protected function content_template() {
			?>
			<#
			view.addRenderAttribute( 'class', 'class', 'koganic-social-icons flex' );
			if( settings.align && '' !== settings.align){
				view.addRenderAttribute( 'class', 'class', 'icon-align-'+settings.align );
			}
			if( settings.style && '' !== settings.style){
				view.addRenderAttribute( 'class', 'class', 'icon-style-'+settings.style );
			}
			if( settings.size && '' !== settings.size){
				view.addRenderAttribute( 'class', 'class', 'icon-size-'+settings.size );
			}
			if( settings.color && '' !== settings.color){
				view.addRenderAttribute( 'class', 'class', 'icon-color-'+settings.color );
			}
			#>
			<div class="koganic-social-box">
				<# if ( '' !== settings.title_social ) {
					view.addRenderAttribute( 'title_social', 'class', 'koganic-social-box-title' );
					view.addInlineEditingAttributes( 'title_social', 'none' );
				#>
					<div {{{ view.getRenderAttributeString( 'title_social' ) }}}>{{{ settings.title_social }}}</div>
				<# } #>
				<div {{{ view.getRenderAttributeString( 'class' ) }}}>
					<# if ( '' !== settings.facebook ) { #>
					<div class="koganic-social-icon social-facebook">
						<a  href="{{{ settings.facebook }}}">
							<i class="fa fa-facebook-square"></i>
						</a>
					</div>
					<# } #>
					<# if ( '' !== settings.twitter.url ) { #>
					<div class="koganic-social-icon social-twitter"><a href="{{{ settings.twitter.url }}}"><i class="fa fa-twitter"></i></a></div>
					<# } #>
					<# if ( '' !== settings.behance.url ) { #>
					<div class="koganic-social-icon social-behance"><a href="{{{ settings.behance.url }}}"><i class="fa fa-behance"></i></a></div>
					<# } #>					
					<# if ( '' !== settings.google_plus.url ) { #>
					<div class="koganic-social-icon social-google-plus"><a href="{{{ settings.google_plus.url }}}"><i class="fa fa-google-plus"></i></a></div>
					<# } #>
					<# if ( '' !== settings.linkedin.url ) { #>
					<div class="koganic-social-icon social-linkedin"><a href="{{{ settings.linkedin.url }}}"><i class="fa fa-linkedin"></i></a></div>
					<# } #>
					<# if ('' !== settings.skype.url ) { #>
					<div class="koganic-social-icon social-skype"><a href="{{{ settings.skype.url }}}"><i class="fa fa-skype"></i></a></div>
					<# } #>
					<# if ( '' !== settings.instagram.url ) { #>
						<div class="koganic-social-icon social-instagram">
							<a href="{{{ settings.instagram.url }}}"><i class="fa fa-instagram"></i></a>
						</div>
					<# } #>
					<# if ( '' !== settings.pinterest.url ) { #>
						<div class="koganic-social-icon social-pinterest">
							<a href="{{{ settings.pinterest.url }}}"><i class="fa fa-pinterest-square"></i></a>
						</div>
					<# } #>
				</div>
			</div>
			<?php
		}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Social_Widget() );
}