<?php

namespace Elementor;

use Elementor\Core\Schemes;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_Product_Tabs_Widget' ) ) {

	class Elementor_Product_Tabs_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );

			if ( ! wp_script_is( 'script-handle', 'registered' ) ) {
				wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
			}
		}

		public function get_script_depends() {
			return [ 'script-handle' ];
		}

		public function get_name() {
			return 'product_tabs';
		}

		public function get_title() {
			return __( 'Product Tabs', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-product-tabs';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}


		protected function _register_controls() {
			$product_cat = array();
			$terms = get_terms( 'product_cat' );
			if ( $terms && ! isset( $terms->errors ) ) {
				foreach ( $terms as $key => $value ) {
					$product_cat[$value->term_id] = $value->name;
				}
				reset($product_cat);
				$default_cat = key($product_cat);
			}

			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$repeater = new Repeater();
			$repeater->start_controls_tabs( 'tabs_repeater' );
			$repeater->start_controls_tab( 'general', [ 'label' => __( 'General', 'koganic-addons' ) ] );

			$repeater->add_control(
				'title',
				[
					'label'       => __( 'Title for the tab', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'product_design',
				[
					'label'   => __( 'Display', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'nocarousel' => __( 'No Carousel', 'koganic-addons' ),
						'carousel'   => __( 'Carousel', 'koganic-addons' ),
					],
					'default' => 'nocarousel',
				]
			);

			$repeater->add_control(
				'product_type',
				[
					'label'   => __( 'Display', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'all'      => __( 'All products', 'koganic-addons' ),
						'recent'   => __( 'Recent products', 'koganic-addons' ),
						'featured' => __( 'Featured products', 'koganic-addons' ),
						'sale'     => __( 'Sale products', 'koganic-addons' ),
						'selling'  => __( 'Best selling products', 'koganic-addons' ),
						'cat'      => __( 'Category', 'koganic-addons' ),
						'ids'      => __( 'List of IDs', 'koganic-addons' ),
					],
					'default' => 'all',
				]
			);
			$repeater->add_control(
				'orderby',
				[
					'label'     => __( 'Order By', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'title'         => __( 'Title', 'koganic-addons' ),
						'date'          => __( 'Date', 'koganic-addons' ),
						'ID'            => __( 'ID', 'koganic-addons' ),
						'author'        => __( 'Author', 'koganic-addons' ),
						'modified'      => __( 'Modified', 'koganic-addons' ),
						'rand'          => __( 'Random', 'koganic-addons' ),
						'comment_count' => __( 'Comment count', 'koganic-addons' ),
						'menu_order'    => __( 'Menu order', 'koganic-addons' ),
					],
					'default'   => 'title',
					'condition' => [
						'product_type' => array( 'all', 'featured', 'sale', 'rated', 'cat' ),
					],
				]
			);
			$repeater->add_control(
				'order',
				[
					'label'     => __( 'Order', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'ASC'  => __( 'Ascending', 'koganic-addons' ),
						'DESC' => __( 'Descending', 'koganic-addons' ),
					],
					'default'   => 'ASC',
					'condition' => [
						'product_type' => array( 'all', 'featured', 'sale', 'rated' ),
					],
				]
			);

			$repeater->add_control(
				'ids',
				[
					'label' => __( 'Products', 'koganic-addons' ),
					'type' => 'koganic',
					'options' => [],
					'autocomplete' => [
						'object' => 'post',
						'query' => [
							'post_type' => 'product',
						],
					],
					'label_block' => true,
					'multiple' => true,
					'condition' => [
						'product_type' => 'ids',
					],
				]
			);

			$repeater->add_control(
				'skus',
				[
					'type'      => Controls_Manager::HIDDEN,
					'condition' => [
						'product_type' => 'all',
					],
				]
			);

			$repeater->add_control(
				'cat_id',
				[
					'label'   => __( 'Product Category', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => $product_cat,
					'default' => $default_cat,
					'condition' => [
						'product_type' => 'cat',
					]
				]
			);
			$repeater->add_control(
				'total_items',
				[
					'label'       => __( 'Items per page', 'koganic-addons' ),
					'type'        => Controls_Manager::NUMBER,
					'min'         => 1,
					'max'         => 100,
					'step'        => 1,
					'default'     => 8,
					'description' => __( 'Number of items to show per page.', 'koganic-addons' ),
				]
			);
			$repeater->end_controls_tab();
			$repeater->start_controls_tab( 'design', [ 'label' => __( 'Design', 'koganic-addons' ) ] );

			$repeater->add_control(
				'loadmore_product',
				[
					'label'        => __( 'Enable Load more Product', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'product_design' => 'nocarousel',
					],
				]
			);
			$repeater->add_control(
				'type_product',
				[
					'label'   => __( 'Product Type', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'grid' => __( 'Grid', 'koganic-addons' ),
						'list' => __( 'List', 'koganic-addons' ),
					],
					'default' => 'grid',
				]
			);

			$repeater->add_control(
				'style_product',
				[
					'label'       => __( 'Product Style', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''  => __( 'Inherit', 'koganic-addons' ),
						'1' => __( 'Style 1', 'koganic-addons' ),
						'2' => __( 'Style 2', 'koganic-addons' ),
						'3' => __( 'Style 3', 'koganic-addons' ),
						'4' => __( 'Style 4', 'koganic-addons' ),
					],
					'default'     => '',
					'description' => __( 'Consult Designs in Theme Option >> Shop', 'koganic' ),
					'condition'   => [
						'type_product' => 'grid',
					],
				]
			);

			$repeater->add_control(
				'style_product_list',
				[
					'label'     => __( 'Product Style', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'list-1' => __( 'Style 1', 'koganic-addons' ),
						'list-2' => __( 'Style 2', 'koganic-addons' ),
					],
					'default'   => 'list-1',
					'condition' => [
						'type_product' => 'list',
					],
				]
			);

			$repeater->add_control(
				'style_thumb',
				[
					'label'   => __( 'Product Hover', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						''   => __( 'Inherit', 'koganic-addons' ),
						'1'  => __( 'Zoom', 'koganic-addons' ),
						'2'  => __( 'Move top to bottom', 'koganic-addons' ),
						'3'  => __( 'Move bottom to top', 'koganic-addons' ),
						'4'  => __( 'Move right to left', 'koganic-addons' ),
						'5'  => __( 'Move left to right', 'koganic-addons' ),
						'6'  => __( 'Move top left to right bottom', 'koganic-addons' ),
						'7'  => __( 'Move top right to bottom left', 'koganic-addons' ),
						'8'  => __( 'Move right bottom to top right', 'koganic-addons' ),
						'9'  => __( 'Move left bottom to top right', 'koganic-addons' ),
						'10' => __( 'Scale', 'koganic-addons' ),
						'11' => __( 'Scale rotate', 'koganic-addons' ),
						'12' => __( 'Skew Y rotate', 'koganic-addons' ),
						'13' => __( 'Skew X rotate', 'koganic-addons' ),
						'14' => __( 'Skew', 'koganic-addons' ),
					],
					'default' => '',
				]
			);

			$repeater->add_control(
				'product_spacing',
				[
					'label'     => __( 'Product spacing', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						0  => __( '0px', 'koganic-addons' ),
						10 => __( '10px', 'koganic-addons' ),
						20 => __( '20px', 'koganic-addons' ),
						30 => __( '30px', 'koganic-addons' ),
						40 => __( '40px', 'koganic-addons' ),
					],
					'default'   => 30,
					'condition' => [
						'product_design' => 'nocarousel',
					],
				]
			);

			$repeater->add_control(
				'columns',
				[
					'label'     => __( 'Columns', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'1' => __( '1 Column', 'koganic-addons' ),
						'2' => __( '2 Columns', 'koganic-addons' ),
						'3' => __( '3 Columns', 'koganic-addons' ),
						'4' => __( '4 Columns', 'koganic-addons' ),
						'5' => __( '5 Columns', 'koganic-addons' ),
						'6' => __( '6 Columns', 'koganic-addons' ),
					],
					'default'   => '4',
					'condition' => [
						'product_design' => 'nocarousel',
					],
				]
			);

			$repeater->add_control(
				'countdown',
				[
					'label'        => __( 'Enable countdown', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);

			$repeater->add_control(
				'countdown_title',
				[
					'label'       => __( 'Countdown Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Offer Will End Through', 'koganic-addons' ),
					'label_block' => true,
					'condition'   => [
						'countdown' => 'yes',
					],
				]
			);

			$repeater->add_control(
				'varition_woocommerce',
				[
					'label'        => __( 'Enable varition woocommerce', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);

			$repeater->end_controls_tab();
			$repeater->start_controls_tab( 'slider', [
                'label' => __( 'Slider', 'koganic-addons' ),
                'condition' => [
                    'product_design' => 'carousel',
                ],
            ] );
			$repeater->add_control(
				'slider_opacity',
				[
					'label'        => __( 'Enable Slider Opacity', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'number_of_rows',
				[
					'label'     => __( 'Number of row', 'koganic-addons' ),
					'type'      => Controls_Manager::NUMBER,
					'min'       => 1,
					'max'       => 20,
					'step'      => 1,
					'default'   => 1,
					'condition' => [
						'product_design' => 'carousel',
					],
				]
			);


			$repeater->add_control(
				'items_margin',
				[
					'label'     => __( 'Spacing between items', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						0  => __( '0px', 'koganic-addons' ),
						10 => __( '10px', 'koganic-addons' ),
						20 => __( '20px', 'koganic-addons' ),
						30 => __( '30px', 'koganic-addons' ),
						40 => __( '40px', 'koganic-addons' ),
					],
					'default'   => 30,
					'label_block' => true,
					'condition' => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'items_desktop',
				[
					'label'       => __( 'Items Show On Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on desktop', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
						6 => __( '6 Items', 'koganic-addons' ),
					],
					'default'     => 4,
					'label_block' => true,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'items_small_desktop',
				[
					'label'       => __( 'Items Show On Small Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
					],
					'default'     => 4,
					'label_block' => true,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'items_tablet',
				[
					'label'       => __( 'Items Show On Tablet Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
					],
					'default'     => 3,
					'label_block' => true,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'items_mobile',
				[
					'label'       => __( 'Items Show On Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'default'     => 1,
					'label_block' => true,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'items_small_mobile',
				[
					'label'       => __( 'Items Show On Small Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small mobile. Screen resolution of device < 445px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'navigation',
				[
					'label'        => __( 'Enable Navigation', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'style_navigation',
				[
					'label'     => __( 'Arrow Styles', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'icon_arrow'     => __( 'Icon Arrow', 'koganic-addons' ),
						'icon_box_arrow' => __( 'Icon Arrow Box', 'koganic-addons' ),
					],
					'default'   => 'icon_arrow',
					'condition' => [
						'navigation' => 'yes',
					],
				]
			);

			$repeater->add_control(
				'pagination',
				[
					'label'        => __( 'Enable Dots Pagination', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => __( 'Enables autoplay mode', 'koganic-addons' ),
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'autoplay',
				[
					'label'        => __( 'Autoplay', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);

			$repeater->add_control(
				'loop',
				[
					'label'        => __( 'Loop', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'koganic-addons' ),
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);
			$repeater->end_controls_tab();
			$repeater->end_controls_tabs();


			$this->add_control(
				'product_tabs',
				[
					'label'       => '',
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => [
                        [
                            'title' => __( 'Tab1', 'koganic-addons' )
                        ]
                    ]
				]
			);

			$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'label_block' => true,
				]
			);


			$this->add_control(
				'line_bottom',
				[
					'label'       => __( 'Line Bottom', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						'big'   => __( 'Big line under', 'koganic-addons' ),
						'small' => __( 'Small line under', 'koganic-addons' ),
						'right' => __( 'Big line on the right', 'koganic-addons' ),
						'none'  => __( 'None', 'koganic-addons' ),
					],
					'default'     => 'big',
					'label_block' => true,
				]
			);

			$this->add_control(
				'title_style',
				[
					'label'       => __( 'Align', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						'line'   => __( 'Aligned Line', 'koganic-addons' ),
						'left'   => __( 'Aligned Left', 'koganic-addons' ),
						'center' => __( 'Aligned Center', 'koganic-addons' ),
						'right'  => __( 'Aligned Right', 'koganic-addons' ),
					],
					'default'     => 'line',
					'label_block' => true,
				]
			);

			$this->add_control(
				'color',
				[
					'label'       => __( 'Title color', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						'default' => __( 'Default', 'koganic-addons' ),
						'primary' => __( 'Primary color', 'koganic-addons' ),
						'black'   => __( 'Black', 'koganic-addons' ),
						'white'   => __( 'White', 'koganic-addons' ),
					],
					'default'     => 'default',
					'label_block' => true,
				]
			);

			$this->add_control(
				'size',
				[
					'label'       => __( 'Title size', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						'small'       => __( 'Small', 'koganic-addons' ),
						'medium'      => __( 'Medium', 'koganic-addons' ),
						'large'       => __( 'Large', 'koganic-addons' ),
						'extra-large' => __( 'Extra Large', 'koganic-addons' ),
					],
					'default'     => 'small',
					'label_block' => true,
				]
			);
			
			$this->add_control(
				'style_tab',
				[
					'label'       => __( 'Layout tabs', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''       => __( 'Default', 'koganic-addons' ),
						'1'      => __( 'Line bottom', 'koganic-addons' ),
					],
					'default'     => '',
					'label_block' => true,
				]
			);

			$this->add_control(
				'link_see_all_now',
				[
					'label'       => __( 'Link See All Now', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( '#', 'koganic-addons' ),
					'label_block' => true,
					'condition'   => [
						'title_style' => 'left',
					],
				]
			);
			$this->add_control(
				'search',
				[
					'label'        => __( 'Show Search Form', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						//'product_design' => 'nocarousel',
					],
					'description' => __( 'Show if tab display type no nocarousel.', 'koganic-addons' ),
				]
			);
			$this->add_control(
				'filter',
				[
					'label'        => __( 'Show Filter', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						//'product_design' => 'nocarousel',
					],
					'description' => __( 'Show if tab display type nocarousel.', 'koganic-addons' ),
				]
			);

			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();
			if(! $settings['product_tabs'] ){
			    return;
            }
			$this->add_render_attribute( 'class', 'class', 'jmsproducttabs-elements' );
			$this->add_render_attribute( 'class', 'class', 'layout-' . esc_attr( $settings['style_tab'] ) );
			$this->add_render_attribute( 'title_class', 'class', 'addon-title' );

			if( ! empty( $settings['title_style'] ) && $settings['title_style'] == 'left' ) {
				if(! empty($settings['link_see_all_now'])) {
					$this->add_render_attribute( 'title_class', 'class', 't-flex' );
				}
			}

			if ( isset( $settings['filter'] ) && $settings['filter'] === 'yes' ) {
				$this->add_render_attribute( 'class', 'class', 'filter-active' );
            }
			
			if ( isset( $settings['search'] ) && $settings['search'] == 'yes' ) {
				$this->add_render_attribute( 'class', 'class', 'search-active' );
			}

			if ( ! empty( $settings['title_style'] ) ) {
				$this->add_render_attribute( 'class', 'class', 'tab-design-' . esc_attr( $settings['title_style'] ) );
			}
			if ( ! empty( $settings['color'] ) ) {
				$this->add_render_attribute( 'title_class', 'class', 'title-color-' . esc_attr( $settings['color'] ) );
			}
			if ( ! empty( $settings['size'] ) ) {
				$this->add_render_attribute( 'title_class', 'class', 'title-size-' . esc_attr( $settings['size'] ) );
			}
			if ( ! empty( $settings['line_bottom'] ) ) {
				$this->add_render_attribute( 'title_class', 'class', 'line-bottom-' . esc_attr( $settings['line_bottom'] ) );
			}
			?>
            <div <?php echo $this->get_render_attribute_string( 'class' ); ?> >
                <div class="jms-tabs-title<?php if ( !empty($settings['title']) ) echo ' no-tabs-name'; ?>">
                    <div class="koganic-tabs-header">
		                <?php if ( !empty($settings['title'])): ?>
                            <div <?php echo $this->get_render_attribute_string( 'title_class' ); ?>>
                                <h3 class="title"><?php echo esc_html($settings['title']); ?></h3>

                                <?php if( ! empty( $settings['title_style'] ) && $settings['title_style'] == 'left' ) : 
                                	if(! empty($settings['link_see_all_now'])) {
                                ?>
                                	<p><a href="<?php echo esc_url( $settings['link_see_all_now'] ); ?>"><?php echo esc_html_e('See All Now', 'koganic-addons'); ?></a></p>
                                <?php } endif; ?>
                            </div>
		                <?php endif; ?>
                        <div class="tabs-navigation-wrapper">
                            <ul class="tab-title">
                                <?php
                                    $i = 0;
                                    foreach ( $settings['product_tabs'] as $tab ) {
	                                    $i++;
	                                    if( $i == 1 && isset( $tab['title'] ) ) $first_tab_title = $tab['title'];
	                                    $class = ( $i == 1 ) ? 'active' : '';
	                                    $attr_json = wp_json_encode( $tab );
	                                    $encoded_atts = function_exists( 'wc_esc_json' ) ? wc_esc_json( $attr_json ) : _wp_specialchars( $attr_json, ENT_QUOTES, 'UTF-8', true );
	                                    if ( isset( $tab['title'] ) ) {
		                                    echo '<li class="'. esc_attr( $class ) .'" data-atts="'. esc_attr( $encoded_atts ) .'"><span class="tab-label">' . $tab['title'] . '</span></li>';
	                                    }
                                    }
                                ?>
                            </ul>
                        </div>
                        <?php if($settings['search'] == 'yes'): ?>
                        <div class="koganic-tabs-search">
                            <form method="get" class="koganic-search-form" action="<?php echo esc_url( home_url( '/'  ) ) ?>">
                                <input type="text" name="s" class="koganic-search" placeholder="<?php esc_attr_e('Search products...','koganic-addons') ?>">
                            </form>
                        </div>
                        <?php endif; ?>
			            <?php if($settings['filter'] == 'yes'): ?>
                        <div class="koganic-tabs-filter">
                            <a href="javascript:void(0)" data-toggle="collapse" data-target="#filter-toggle-<?php esc_attr_e($this->get_id()); ?>" class="filter-toggle collapsed"><span><?php esc_html_e('Filter', 'koganic-addons'); ?></span></a>
                        </div>
			            <?php endif; ?>
                    </div>
                </div>
			    <?php if($settings['filter'] == 'yes'): ?>
                <div class="product-tab-action collapse" id="filter-toggle-<?php esc_attr_e($this->get_id()); ?>" >
                    <div class="filter-wrapper flex between-xs">
	                    <?php dynamic_sidebar( 'koganic-product-filter' ); ?>
                    </div>
                </div>
			    <?php endif; ?>
                <div class="koganic-products-tab-loader loading"></div>
                <div class="product-tab-content">
                    <?php
                        $first_tab_atts =  $settings['product_tabs'][0];
                        if ( Plugin::$instance->editor->is_edit_mode() ) {
	                        $first_tab_atts['not_ajax'] = 'yes';
                        }
                        $this->add_render_attribute( 'shortcode', $first_tab_atts );
                        $shortcode = sprintf( '[jms_products %s]', $this->get_render_attribute_string( 'shortcode' ) );
                        echo do_shortcode( $shortcode);
                    ?>
                </div>
            </div>
			<?php
		}

		protected function content_template() {
		}
	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Product_Tabs_Widget() );
}