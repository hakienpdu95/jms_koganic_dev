<?php
namespace Elementor;

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;
if ( ! class_exists( 'Elementor_Product_Widget' ) ) {

	class Elementor_Product_Widget extends Widget_Base {

		public function __construct( $data = [], $args = null ) {
			parent::__construct( $data, $args );

			if ( ! wp_script_is( 'script-handle', 'registered' ) ) {
				wp_register_script( 'script-handle', KOGANIC_ADDONS_URL . 'assets/js/theme-elementor.js', [ 'elementor-frontend' ], '1.0.0', true );
			}
		}

		public function get_script_depends() {
			return [ 'script-handle' ];
		}
		
		public function get_name() {
			return 'product';
		}

		public function get_title() {
			return __( 'Products (grid or carousel)', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-products';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}

		protected function _register_controls() {
			$product_cat = array();
			$terms = get_terms( 'product_cat' );
			if ( $terms && ! isset( $terms->errors ) ) {
				foreach ( $terms as $key => $value ) {
					$product_cat[$value->term_id] = $value->name;
				}
				reset($product_cat);
				$default_cat = key($product_cat);
		    }
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'product_design',
				[
					'label'   => __( 'Display', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'nocarousel' => __( 'No Carousel', 'koganic-addons' ),
						'carousel'   => __( 'Carousel', 'koganic-addons' ),
					],
					'default' => 'nocarousel',
				]
			);

			$this->add_control(
				'product_type',
				[
					'label'   => __( 'Display', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'all'      => __( 'All products', 'koganic-addons' ),
						'recent'   => __( 'Recent products', 'koganic-addons' ),
						'featured' => __( 'Featured products', 'koganic-addons' ),
						'sale'     => __( 'Sale products', 'koganic-addons' ),
						'selling'  => __( 'Best selling products', 'koganic-addons' ),
						'cat'      => __( 'Category', 'koganic-addons' ),
						'ids'      => __( 'List of IDs', 'koganic-addons' ),
					],
					'default' => 'all',
				]
			);

			$this->add_control(
				'orderby',
				[
					'label'     => __( 'Order By', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'title'         => __( 'Title', 'koganic-addons' ),
						'date'          => __( 'Date', 'koganic-addons' ),
						'ID'            => __( 'ID', 'koganic-addons' ),
						'author'        => __( 'Author', 'koganic-addons' ),
						'modified'      => __( 'Modified', 'koganic-addons' ),
						'rand'          => __( 'Random', 'koganic-addons' ),
						'comment_count' => __( 'Comment count', 'koganic-addons' ),
						'menu_order'    => __( 'Menu order', 'koganic-addons' ),
					],
					'default'   => 'title',
					'condition' => [
						'product_type' => array( 'all', 'featured', 'sale', 'rated', 'cat' ),
					],
				]
			);

			$this->add_control(
				'order',
				[
					'label'     => __( 'Order', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'ASC'  => __( 'Ascending', 'koganic-addons' ),
						'DESC' => __( 'Descending', 'koganic-addons' ),
					],
					'default'   => 'ASC',
					'condition' => [
						'product_type' => array( 'all', 'featured', 'sale', 'rated' ),
					],
				]
			);
			$this->add_control(
				'ids',
				[
					'label' => __( 'Products', 'koganic-addons' ),
					'type' => 'koganic',
					'options' => [],
					'autocomplete' => [
						'object' => 'post',
						'query' => [
							'post_type' => 'product',
						],
					],
					'label_block' => true,
					'multiple' => true,
					'condition' => [
						'product_type' => 'ids',
					],
				]
			);

			$this->add_control(
				'skus',
				[
					'type'      => Controls_Manager::HIDDEN,
					'condition' => [
						'product_type' => 'all',
					],
				]
			);

			$this->add_control(
				'cat_id',
				[
					'label'   => __( 'Product Category', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => $product_cat,
					'default' => $default_cat,
					'condition' => [
						'product_type' => 'cat',
					]
				]
			);
			$this->add_control(
				'total_items',
				[
					'label'       => __( 'Items per page', 'koganic-addons' ),
					'type'        => Controls_Manager::NUMBER,
					'min'         => 1,
					'max'         => 100,
					'step'        => 1,
					'default'     => 8,
					'description' => __( 'Number of items to show per page.', 'koganic-addons' ),
				]
			);


			$this->end_controls_section();

			$this->start_controls_section(
				'section_design_options',
				[
					'label' => __( 'Design', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_SETTINGS,
				]
			);

			$this->add_control(
				'loadmore_product',
				[
					'label'        => __( 'Enable Load more Product', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'product_design' => 'nocarousel',
					],
				]
			);

			$this->add_control(
				'type_product',
				[
					'label'   => __( 'Product Type', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						'grid' => __( 'Grid', 'koganic-addons' ),
						'list' => __( 'List', 'koganic-addons' ),
					],
					'default' => 'grid',
				]
			);

			$this->add_control(
				'style_product',
				[
					'label'       => __( 'Product Style', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'options'     => [
						''  => __( 'Inherit', 'koganic-addons' ),
						'1' => __( 'Style 1', 'koganic-addons' ),
						'2' => __( 'Style 2', 'koganic-addons' ),
						'3' => __( 'Style 3', 'koganic-addons' ),
						'4' => __( 'Style 4', 'koganic-addons' ),
						'5' => __( 'Style 5', 'koganic-addons' ),
						'6' => __( 'Style 6', 'koganic-addons' ),
					],
					'default'     => '',
					'description' => __( 'Consult Designs in Theme Option >> Shop', 'koganic' ),
					'condition'   => [
						'type_product' => 'grid',
					],
				]
			);

			$this->add_control(
				'style_product_list',
				[
					'label'     => __( 'Product Style', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'list-1' => __( 'Style 1', 'koganic-addons' ),
						'list-2' => __( 'Style 2', 'koganic-addons' ),
					],
					'default'   => 'list-1',
					'condition' => [
						'type_product' => 'list',
					],
				]
			);

			$this->add_control(
				'style_thumb',
				[
					'label'   => __( 'Product Hover', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => [
						''   => __( 'Inherit', 'koganic-addons' ),
						'1'  => __( 'Zoom', 'koganic-addons' ),
						'2'  => __( 'Move top to bottom', 'koganic-addons' ),
						'3'  => __( 'Move bottom to top', 'koganic-addons' ),
						'4'  => __( 'Move right to left', 'koganic-addons' ),
						'5'  => __( 'Move left to right', 'koganic-addons' ),
						'6'  => __( 'Move top left to right bottom', 'koganic-addons' ),
						'7'  => __( 'Move top right to bottom left', 'koganic-addons' ),
						'8'  => __( 'Move right bottom to top right', 'koganic-addons' ),
						'9'  => __( 'Move left bottom to top right', 'koganic-addons' ),
						'10' => __( 'Scale', 'koganic-addons' ),
						'11' => __( 'Scale rotate', 'koganic-addons' ),
						'12' => __( 'Skew Y rotate', 'koganic-addons' ),
						'13' => __( 'Skew X rotate', 'koganic-addons' ),
						'14' => __( 'Skew', 'koganic-addons' ),
					],
					'default' => '',
				]
			);

			$this->add_control(
				'product_spacing',
				[
					'label'     => __( 'Product spacing', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						0  => __( '0px', 'koganic-addons' ),
						10 => __( '10px', 'koganic-addons' ),
						20 => __( '20px', 'koganic-addons' ),
						30 => __( '30px', 'koganic-addons' ),
						40 => __( '40px', 'koganic-addons' ),
					],
					'default'   => 30,
					'condition' => [
						'product_design' => 'nocarousel',
					],
				]
			);

			$this->add_control(
				'columns',
				[
					'label'     => __( 'Columns', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'1' => __( '1 Column', 'koganic-addons' ),
						'2' => __( '2 Columns', 'koganic-addons' ),
						'3' => __( '3 Columns', 'koganic-addons' ),
						'4' => __( '4 Columns', 'koganic-addons' ),
						'5' => __( '5 Columns', 'koganic-addons' ),
						'6' => __( '6 Columns', 'koganic-addons' ),
					],
					'default'   => '4',
					'condition' => [
						'product_design' => 'nocarousel',
					],
				]
			);

			$this->add_control(
				'countdown',
				[
					'label'        => __( 'Enable countdown', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);

			$this->add_control(
				'countdown_title',
				[
					'label'       => __( 'Countdown Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Offer Will End Through', 'koganic-addons' ),
					'label_block' => true,
					'condition'   => [
						'countdown' => 'yes',
					],
				]
			);

			$this->add_control(
				'varition_woocommerce',
				[
					'label'        => __( 'Enable varition woocommerce', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
				]
			);

			$this->end_controls_section();

			$this->start_controls_section(
				'section_slider_options',
				[
					'label'     => __( 'Slider', 'koganic-addons' ),
					'tab'       => Controls_Manager::TAB_SETTINGS,
					'condition' => [
						'product_design' => 'carousel',
					],
				]
			);
			$this->add_control(
				'slider_opacity',
				[
					'label'        => __( 'Enable Slider Opacity', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'number_of_rows',
				[
					'label'     => __( 'Number of row', 'koganic-addons' ),
					'type'      => Controls_Manager::NUMBER,
					'min'       => 1,
					'max'       => 20,
					'step'      => 1,
					'default'   => 1,
					'condition' => [
						'product_design' => 'carousel',
					],
				]
			);


			$this->add_control(
				'items_margin',
				[
					'label'     => __( 'Spacing between items', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						0  => __( '0px', 'koganic-addons' ),
						10 => __( '10px', 'koganic-addons' ),
						20 => __( '20px', 'koganic-addons' ),
						30 => __( '30px', 'koganic-addons' ),
						40 => __( '40px', 'koganic-addons' ),
					],
					'default'   => 30,
					'condition' => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'items_desktop',
				[
					'label'       => __( 'Items Show On Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on desktop', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
						5 => __( '5 Items', 'koganic-addons' ),
						6 => __( '6 Items', 'koganic-addons' ),
					],
					'default'     => 4,
					'label_block' => true,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'items_small_desktop',
				[
					'label'       => __( 'Items Show On Small Desktop', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
						4 => __( '4 Items', 'koganic-addons' ),
					],
					'default'     => 4,
					'label_block' => true,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'items_tablet',
				[
					'label'       => __( 'Items Show On Tablet Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
						3 => __( '3 Items', 'koganic-addons' ),
					],
					'default'     => 3,
					'label_block' => true,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'items_mobile',
				[
					'label'       => __( 'Items Show On Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'default'     => 1,
					'label_block' => true,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'items_small_mobile',
				[
					'label'       => __( 'Items Show On Small Mobile Device', 'koganic-addons' ),
					'type'        => Controls_Manager::SELECT,
					'description' => __( 'Show number of items on small mobile. Screen resolution of device < 445px', 'koganic-addons' ),
					'options'     => [
						1 => __( '1 Item', 'koganic-addons' ),
						2 => __( '2 Items', 'koganic-addons' ),
					],
					'label_block' => true,
					'default'     => 1,
					'condition'   => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'navigation',
				[
					'label'        => __( 'Enable Navigation', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'style_navigation',
				[
					'label'     => __( 'Arrow Styles', 'koganic-addons' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => [
						'icon_arrow'     => __( 'Icon Arrow', 'koganic-addons' ),
						'icon_box_arrow' => __( 'Icon Arrow Box', 'koganic-addons' ),
					],
					'default'   => 'icon_arrow',
					'condition' => [
						'navigation' => 'yes',
					],
				]
			);

			$this->add_control(
				'pagination',
				[
					'label'        => __( 'Enable Dots Pagination', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => __( 'Enables autoplay mode', 'koganic-addons' ),
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'        => __( 'Autoplay', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->add_control(
				'loop',
				[
					'label'        => __( 'Loop', 'koganic-addons' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'koganic-addons' ),
					'condition'    => [
						'product_design' => 'carousel',
					],
				]
			);

			$this->end_controls_section();
		}
		protected function render() {
			global $woocommerce_loop, $product;
			//$default = $this->get_default_setting_product();
			$settings = $this->get_settings_for_display();
            //$settings = wp_parse_args($settings,$default);
			if ( Plugin::$instance->editor->is_edit_mode() ) {
				$settings['not_ajax'] == 'yes';
			}
			$doing_ajax = (defined( 'DOING_AJAX' ) && DOING_AJAX && $settings['not_ajax'] != 'yes');

			$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
			if(isset($settings['ajax_page']) && $settings['ajax_page'] > 1 ) $settings['ajax_page'];

			$woocommerce_loop['is_shortcode']   = true;
			$woocommerce_loop['product_design'] = $settings['product_design'];
			$woocommerce_loop['style_product'] = $settings['style_product'];
			$woocommerce_loop['style_product_list'] = $settings['style_product_list'];
			$woocommerce_loop['style_thumb']  = $settings['style_thumb'];
			$woocommerce_loop['countdown']      = $settings['countdown'];
			$woocommerce_loop['varition_woocommerce']      = $settings['varition_woocommerce'];
			$woocommerce_loop['style_navigation']   = $settings['style_navigation'];
			$woocommerce_loop['slider_opacity']   = $settings['slider_opacity'];
			$woocommerce_loop['number_of_rows']   = $settings['number_of_rows'];
			$woocommerce_loop['type_product']   = $settings['type_product'];


			$this->add_render_attribute( 'class', 'class', 'jmsproduct-elements' );

			if ( isset( $settings['style_navigation'] ) && $settings['style_navigation'] == 'icon_arrow' ) {
				$this->add_render_attribute( 'class', 'class', 'icon_arrow' );
			} elseif ( isset( $settings['style_navigation'] ) && $settings['style_navigation'] == 'icon_box_arrow' ) {
				$this->add_render_attribute( 'class', 'class', 'icon_box_arrow' );
			}
			if ( isset( $settings['product_design'] ) && $settings['product_design'] == 'nocarousel' ) {
				$this->add_render_attribute( 'class', 'class', 'product-design-grid' );
				$this->add_render_attribute( 'class_wrap', 'class', [
					'products',
					'row',
					'koganic-products-holder',
					'layout-columns-mobile-2',
					'product-design-grid',
					'masonry-container',
				] );
				$this->add_render_attribute( 'class_wrap', 'data-paged', 1);
				if ( isset( $settings['columns']) && $settings['columns'] != '' ) {
					$this->add_render_attribute( 'class_wrap', 'class', 'layout-columns-'.esc_attr($settings['columns']) );
				}
				if ( isset( $settings['product_spacing']) && $settings['product_spacing'] != '' ) {
					$this->add_render_attribute( 'class_wrap', 'class', 'layout-spacing-'.esc_attr($settings['product_spacing']) );
				}
			}

			if ( isset( $settings['product_design'] ) && $settings['product_design'] == 'carousel' ) {
				$this->add_render_attribute( 'class_wrap', 'class', [
					'koganic-products-holder',
					'koganic-products-style-' . $settings['style_product'],
					'spacing-carousel-'.intval( $settings['items_margin']),
					'product-carousel-'.$this->get_id(),
					'owl-carousel',
					'owl-theme',
				] );

				// attr slider
				$attr_slider = array();

				if ( ! empty( $settings['items_desktop'] ) ) {
					$attr_slider['itemDesktop'] = intval( $settings['items_desktop'] );
					$attr_slider['smartSpeed'] = 250;
				}

				if ( ! empty( $settings['items_small_desktop'] ) ) {
					$attr_slider['itemSmallDesktop'] = intval( $settings['items_small_desktop'] );
				}

				if ( ! empty( $settings['items_tablet'] ) ) {
					$attr_slider['itemTablet'] = intval( $settings['items_tablet'] );
				}

				if ( ! empty( $settings['items_mobile'] ) ) {
					$attr_slider['itemMobile'] = intval( $settings['items_mobile'] );
				}

				if ( ! empty( $settings['items_small_mobile'] ) ) {
					$attr_slider['itemSmallMobile'] =  intval( $settings['items_small_mobile'] );
				}

				if ( ! empty( $settings['items_margin'] ) ) {
					$attr_slider['margin'] =  intval( $settings['items_margin'] );
				}

				if ( isset( $settings['navigation'] ) && $settings['navigation'] == 'yes' ) {
					$attr_slider['navigation'] = true;
				} else {
					$attr_slider['navigation'] = false;
				}

				if ( isset( $settings['pagination'] ) && $settings['pagination'] == 'yes' ) {
					$attr_slider['pagination'] = true;
				} else {
					$attr_slider['pagination'] = false;
				}

				if ( isset( $settings['autoplay'] ) && $settings['autoplay'] == 'yes' ) {
					$attr_slider['autoplay'] = true;
				} else {
					$attr_slider['autoplay'] = false;
				}

				if ( isset( $settings['loop'] ) && $settings['loop'] == 'yes' ) {
					$attr_slider['loop'] = true;
				} else {
					$attr_slider['loop'] = false;
				}
				if ( isset( $settings['slider_opacity'] ) && $settings['slider_opacity'] == 'yes' ) {
					$attr_slider['slider_opacity'] = true;
				} else {
					$attr_slider['slider_opacity'] = false;
				}

				if ( isset( $settings['countdown'] ) && $settings['countdown'] == 'yes' ) {
					$this->add_render_attribute( 'class_wrap', 'data-countdown', 'yes' );
					wp_enqueue_script( 'countdown' , get_template_directory_uri() . '/assets/3rd-party/jquery.countdown.min.js', array(), false, true  );
            		wp_enqueue_script( 'moment', get_template_directory_uri() . '/assets/3rd-party/moment.min.js', array( 'jquery' ), '', true );
            		wp_enqueue_script( 'moment-timezone', get_template_directory_uri() . '/assets/3rd-party/moment-timezone-with-data.min.js', array( 'jquery' ), '', true );
				}

				if ( ! empty( $attr_slider ) ) {
					$attr_json = wp_json_encode( $attr_slider );
					$data_slider = function_exists( 'wc_esc_json' ) ? wc_esc_json( $attr_json ) : _wp_specialchars( $attr_json, ENT_QUOTES, 'UTF-8', true );
					$this->add_render_attribute( 'class_wrap', 'data-carousel', $data_slider );
				}
			}
			if ( isset( $settings['slider_opacity'] ) && $settings['slider_opacity'] == 'yes' ) {
				$this->add_render_attribute( 'class', 'class', 'slider_opacity' );
			}

			// Global Query

			$args = array(
				'post_type'            => 'product',
				'post_status' 		   => 'publish',
				'ignore_sticky_posts'  => 1,
				'paged'                => $paged,
				'orderby'              => $settings['orderby'],
				'order'                => $settings['order'],
				'posts_per_page'       => intval($settings['total_items']),
				'meta_query'           => WC()->query->get_meta_query(),
				'tax_query'            => WC()->query->get_tax_query()
			);

			// all products
			if( isset($settings['product_type']) && $settings['product_type'] == 'ids' ) {
				if (isset($settings['sku']) && $settings['sku'] != '' ) {
					$args['meta_query'][] = array(
						'key'     => '_sku',
						'value'   => array_map( 'trim', explode( ',', $settings['sku'] ) ),
						'compare' => 'IN'
					);
				}
				if ( $settings['ids']  != '' ) {
					if(is_array($settings['ids'])){
						$args['post__in'] = array_filter( $settings['ids'] );
					}else{
						$args['post__in'] = array_map( 'trim', explode( ' ', $settings['ids'] ) );
					}
					
				}
			}

			//recent products
			if( isset($settings['product_type']) && $settings['product_type'] === 'recent' ) {
				$args['orderby'] = 'date';
				$args['order']   = 'desc';
			}

			//featured products
			if( isset($settings['product_type']) && $settings['product_type'] === 'featured' ) {
				$args['tax_query'][] = array(
					'taxonomy' => 'product_visibility',
					'field'    => 'name',
					'terms'    => 'featured',
					'operator' => 'IN',
				);
			}

			//best selling
			if( isset($settings['product_type']) && $settings['product_type'] === 'selling' ) {
				$args['orderby'] = 'meta_value_num';
				$args['meta_key'] = 'total_sales';
			}

			//sale products
			if( isset($settings['product_type']) && $settings['product_type'] === 'sale' ) {
				$args['post__in'] = array_merge( array( 0 ), wc_get_product_ids_on_sale() );
			}

			//product by categories
			if( isset($settings['product_type']) && $settings['product_type'] === 'cat' ) {
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'id',
						'terms'    => $settings['cat_id'],
					),
				);
			}
			$products = new \WP_Query( $args );
			?>
			<div <?php echo $this->get_render_attribute_string( 'class' ); ?> >
				<div <?php echo $this->get_render_attribute_string( 'class_wrap' ); ?> >
				<?php
				if ( isset( $settings['product_design'] ) && $settings['product_design'] == 'carousel' ) {
					if ( $products->have_posts() ) :
						$row = 1;
						while ( $products->have_posts() ) : $products->the_post();
							if($row == 1) :
								echo '<div class="item-wrap">';
							endif;
							wc_get_template_part( 'content', 'product' );
							if( $row == (int) $settings['number_of_rows'] || $products->current_post+1 == $products->post_count) { $row=0;
								 echo '</div>';
							} $row++;
						endwhile;
					endif;
				}
				if ( isset( $settings['product_design'] ) && $settings['product_design'] == 'nocarousel' ) {
					if ( $products->have_posts() ) :
						while ( $products->have_posts() ) :
							$products->the_post();
							wc_get_template_part( 'content', 'product' );
						endwhile;
					endif;
				}
				wp_reset_postdata();
				?>
				</div>
				<div class="clearfix"></div>
				<?php if ( $products->max_num_pages > 1 && ($settings['loadmore_product'] == 'yes')) : ?>
					<div class="loadmore_product_btn">
						<a href="#" data-max-paged="<?php echo intval($products->max_num_pages); ?>"><?php esc_html_e('Load more products', 'koganic-addons'); ?><span><?php esc_html_e('Loading...', 'koganic-addons'); ?></span></a>
					</div>
				<?php endif; ?>
			</div>
			<?php
		}

		private function get_default_setting_product() {
			return array(
				'product_design'     => 'nocarousel',
				'product_type'       => 'all',
				'orderby'            => 'title',
				'order'              => 'ASC',
				'ids'                => '',
				'sku'                => '',
				'cat_id'             => '',
				'countdown'   		 => '',
				'varition_woocommerce'  => '',
				'total_items'        => '8',
				'columns'            => '4',
				'style_thumb'        => '',
				'loadmore_product'   => 'no',
				'type_product'        => 'grid',
				'style_product'        => '',
				'style_product_list'        => '',
				'product_spacing'    => '30',
				'slider_opacity'    => '',
				'style_navigation'   => 'icon_arrow',
				'css_animation' => '',
				'not_ajax' 	 		 => 'no',
				'el_class'           => '',
				'css'                => '',
				'ajax_page'			 => '',
				'number_of_rows'	 => '1',
				'items_desktop'       => '4',
				'items_small_desktop' => '4',
				'items_tablet'        => '3',
				'items_mobile'        => '2',
				'items_small_mobile'  => '1',
				'navigation'          => 'yes',
				'items_margin'        => '30',
				'pagination'          => 'no',
				'autoplay'            => 'no',
				'loop'                => 'no',
			);
		}

		protected function render_shortcode() {
			$settings = $this->get_settings_for_display();

			$attribute = array(
				'product_design',
				'product_type',
				'orderby',
				'order',
				'ids',
				'sku',
				'cat_id',
				'countdown',
				'countdown_title',
				'varition_woocommerce',
				'total_items',
				'columns',
				'style_thumb',
				'loadmore_product',
				'type_product',
				'style_product',
				'style_product_list',
				'product_spacing',
				'slider_opacity',
				'style_navigation',
				'css_animation',
				'not_ajax',
				'el_class',
				'css',
				'ajax_page',
				'number_of_rows',
				'items_desktop',
				'items_small_desktop',
				'items_tablet',
				'items_mobile',
				'items_small_mobile',
				'navigation',
				'items_margin',
				'pagination',
				'autoplay',
				'loop',
			);

			foreach ($attribute as $key => $value){
				if ( isset($settings[$value]) && !empty($settings[$value]) ) {
					$this->add_render_attribute( 'shortcode', $value, $settings[$value] );
				}
			}
			if ( Plugin::$instance->editor->is_edit_mode() ) {
				$this->add_render_attribute( 'shortcode', 'not_ajax', 'yes' );
			}

			//echo "<pre>";
			//print_r( $this->get_render_attribute_string( 'shortcode' ) );

			echo do_shortcode( '[jms_products ' . $this->get_render_attribute_string( 'shortcode' ) . ']' );

		}

	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_Product_Widget() );
}