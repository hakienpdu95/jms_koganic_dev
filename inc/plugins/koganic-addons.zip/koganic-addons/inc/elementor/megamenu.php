<?php

namespace Elementor;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Elementor_MegaMenu_Widget' ) ) {

	class Elementor_MegaMenu_Widget extends Widget_Base {

		public function get_name() {
			return 'megamenu';
		}

		public function get_title() {
			return __( 'Mega Menu Widget', 'koganic-addons' );
		}

		public function get_icon() {
			return 'eicon-nav-menu';
		}

		public function get_categories() {
			return [ 'koganic' ];
		}

		private function get_available_menus() {
			$menus = wp_get_nav_menus();

			$options = [];

			foreach ( $menus as $menu ) {
				$options[ $menu->slug ] = $menu->name;
			}

			return $options;
		}

		protected function _register_controls() {
			$menus = $this->get_available_menus();
			$this->start_controls_section(
				'section_general',
				[
					'label' => __( 'General', 'koganic-addons' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'koganic-addons' ),
					'type'        => Controls_Manager::TEXT,
					'input_type'  => 'text',
					'default'     =>  __( 'Title', 'koganic-addons' ),
					'label_block' => true,
					'placeholder' => __( 'User name', 'koganic-addons' ),
				]
			);

			$this->add_control(
				'nav_menu',
				[
					'label'   => __( 'Choose Menu', 'koganic-addons' ),
					'type'    => Controls_Manager::SELECT,
					'options' => $menus,
					'default' => array_keys( $menus )[0],
					'save_default' => true,
				]
			);

			$this->add_control(
				'color',
				[
					'label' => __( 'Title Color', 'koganic-addons' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .menu-title' => 'color: {{VALUE}}',
					],
				]
			);
			$this->end_controls_section();

		}


		protected function render() {
			$settings = $this->get_settings_for_display();
			if ( '' === $settings['nav_menu'] ) {
				return;
			}
			?>
				<div class="megamenu-widget-wrapper">
					<?php if ( '' !== $settings['title'] ) : ?>
						<h3 class="menu-title"><?php echo esc_html($settings['title']); ?></h3>
					<?php endif; ?>
					<div class="koganic-navigation vertical-navigation">
						<?php
							wp_nav_menu( array(
								'fallback_cb' => '',
								'menu'        => $settings['nav_menu'],
							) );
						?>
					</div>
				</div>
			<?php
		}

		protected function render_shortcode() {
			$settings = $this->get_settings_for_display();

			$attribute = array(
				'title',
				'nav_menu',
				'color',
			);

			foreach ($attribute as $key => $value){
				if ( isset($settings[$value]) && !empty($settings[$value]) ) {
					$this->add_render_attribute( 'shortcode', $value, $settings[$value] );
				}
			}

			echo do_shortcode( '[koganic_megamenu ' . $this->get_render_attribute_string( 'shortcode' ) . ']' );

		}

	}

	Plugin::instance()->widgets_manager->register_widget_type( new Elementor_MegaMenu_Widget() );
}