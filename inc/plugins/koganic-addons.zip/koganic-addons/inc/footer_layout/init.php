<?php
/**
 * HTML BLOCK custom post type.
 */

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

class Koganic_footer_layout {
    function __construct() {
		add_action( 'init', array( __CLASS__, 'register_blocks' ) );

        // Add shortcode column to block list
		add_filter( 'manage_edit-footer_layout_columns', array($this, 'edit_footer_layouts_columns') ) ;
	}

    public static function register_blocks() {
 		$labels = array(
 			'name'                => _x( 'Footer Layout', 'Post Type General Name', 'koganic-addons' ),
 			'singular_name'       => _x( 'Footer Layout', 'Post Type Singular Name', 'koganic-addons' ),
 			'menu_name'           => __( 'Footer Layout', 'koganic-addons' ),
 			'parent_item_colon'   => __( 'Parent Item:', 'koganic-addons' ),
 			'all_items'           => __( 'All Items', 'koganic-addons' ),
 			'view_item'           => __( 'View Item', 'koganic-addons' ),
 			'add_new_item'        => __( 'Add New Item', 'koganic-addons' ),
 			'add_new'             => __( 'Add New', 'koganic-addons' ),
 			'edit_item'           => __( 'Edit Item', 'koganic-addons' ),
 			'update_item'         => __( 'Update Item', 'koganic-addons' ),
 			'search_items'        => __( 'Search Item', 'koganic-addons' ),
 			'not_found'           => __( 'Not found', 'koganic-addons' ),
 			'not_found_in_trash'  => __( 'Not found in Trash', 'koganic-addons' ),
 		);

 		$args = array(
 			'label'               => __( 'footer_layout', 'koganic-addons' ),
 			'description'         => __( 'CMS Blocks for custom HTML to place in your pages', 'koganic-addons' ),
 			'labels'              => $labels,
 			'supports'            => array( 'title', 'editor' ),
 			'hierarchical'        => false,
 			'public'              => true,
 			'show_ui'             => true,
 			'show_in_menu'        => true,
 			'show_in_nav_menus'   => true,
 			'show_in_admin_bar'   => true,
 			'menu_position'       => 29,
 			'menu_icon'           => 'dashicons-schedule',
 			'can_export'          => true,
 			'has_archive'         => true,
 			'exclude_from_search' => true,
 			'publicly_queryable'  => true,
 			'rewrite'             => false,
 			'capability_type'     => 'page',
 		);

 		register_post_type( 'footerlayout', $args );

 	}

    public function edit_footer_layouts_columns( $columns ) {
		$columns = array(
			'cb' => '<input type="checkbox" />',
			'title' => __( 'Title', 'koganic-addons' ),
			'date' => __( 'Date', 'koganic-addons' ),
		);
		return $columns;
	}

}
$footer_layout = new Koganic_footer_layout;
