<?php 

if ( !function_exists('koganic_framework_widgets_new_version') ) {
    function koganic_framework_widgets_new_version() {

        if( ( defined('KOGANIC_VERSION') && (float)KOGANIC_VERSION >= 1.0 )  ) {
           
            if(class_exists('koganic_Recent_Post')) {
                register_widget( 'koganic_Recent_Post' );
            }  

        }
    }

    add_action( 'widgets_init', 'koganic_framework_widgets_new_version', 30 );
}

if( ! function_exists( 'koganic_framework_widget_init' ) ) {
    function koganic_framework_widget_init() {
    	$widgets = apply_filters( 'koganic_framework_register_widgets', array(
    		'widget-woo-filter',
    		'widget-woo-filter-by-price'
	    ) );
    	if ( !empty($widgets) ) {
    		foreach ($widgets as $widget) {
    			if ( file_exists( KOGANIC_ADDONS_PATH . 'classes/widgets/'.$widget.'.php' ) ) {
    				require KOGANIC_ADDONS_PATH . 'classes/widgets/'.$widget.'.php';
    			}
    		}
    	}
    }
}

if( ! function_exists( 'koganic_framework_get_widget_locate' ) ) {
    function koganic_framework_get_widget_locate( $name, $plugin_dir = KOGANIC_ADDONS_PATH ) {
    	$template = '';
    	
    	// Child theme
    	if ( ! $template && ! empty( $name ) && file_exists( get_stylesheet_directory() . "/widgets/{$name}" ) ) {
    		$template = get_stylesheet_directory() . "/widgets/{$name}";
    	}

    	// Original theme
    	if ( ! $template && ! empty( $name ) && file_exists( get_template_directory() . "/widgets/{$name}" ) ) {
    		$template = get_template_directory() . "/widgets/{$name}";
    	}

    	// Plugin
    	if ( ! $template && ! empty( $name ) && file_exists( $plugin_dir . "/templates/widgets/{$name}" ) ) {
    		$template = $plugin_dir . "/templates/widgets/{$name}";
    	}

    	// Nothing found
    	if ( empty( $template ) ) {
    		throw new Exception( "Template /templates/widgets/{$name} in plugin dir {$plugin_dir} not found." );
    	}

    	return $template;
    }
}