<?php

abstract class Koganic_Widget extends WP_Widget {
	
	public $template;
	abstract function getTemplate();

	public function display( $args, $instance ) {
		$this->getTemplate();
		extract($args);
		extract($instance);
		echo $before_widget;
			require koganic_framework_get_widget_locate( $this->template );
		echo $after_widget;
	}
}