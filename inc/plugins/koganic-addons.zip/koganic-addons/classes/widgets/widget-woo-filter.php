<?php
if ( ! class_exists( 'Koganic_Filter_Widget' ) ) {

	class Koganic_Filter_Widget extends WP_Widget {

		/**
		 * Use to print or not widget
		 */
		public $found = false;

		function __construct() {
			$classname   = 'koganic-woocommerce-ajax-product-filter woocommerce widget_layered_nav checked_multi';
			$widget_ops  = array(
				'classname'   => $classname,
				'description' => __( 'Filter the list of products without reloading the page', 'koganic-addons' )
			);
			$control_ops = array( 'width' => 400, 'height' => 350 );
			add_action( 'wp_ajax_koganic_apf_select_type', array( $this, 'ajax_print_terms' ) );
			parent::__construct( 'koganic-ajax-product-filter', _x( 'Koganic Ajax Product Filter', '[Plugin Name] Admin: Widget Title', 'koganic-addons' ), $widget_ops, $control_ops );
		}

		function widget( $args, $instance ) {
			global $wc_product_attributes;

			$_chosen_attributes = WC_Query::get_layered_nav_chosen_attributes();
			$queried_object     = get_queried_object();

			extract( $args );
			$_attributes_array = get_object_taxonomies( 'product' );

			if ( apply_filters( 'koganic_apf_is_search', is_search() ) ) {
				return;
			}
			if ( apply_filters( 'koganic_apf_show_widget', is_post_type_archive( 'product' ) && ! is_tax( $_attributes_array ), $instance ) ) {
				return;
			}

			$filter_term_field       = 'slug';
			$current_term            = $_attributes_array && is_tax( $_attributes_array ) ? get_queried_object()->$filter_term_field : '';
			$title                   = apply_filters( 'koganic_widget_title_ajax_product_filter    ', ( isset( $instance['title'] ) ? $instance['title'] : '' ), $instance, $this->id_base );
			$query_type              = isset( $instance['query_type'] ) ? $instance['query_type'] : 'or';
			$display_type            = isset( $instance['type'] ) ? $instance['type'] : 'list';
			$is_chosen_class         = 'koganic-active';
			$is_child_class          = 'koganic-apf-child-terms';
			$is_parent_class         = 'koganic-apf-parent-terms';
			$terms_type_list         = ( isset( $instance['display'] ) ) ? $instance['display'] : 'all';
			$instance['attribute']   = empty( $instance['attribute'] ) ? '' : $instance['attribute'];
			$instance['extra_class'] = empty( $instance['extra_class'] ) ? '' : $instance['extra_class'];
			$rel_nofollow            = 'rel="nofollow"';

			$taxonomy        = $instance['attribute'];
			$taxonomy        = apply_filters( 'koganic_apf_get_terms_params', $taxonomy, $instance, 'taxonomy_name' );
			$terms_type_list = apply_filters( 'koganic_apf_get_terms_params', $terms_type_list, $instance, 'terms_type' );

			if ( ! taxonomy_exists( $taxonomy ) ) {
				return;
			}

			$terms = $this->koganic_get_terms( $terms_type_list, $taxonomy, $instance );

			if ( count( $terms ) > 0 || $display_type === 'sort') {
				ob_start();

				$this->found = false;

				echo $args['before_widget'];

				$title = html_entity_decode( apply_filters( 'koganic_widget_title', $title ) );

				if ( ! empty( $title ) ) {
					echo $args['before_title'] . $title . $args['after_title'];
				}
                if($display_type === 'sort'){
	                echo "<input type='hidden' name='orderby' value=''/>";
                } elseif ( ! empty( $instance['attribute'] ) && taxonomy_is_product_attribute( $instance['attribute'] ) ) {
				    //$this->get_filter_input_taxonomy();
					echo "<input type='hidden' name='{$instance['attribute']}' value=''/>";
				}

				if ( in_array( $display_type, apply_filters( 'koganic_apf_display_type_list', array( 'list' ) ) ) ) {

					// List display
					echo "<div class='koganic-apf-list koganic-apf {$instance['extra_class']}' data-filter='{$instance['attribute']}'>";

					foreach ( $terms as $term ) {
						$parent = false;
						$curr_cat_selected = [];
						$pf_adoptive_class = '';

						printf( '<label class="%6$s%4$s%7$s%8$s"><input type="checkbox" value="%1$s"%3$s%9$s /><span>%2$s</span>%5$s</label>',
							$term->slug,
							$term->name,
							( in_array( $term->slug, $curr_cat_selected ) ? ' checked' : '' ),
							( in_array( $term->slug, $curr_cat_selected ) ? ' '.$is_chosen_class : '' ),
							( ! empty( $term->children ) ? '<i class="koganic-plus"></i>' : '' ),
							$pf_adoptive_class,
							( ! empty( $term->children ) && in_array( $term->slug, $curr_cat_selected ) ? ' koganic_clicked' : '' ),
							' koganic_ft_' . sanitize_title( $term->slug ),
							( $parent !== false ? ' data-parent="' . $parent . '"' : '' )
						);
						?>
						<?php
					}
					echo "</div>";

				} elseif ( in_array( $display_type, apply_filters( 'koganic_apf_display_type_list', array( 'color' ) ) ) ) {
					// List display
					echo "<div class='koganic-apf-color koganic-apf {$instance['extra_class']}' data-filter='{$instance['attribute']}'>";
					foreach ( $terms as $term ) {
						$parent = false;
						$curr_cat_selected = [];
						$pf_adoptive_class = '';

						$color = '';
						if( ! empty( $instance['colors'][$term->term_id] ) ){
							$color = $instance['colors'][$term->term_id];
						}
						$curr_insert = '<span class="koganic_customize"><span class="koganic_customize_color" style="background-color:' . $color . ';"></span><span class="">' . $term->name . '</span></span>';

						printf( '<label class="%6$s%4$s%7$s%8$s"><input type="checkbox" value="%1$s"%3$s%9$s /><span>%2$s</span>%5$s</label>',
                            $term->slug,
                            $curr_insert,
                            ( in_array( $term->slug, $curr_cat_selected ) ? ' checked' : '' ),
                            ( in_array( $term->slug, $curr_cat_selected ) ? ' '.$is_chosen_class : '' ),
                            ( ! empty( $term->children ) ? '<i class="koganic-plus"></i>' : '' ),
                            $pf_adoptive_class,
                            ( ! empty( $term->children ) && in_array( $term->slug, $curr_cat_selected ) ? ' koganic_clicked' : '' ),
                            ' koganic_ft_' . sanitize_title( $term->slug ),
                            ( $parent !== false ? ' data-parent="' . $parent . '"' : '' )
                        );
						?>
						<?php
					}
					echo "</div>";
				} elseif ( in_array( $display_type, apply_filters( 'koganic_apf_display_type_list', array( 'label' ) ) ) ) {
					// List display
					echo "<div class='koganic-apf-label koganic-apf {$instance['extra_class']}' data-filter='{$instance['attribute']}'>";
					foreach ( $terms as $term ) {
						$parent = false;
						$curr_cat_selected = [];
						$pf_adoptive_class = '';

						$labels = '';
						if( ! empty( $instance['labels'][$term->term_id] ) ){
							$labels = $instance['labels'][$term->term_id];
						}

						printf( '<label class="%6$s%4$s%7$s%8$s"><input type="checkbox" value="%1$s"%3$s%9$s /><span>%2$s</span>%5$s</label>',
							$term->slug,
							$labels,
							( in_array( $term->slug, $curr_cat_selected ) ? ' checked' : '' ),
							( in_array( $term->slug, $curr_cat_selected ) ? ' '.$is_chosen_class : '' ),
							( ! empty( $term->children ) ? '<i class="koganic-plus"></i>' : '' ),
							$pf_adoptive_class,
							( ! empty( $term->children ) && in_array( $term->slug, $curr_cat_selected ) ? ' koganic_clicked' : '' ),
							' koganic_ft_' . sanitize_title( $term->slug ),
							( $parent !== false ? ' data-parent="' . $parent . '"' : '' )
						);
						?>
						<?php
					}
					echo "</div>";
                } elseif ( in_array( $display_type, apply_filters( 'koganic_apf_display_type_list', array( 'sort' ) ) ) ) {
				    // List display
					$apf_orderby_options = apply_filters( 'woocommerce_catalog_orderby', array(
						'menu_order' => esc_html__( 'Default', 'koganic-addons' ),
						'popularity' => esc_html__( 'Popularity', 'koganic-addons' ),
						'rating'     => esc_html__( 'Average rating', 'koganic-addons' ),
						'date'       => esc_html__( 'Sort by newness', 'koganic-addons' ),
						'price'      => esc_html__( 'Price low to high', 'koganic-addons' ),
						'price-desc' => esc_html__( 'Price high to low', 'koganic-addons' ),
					) );
					$curr_cat_selected = [];
				    echo "<div class='koganic-apf-label koganic-apf {$instance['extra_class']}'  data-filter='orderby'>";
					foreach ( $apf_orderby_options as $key => $val ) {
						printf( '<label class="%4$s%5$s"><input type="checkbox" value="%1$s"%3$s /><span>%2$s</span></label>',
							$key,
							$val,
							( in_array($key, $curr_cat_selected ) ? ' checked' : '' ),
							( in_array( $key, $curr_cat_selected ) ? ' '.$is_chosen_class : '' ),
							' koganic_ft_' . sanitize_title( $key )
						);
                    }
				    echo "</div>";
			    }

				echo $args['after_widget'];

				$this->found = true;
				if ( ! $this->found ) {
					ob_end_clean();
				} else {
					echo ob_get_clean();
				}
			}
		}

		function form( $instance ) {
			$defaults = array(
				'title'       => '',
				'attribute'   => '',
				'query_type'  => 'or',
				'type'        => 'list',
				'colors'      => '',
				'labels'      => '',
				'display'     => 'all',
				'extra_class' => ''
			);

			$instance = wp_parse_args( (array) $instance, $defaults );

			$widget_types = apply_filters( 'koganic_apf_widget_types', array(
					'list'       => __( 'List', 'koganic-addons' ),
					'color'      => __( 'Color', 'koganic-addons' ),
					'label'      => __( 'Label', 'koganic-addons' ),
					'sort'       => __( 'Sort', 'koganic-addons' ),
					//'categories' => __( 'Categories', 'koganic-addons' ),
					//'tags'       => __( 'Tags', 'koganic-addons' ),
					//'select' => __( 'Dropdown', 'koganic-addons' )
				)
			);
			?>
            <p>
                <label>
                    <strong><?php _e( 'Title', 'koganic-addons' ) ?>:</strong><br/>
                    <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'title' ); ?>"
                           name="<?php echo $this->get_field_name( 'title' ); ?>"
                           value="<?php echo $instance['title']; ?>"/>
                </label>
            </p>

            <p>
                <label for="<?php echo $this->get_field_id( 'type' ); ?>"><strong><?php _e( 'Type:', 'koganic-addons' ) ?></strong></label>
                <select class="koganic_apf_type widefat" id="<?php echo esc_attr( $this->get_field_id( 'type' ) ); ?>"
                        name="<?php echo esc_attr( $this->get_field_name( 'type' ) ); ?>">
					<?php foreach ( $widget_types as $type => $label ) : ?>
                        <option value="<?php echo $type ?>" <?php selected( $type, $instance['type'] ) ?>><?php echo $label ?></option>
					<?php endforeach; ?>
                </select>
            </p>

            <p class="koganic-apf-attribute-list"
               style="display: <?php echo $instance['type'] == 'tags' || $instance['type'] == 'brands' || $instance['type'] == 'categories' ? 'none' : 'block' ?>;">

                <label for="<?php echo $this->get_field_id( 'attribute' ); ?>"><strong><?php _e( 'Attribute:', 'koganic-addons' ) ?></strong></label>
                <select class="koganic_apf_attributes widefat"
                        id="<?php echo esc_attr( $this->get_field_id( 'attribute' ) ); ?>"
                        name="<?php echo esc_attr( $this->get_field_name( 'attribute' ) ); ?>">
					<?php
					global $wc_product_attributes;

					// Array of defined attribute taxonomies.
					$attribute_taxonomies = wc_get_attribute_taxonomies();

					if ( ! empty( $attribute_taxonomies ) ) {
						foreach ( $attribute_taxonomies as $tax ) {
							$attribute_taxonomy_name = wc_attribute_taxonomy_name( $tax->attribute_name );
							$label                   = $tax->attribute_label ? $tax->attribute_label : $tax->attribute_name;
							echo '<option value="' . esc_attr( $attribute_taxonomy_name ) . '" ' . selected( $attribute_taxonomy_name, $instance['attribute'], false ) . '>' . esc_html( $label ) . '</option>';
						}
					}
					?>
                </select>
            </p>
            <p id="koganic-apf-display" class="koganic-apf-display-<?php echo $instance['type'] ?>">
                <label for="<?php echo $this->get_field_id( 'display' ); ?>"><strong><?php _e( 'Display (default All):', 'koganic-addons' ) ?></strong></label>
                <select class="koganic_apf_type widefat" id="<?php echo esc_attr( $this->get_field_id( 'display' ) ); ?>"
                        name="<?php echo esc_attr( $this->get_field_name( 'display' ) ); ?>">
                    <option value="all" <?php selected( 'all', $instance['display'] ) ?>>          <?php _e( 'All (no hierarchical)', 'koganic-addons' ) ?></option>
                    <option value="hierarchical" <?php selected( 'hierarchical', $instance['display'] ) ?>> <?php _e( 'All (hierarchical)', 'koganic-addons' ) ?>   </option>
                    <option value="parent" <?php selected( 'parent', $instance['display'] ) ?>>       <?php _e( 'Only Parent', 'koganic-addons' ) ?>        </option>
                </select>
            </p>
            <p>
                <label>
                    <strong><?php _e( 'CSS custom class', 'koganic-addons' ) ?>:</strong><br/>
                    <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'extra_class' ); ?>"
                           name="<?php echo $this->get_field_name( 'extra_class' ); ?>"
                           value="<?php echo $instance['extra_class']; ?>"/>
                </label>
            </p>
            <div class="koganic_apf_placeholder">
				<?php
				$values = array();

				if ( $instance['type'] == 'color' ) {
					$values = $instance['colors'];
				} elseif ( $instance['type'] == 'label' ) {
					$values = $instance['labels'];
				}

				$this->koganic_apf_attributes_table(
					$instance['type'],
					$instance['attribute'],
					'widget-' . $this->id . '-',
					'widget-' . $this->id_base . '[' . $this->number . ']',
					$values,
					$instance['display']
				);
				?>
            </div>
            <span class="spinner" style="display: none;"></span>
            <input type="hidden" name="widget_id" value="widget-<?php echo $this->id ?>-"/>
            <input type="hidden" name="widget_name"
                   value="widget-<?php echo $this->id_base ?>[<?php echo $this->number ?>]"/>
			<?php
		}

		function update( $new_instance, $old_instance ) {
			$instance                = $old_instance;
			$instance['title']       = strip_tags( $new_instance['title'] );
			$instance['attribute']   = ! empty( $new_instance['attribute'] ) ? stripslashes( $new_instance['attribute'] ) : array();
			$instance['query_type']  = ! empty( $new_instance['query_type'] ) ? stripslashes( $new_instance['query_type'] ) : 'or';
			$instance['type']        = stripslashes( $new_instance['type'] );
			$instance['colors']      = ! empty( $new_instance['colors'] ) ? $new_instance['colors'] : array();
			$instance['labels']      = ! empty( $new_instance['labels'] ) ? $new_instance['labels'] : array();
			$instance['display']     = $new_instance['display'];
			$instance['extra_class'] = ! empty ( $new_instance['extra_class'] ) ? $new_instance['extra_class'] : '';

			return $instance;
		}

		/**
		 * Print terms for the element selected
		 */
		public function ajax_print_terms() {
			$unsanitize_posted_data = $_POST;
			$posted_data            = array();

			foreach ( $unsanitize_posted_data as $k => $v ) {
				$posted_data[ $k ] = esc_html( $v );
			}

			$type      = $posted_data['value'];
			$attribute = $posted_data['attribute'];
			$post_id   = $posted_data['id'];
			$name      = $posted_data['name'];
			$return    = array( 'message' => '', 'content' => $posted_data );

			$terms = get_terms( array( 'taxonomy' => $attribute, 'hide_empty' => '0' ) );

			$settings        = $this->get_settings();
			$widget_settings = $settings[ $this->number ];
			$value           = '';

			if ( 'label' == $type ) {
				$value = $widget_settings['labels'];
			} elseif ( 'color' == $type ) {
				$value = $widget_settings['colors'];
			}

			if ( $type ) {
				$return['content'] = $this->koganic_apf_attributes_table(
					$type,
					$attribute,
					$_POST['id'],
					$_POST['name'],
					$value,
					false
				);
			}

			echo json_encode( $return );
			die();
		}

		public function koganic_apf_attributes_table( $type, $attribute, $id, $name, $values = array(), $echo = true ) {
			$return = '';
			$terms  = get_terms( array( 'taxonomy' => $attribute, 'hide_empty' => '0' ) );

			if ( 'list' == $type || 'sort' == $type ) {
				$return = '<input type="hidden" name="' . $name . '[colors]" value="" /><input type="hidden" name="' . $name . '[labels]" value="" />';
			} elseif ( 'color' == $type ) {
				if ( ! empty( $terms ) ) {
					$return = sprintf( '<table><tr><th>%s</th><th>%s</th></tr>', __( 'Term', 'koganic-addons' ), __( 'Color', 'koganic-addons' ) );
					if ( function_exists( 'TA_WCVS' ) ) {
						$attr = TA_WCVS()->get_tax_attribute( $attribute );

						if ( 'color' === $attr->attribute_type ) {
							$colors = array_map( function ( $term ) use ( $values ) {
								return isset( $values[ $term->term_id ] ) ? $values[ $term->term_id ] : sanitize_hex_color(get_term_meta( $term->term_id, 'color', true ));
							}, $terms );
							$values = array_combine( wp_list_pluck( $terms, 'term_id' ), $colors );
						}
					}elseif(class_exists( 'Woo_Variation_Swatches' )){
						$colors = array_map( function ( $term ) use ( $values ) {
							return isset( $values[ $term->term_id ] ) ? $values[ $term->term_id ] : sanitize_hex_color(get_term_meta( $term->term_id, 'product_attribute_color', true ));
						}, $terms );
						$values = array_combine( wp_list_pluck( $terms, 'term_id' ), $colors );
                    }

					foreach ( $terms as $term ) {
						if ( $term instanceof WP_Term ) {
							$return .= "<tr><td><label for='{$id}{$term->term_id}'>{$term->name}</label></td><td><input type='text' id='{$id}{$term->term_id}' name='{$name}[colors][{$term->term_id}]' value='" . ( isset( $values[ $term->term_id ] ) ? $values[ $term->term_id ] : '' ) . "' size='3' class='koganic-apf-colorpicker' /></td></tr>";
						}
					}
					$return .= '</table>';
				}

				$return .= '<input type="hidden" name="' . $name . '[labels]" value="" />';
			} elseif ( 'label' == $type ) {
				if ( ! empty( $terms ) ) {
					$return = sprintf( '<table><tr><th>%s</th><th>%s</th></tr>', __( 'Term', 'koganic-addons' ), __( 'Labels', 'koganic-addons' ) );

					foreach ( $terms as $term ) {
						if ( $term instanceof WP_Term ) {
							$return .= "<tr><td><label for='{$id}{$term->term_id}'>{$term->name}</label></td><td><input type='text' id='{$id}{$term->term_id}' name='{$name}[labels][{$term->term_id}]' value='" . ( isset( $values[ $term->term_id ] ) ? $values[ $term->term_id ] : '' ) . "' size='3' /></td></tr>";
						}
					}

					$return .= '</table>';
				}

				$return .= '<input type="hidden" name="' . $name . '[colors]" value="" />';
			}

			if ( $echo ) {
				echo $return;
			}

			return $return;
		}

		public function koganic_reorder_terms_by_parent( $terms, $taxonomy ) {

			/* Extract Child Terms */
			$child_terms  = array();
			$terms_count  = 0;
			$parent_terms = array();

			foreach ( $terms as $array_key => $term ) {

				if ( $term->parent != 0 ) {

					$term_parent = $term->parent;
					while ( true ) {
						$temp_parent_term = get_term_by( 'id', $term_parent, $taxonomy );
						if ( $temp_parent_term->parent != 0 ) {
							$term_parent = $temp_parent_term->parent;
						} else {
							break;
						}
					}

					if ( isset( $child_terms[ $term_parent ] ) && $child_terms[ $term_parent ] != null ) {
						$child_terms[ $term_parent ] = array_merge( $child_terms[ $term_parent ], array( $term ) );
					} else {
						$child_terms[ $term_parent ] = array( $term );
					}

				} else {
					$parent_terms[ $terms_count ] = $term;
				}
				$terms_count ++;
			}

			/* Reorder Terms */
			$terms_count = 0;
			$terms       = array();

			foreach ( $parent_terms as $term ) {

				$terms[ $terms_count ] = $term;

				/* The term as child */
				if ( array_key_exists( $term->term_id, $child_terms ) ) {

					if ( 'product' == get_option( 'koganic_apf_terms_order', 'alphabetical' ) && ! is_wp_error( $child_terms[ $term->term_id ] ) ) {
						usort( $child_terms[ $term->term_id ], array( $this, 'koganic_terms_sort' ) );
					} elseif ( 'alphabetical' == get_option( 'koganic_apf_terms_order', 'alphabetical' ) ) {
						usort( $child_terms[ $term->term_id ], array( $this, 'koganic_alphabetical_terms_sort' ) );
					}

					foreach ( $child_terms[ $term->term_id ] as $child_term ) {
						$terms_count ++;
						$terms[ $terms_count ] = $child_term;
					}
				}
				$terms_count ++;
			}

			if ( 'product' == get_option( 'koganic_apf_terms_order', 'alphabetical' ) && ! is_wp_error( $parent_terms ) ) {
				usort( $terms, array( $this, 'koganic_terms_sort' ) );
			} elseif ( 'alphabetical' == get_option( 'koganic_apf_terms_order', 'alphabetical' ) ) {
				usort( $terms, array( $this, 'koganic_alphabetical_terms_sort' ) );
			}

			return $terms;
		}

		public function koganic_get_terms( $case, $taxonomy, $instance = false ) {

			$exclude   = apply_filters( 'koganic_apf_exclude_terms', array(), $instance );
			$include   = apply_filters( 'koganic_apf_include_terms', array(), $instance );
			$reordered = false;

			$args = array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'exclude'    => $exclude
			);

			$args = apply_filters( 'koganic_get_terms_args', $args, $instance );

			switch ( $case ) {

				case 'all':
					$terms = get_terms( $args );
				break;

				case 'hierarchical':
					$terms = get_terms( $args );
					if ( ! in_array( $instance['type'], apply_filters( 'koganic_apf_display_type_list', array( 'list' ) ) ) ) {
						$terms     = $this->koganic_reorder_terms_by_parent( $terms, $taxonomy );
						$reordered = true;
					}
				break;

				case 'parent' :
					$args['parent'] = false;
					$terms          = get_terms( $args );
				break;

				default:
					$args['include'] = $include;

					if ( 'parent' == $instance['display'] ) {
						$args['parent'] = false;
					}

					$terms = get_terms( $args );

					if ( 'hierarchical' == $instance['display'] ) {
						if ( ! in_array( $instance['type'], apply_filters( 'koganic_apf_display_type_list', array( 'list' ) ) ) ) {
							$terms     = $this->koganic_reorder_terms_by_parent( $terms, $taxonomy );
							$reordered = true;
						}
					}
				break;
			}

			if ( ! $reordered ) {
				$terms     = $this->koganic_reorder_terms_by_parent( $terms, $taxonomy );
				$reordered = true;
			}

			if ( apply_filters( 'koganic_apf_skip_term_order', true, $taxonomy, $instance ) && 'product' == get_option( 'koganic_apf_terms_order', 'alphabetical' ) && 'hierarchical' != $instance['display'] && ! is_wp_error( $terms ) && ! $reordered ) {
				usort( $terms, array( $this, 'koganic_terms_sort' ) );
			}

			return apply_filters( 'koganic_apf_get_terms_list', $terms, $taxonomy, $instance );
		}

		public function koganic_terms_sort( $a, $b ) {
			$result = 0;
			if ( $a->count < $b->count ) {
				$result = 1;
			} elseif ( $a->count > $b->count ) {
				$result = - 1;
			}

			return $result;
		}

		public function koganic_alphabetical_terms_sort( $a, $b ) {
			return strnatcmp( strtolower( $a->name ), strtolower( $b->name ) );
		}

	}


    if ( function_exists( 'WC' ) ) {
        register_widget( 'Koganic_Filter_Widget' );
    }

}

?>