<?php
if ( ! class_exists( 'Koganic_Filter_Price_Widget' ) ) {

	class Koganic_Filter_Price_Widget extends WP_Widget {

		function __construct() {
			$classname   = 'koganic-woocommerce-ajax-product-filter koganic-woocommerce-ajax-product-filter-by-price woocommerce widget_layered_nav';
			$widget_ops  = array(
				'classname'   => $classname,
				'description' => __( 'Filter the list of products', 'koganic-addons' )
			);
			$control_ops = array( 'width' => 400, 'height' => 350 );
			parent::__construct( 'koganic-ajax-product-filter-by-price', _x( 'Koganic Ajax Product Filter By Price', '[Plugin Name] Admin: Widget Title', 'koganic-addons' ), $widget_ops, $control_ops );
		}

		function widget( $args, $instance ) {
			//extract( $instance );

			if ( apply_filters( 'koganic_apf_is_search', is_search() ) ) {
				return;
			}

			$_attributes_array = get_object_taxonomies( 'product' );

			if ( apply_filters( 'koganic_apf_show_widget', is_post_type_archive( 'product' ) && ! is_tax( $_attributes_array ), $instance ) ) {
				return;
			}
			echo $args['before_widget'];

			$title = html_entity_decode( apply_filters( 'koganic_widget_title', $instance['title'] ) );

			if ( ! empty( $title ) ) {
				echo $args['before_title'] . $title . $args['after_title'];
			}

			if( ! empty( $instance['prices'] ) ) {
				echo "<input type='hidden' name='min_price' value=''/>";
				echo "<input type='hidden' name='max_price' value=''/>";
				// List display
				echo "<div class='koganic-apf-by-price koganic-apf' data-filter='price'>";

				foreach( $instance['prices'] as $price ) {
					$curr_selected = [];
                    $value = $price['min']. '-' . $price['max'];
                    if(!empty($price['min']) && !empty($price['max'])){
                        $name = wc_price($price['min']). ' - ' . wc_price($price['max']);
                    }elseif(!empty($price['min'])){
	                    $name = wc_price($price['min']). '+';
                    }elseif(!empty($price['max'])){
	                    $name = wc_price($price['max']). '-';
                    }
					printf( '<label class="%4$s%5$s"><input type="checkbox" value="%1$s"%3$s /><span>%2$s</span></label>',
						$value,
						$name,
						( in_array( $value, $curr_selected ) ? ' checked' : '' ),
						( in_array( $value, $curr_selected ) ? ' koganic_active' : '' ),
						' koganic_ft_' . $value
					);
				}

				echo "</div>";
			}

			echo $args['after_widget'];

		}
		function form( $instance ) {
			global $wpdb;

			$is_ajax = defined('DOING_AJAX') && DOING_AJAX ;

			$min = floor( $wpdb->get_var(
				'SELECT min(meta_value + 0)
				FROM ' . $wpdb->posts . ' as p
				LEFT JOIN ' . $wpdb->postmeta . ' as pm ON p.ID = pm.post_id
				WHERE meta_key IN ("' . implode( '","', apply_filters( 'woocommerce_price_filter_meta_keys', array(
					'_price',
					'_min_variation_price'
				) ) ) . '") '
			) );

			$max = ceil( $wpdb->get_var(
				'SELECT max(meta_value + 0)
					FROM ' . $wpdb->posts . ' as p
				LEFT JOIN ' . $wpdb->postmeta . ' as pm ON p.ID = pm.post_id
					WHERE meta_key IN ("' . implode( '","', apply_filters( 'woocommerce_price_filter_meta_keys', array( '_price' ) ) ) . '")'
			) );

			$defaults = array(
				'title'             => _x( 'Price Filter', 'refer to: product price', 'koganic-addons' ),
				'dropdown'          => 0,
				'dropdown_type'     => 'open',
				'prices'            => array(
					array(
						'min' => $min,
						'max' => $max
					)
				),
			);

			$instance = wp_parse_args( (array) $instance, $defaults );
			?>
			<p>
				<label>
					<strong><?php _e( 'Title', 'koganic-addons' ) ?>:</strong><br />
					<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
				</label>
			</p>
			<p class="koganic-apf-price-filter">
				<label>
					<?php _e( 'Price Range', 'koganic-addons' ) ?>:
				</label>
				<span class="range-filter" data-field_name="<?php echo $this->get_field_name( 'prices' ); ?>">
                    <?php $i = 0; ?>
					<?php if( is_array( $instance['prices'] ) ) : ?>
						<?php foreach ( $instance['prices'] as $price ) : ?>
							<input type="text" name="<?php echo $this->get_field_name( 'prices' ); ?>[<?php echo $i; ?>][min]" value="<?php echo $price['min'] ?>" class="koganic-apf-price-filter-input widefat" data-position="<?php echo $i; ?>" />
							<input type="text" name="<?php echo $this->get_field_name( 'prices' ); ?>[<?php echo $i; ?>][max]" value="<?php echo $price['max'] ?>" class="koganic-apf-price-filter-input widefat" data-position="<?php echo $i; ?>"/>
							<?php $i++; ?>
						<?php endforeach; ?>
					<?php endif; ?>
                </span>
			</p>

			<div class="koganic-add-new-range-button">
				<input type="button" class="koganic-apf-price-filter-add-range button button-primary" value="<?php _e( 'Add new range', 'koganic-addons' ) ?>">
			</div>
			<script type="text/javascript">
                jQuery(document).ready(function () {
                    jQuery('.koganic-apf-price-filter-add-range').off('click').on('click', function (e) {
                        e.preventDefault();
                        var t = jQuery(this);
                        jQuery.add_new_range(t);
                    });
                });
			</script>
			<?php
		}

		function update( $new_instance, $old_instance ) {
			$instance = $old_instance;
			$instance['title']          = strip_tags( $new_instance['title'] );
			$instance['prices']         = $this->remove_empty_price_range( $new_instance['prices'] );
			return $instance;
		}

		public function remove_empty_price_range( $prices ){
			foreach( $prices as $k => $price ){
				if( $price['min'] == '' && $price['max'] == ''  ){
					unset( $prices[ $k ] );
				}
			}

			return $prices;
		}
	}

	if ( function_exists( 'WC' ) ) {
		register_widget( 'Koganic_Filter_Price_Widget' );
	}
}