<?php
/*
* Plugin Name: WooCommerce Ajax Search
* Plugin URI: http://joommasters.com
* Description: WooCommerce Ajax Search allows your users to search products.
* Version: 1.0.0
* Author: Joommasters
* Author URI: http://joommasters.com
* License:     GPL2
* License URI: https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain: woosearch
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define('JMS_WOOSEARCH_PLUGIN_PATH' , plugin_dir_path(__FILE__));
define('JMS_WOOSEARCH_URL', plugin_dir_url(__FILE__));
define('JMS_WOOSEARCH_CSS_URL', JMS_WOOSEARCH_URL . 'css/');
define('JMS_WOOSEARCH_JS_URL', JMS_WOOSEARCH_URL . 'js/');
define('JMS_WOOSEARCH_IMAGES_URL', JMS_WOOSEARCH_URL . 'images/');
define('JMS_WOOSEARCH_ADMIN_PATH' , JMS_WOOSEARCH_PLUGIN_PATH . 'admin/');
define( 'JMS_WOOSEARCH_VERSION', '1.0.0' );
require 'admin/params.php';
require 'admin/admin.php';
require 'front/widget.php';
require 'front/front.php';
register_activation_hook( __FILE__, 'woosearch_activate' );
function woosearch_activate() {
	global $wp_version;
	if ( version_compare( $wp_version, "5.0", "<" ) ) {
		deactivate_plugins( basename( __FILE__ ) ); // Deactivate our plugin
		wp_die( "This plugin requires WordPress version 5.0 or higher." );
	}
	if ( !function_exists( 'WC' ) ) {
		deactivate_plugins( basename( __FILE__ ) ); // Deactivate our plugin
		wp_die( "This plugin requires WooCommerce in order to work." );
	}
	$json_data = '{"min_chars":"3","posts_per_page":"3","show_image":"1","show_border_image":"1","image_position":"img_left","show_product_name":"1","show_price":"1","show_excerpt":"1","show_view_all":"1","show_excerpt_num_words":"10","show_search_button":"1","show_icon_search":"1","show_category":"1","default_product_cat":"1","hide_empty":"1","category_tree":"1","image_size":"thumbnail","title_color":"#000000","title_size":"16","title_font_weight":"700","border_width":"1","border_color":"#000000","select_box_text_color":"#000000","select_box_background":"#ffffff","select_box_border_width":"1","select_box_border_color":"#cccccc","search_input_text_color":"#000000","search_input_background":"#ffffff","search_input_border_width":"1","search_input_border_color":"#cccccc","search_button_background":"#000000","search_button_text_color":"#ffffff","search_button_border_width":"0","search_button_border_color":"#ffffff","custom_css":"","placeholder_text":"Start typing here...","view_all_text":"View all","no_results_text":"No results"}';
	if ( ! get_option( 'woosearch_params', '' ) ) {
		update_option( 'woosearch_params', json_decode( $json_data, true ) );
	}
}
register_deactivation_hook(__FILE__, 'woosearch_deactivation');
function woosearch_deactivation() {
	return true;
}
new WooSearch_Admin();
new WooSearch_Params();
new WooSearch_Widget();
new WooSearch_Front();