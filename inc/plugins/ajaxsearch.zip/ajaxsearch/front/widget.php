<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class WooSearch_Widget extends WP_Widget {
    public $params;
    public function __construct() {
        $widget_ops = array(
            'classname' => 'widget_ajax_product_search',
            'description' => 'WooCommerce Ajax Search',
        );
        parent::__construct( 'widget_ajax_product_search', esc_html__( 'WooCommerce Ajax Search', 'woosearch' ), $widget_ops );
        $this->params = new WooSearch_Params();
    }

    public function widget( $args, $instance ) {
        $show_category = ! empty( $instance['show_category'] ) ? '1' : '0';
        $show_search_button = ! empty( $instance['show_search_button'] ) ? '1' : '0';
        $show_icon_search = ! empty( $instance['show_icon_search'] ) ? '1' : '0';
        $hierarchical = ! empty( $instance['hierarchical'] ) ? '1' : '0';
        $hide_empty = ! empty( $instance['hide_empty'] ) ? '1' : '0';
        $default_product_cat = ! empty( $instance['default_product_cat'] ) ? '1' : '0';
        $level_to_show = ! empty( $instance['level_to_show'] ) ? (int)$instance['level_to_show'] : '0';

        echo $args['before_widget'];
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        echo do_shortcode("[woocommerce_ajax_search cat_box={$show_category} cat_default={$default_product_cat} hide_empty={$hide_empty} cat_level={$level_to_show} cat_tree={$hierarchical} search_button={$show_search_button} search_icon={$show_icon_search}]");
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title               = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'WooCommerce Ajax Search', 'woosearch' );
        $show_category       = isset( $instance['show_category'] ) ? (bool) $instance['show_category'] : $this->params->get_param( 'show_category' );
        $show_search_button       = isset( $instance['show_search_button'] ) ? (bool) $instance['show_search_button'] : $this->params->get_param( 'show_search_button' );
        $show_icon_search       = isset( $instance['show_icon_search'] ) ? (bool) $instance['show_icon_search'] : $this->params->get_param( 'show_icon_search' );
        $hierarchical        = isset( $instance['hierarchical'] ) ? (bool) $instance['hierarchical'] : $this->params->get_param( 'category_tree' );
        $hide_empty          = isset( $instance['hide_empty'] ) ? (bool) $instance['hide_empty'] : $this->params->get_param( 'hide_empty' );
        $default_product_cat = isset( $instance['default_product_cat'] ) ? (bool) $instance['default_product_cat'] : $this->params->get_param( 'default_product_cat' );
        $level_to_show       = isset( $instance['level_to_show'] ) ? (int)$instance['level_to_show'] : $this->params->get_param( 'category_parent' );
        $level = $this->params->get_all_level_taxonomy('product_cat');

        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'woosearch' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'show_category' ); ?>" name="<?php echo $this->get_field_name( 'show_category' ); ?>"<?php checked( $show_category ); ?> />
            <label for="<?php echo $this->get_field_id( 'show_category' ); ?>"><?php _e( 'Show Categories Select Box','woosearch'); ?></label><br />
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'hierarchical' ); ?>" name="<?php echo $this->get_field_name( 'hierarchical' ); ?>"<?php checked( $hierarchical ); ?> />
            <label for="<?php echo $this->get_field_id( 'hierarchical' ); ?>"><?php _e( 'Enable Categories Tree','woosearch' ); ?></label><br />
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'hide_empty' ); ?>" name="<?php echo $this->get_field_name( 'hide_empty' ); ?>"<?php checked( $hide_empty ); ?> />
            <label for="<?php echo $this->get_field_id( 'hide_empty' ); ?>"><?php _e( 'Hide Empty Categories' ); ?></label><br />
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'default_product_cat' ); ?>" name="<?php echo $this->get_field_name( 'default_product_cat' ); ?>"<?php checked( $default_product_cat ); ?> />
            <label for="<?php echo $this->get_field_id( 'default_product_cat' ); ?>"><?php _e( 'Show Product Default Categories (Uncategorized)','woosearch' ); ?></label><br />
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'show_search_button' ); ?>" name="<?php echo $this->get_field_name( 'show_search_button' ); ?>"<?php checked( $show_search_button ); ?> />
            <label for="<?php echo $this->get_field_id( 'show_search_button' ); ?>"><?php _e( 'Show Search Button','woosearch' ); ?></label><br />
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'show_icon_search' ); ?>" name="<?php echo $this->get_field_name( 'show_icon_search' ); ?>"<?php checked( $show_icon_search ); ?> />
            <label for="<?php echo $this->get_field_id( 'show_icon_search' ); ?>"><?php _e( 'Show Search Icon','woosearch' ); ?></label><br />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'level_to_show' ); ?>"><?php _e( 'Level to Show' ); ?></label>
            <select name="<?php echo $this->get_field_name( 'level_to_show' ); ?>" id="<?php echo $this->get_field_id( 'level_to_show' ); ?>">
                <option <?php selected( $level_to_show, '0' ) ?> value="0"><?php esc_html_e( 'All Categories', 'woosearch' ) ?></option>
                <?php for ($i = 1; $i <= $level; $i++) {?>
                    <option <?php selected( $level_to_show, $i ) ?> value="<?php echo esc_attr( $i ) ?>"><?php echo esc_html( 'Level '.$i ) ?></option>
                <?php } ?>
            </select>
        </p>
        <?php
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['show_category']     = ! empty( $new_instance['show_category'] ) ? 1 : 0;
        $instance['show_search_button']     = ! empty( $new_instance['show_search_button'] ) ? 1 : 0;
        $instance['show_icon_search']     = ! empty( $new_instance['show_icon_search'] ) ? 1 : 0;
        $instance['hierarchical']     = ! empty( $new_instance['hierarchical'] ) ? 1 : 0;
        $instance['hide_empty']     = ! empty( $new_instance['hide_empty'] ) ? 1 : 0;
        $instance['default_product_cat']     = ! empty( $new_instance['default_product_cat'] ) ? 1 : 0;
        $instance['level_to_show']     = ! empty( $new_instance['level_to_show'] ) ? $new_instance['level_to_show'] : 0;

        return $instance;
    }
}
?>