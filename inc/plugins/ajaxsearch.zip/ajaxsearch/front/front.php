<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WooSearch_Front {
	public $params;
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array($this, 'init_scripts'));
		add_action( 'wp_ajax_search_products', array( $this, 'woo_ajax_search_products' ) );
		add_action( 'wp_ajax_nopriv_search_products', array( $this, 'woo_ajax_search_products' ) );

		add_action( 'widgets_init', array( $this, 'register_woosearch_widget' ) );
		add_shortcode( 'woocommerce_ajax_search', array( $this, 'woo_ajax_search_shortcode' ) );

		$this->params = new WooSearch_Params();
	}
	public function init_scripts() {
		wp_register_script( 'semantic', JMS_WOOSEARCH_JS_URL . 'semantic.min.js', array( 'jquery' ), JMS_WOOSEARCH_VERSION );
		if(!wp_script_is('woosearch','registered')){
			wp_enqueue_script( 'woosearch', JMS_WOOSEARCH_JS_URL . 'woosearch.min.js', array( 'semantic','jquery' ), JMS_WOOSEARCH_VERSION );
			wp_localize_script( 'woosearch', 'WooSearch', array(
				'min_chars' => $this->params->get_param( 'min_chars' ),
				'image_position' => $this->params->get_param( 'image_position' ),
				'posts_per_page' => $this->params->get_param( 'posts_per_page' ),
				'no_results_text' => $this->params->get_param( 'no_results_text' ),
				'ajax_url' => admin_url( 'admin-ajax.php' )
			));
		}
		/*Custom*/
		$title_cl    		        = $this->params->get_param( 'title_color' );
		$title_size         	    = $this->params->get_param( 'title_size' ). 'px';
		$title_font_weight          = $this->params->get_param( 'title_font_weight' );
		$image_border_width   	    = $this->params->get_param( 'border_width' ). 'px';
		$image_border_color   	    = $this->params->get_param( 'border_color' );
		$select_box_text_color      = $this->params->get_param( 'select_box_text_color');
		$select_box_background      = $this->params->get_param( 'select_box_background');
		$select_box_border_width   	= $this->params->get_param( 'select_box_border_width' ). 'px';
		$select_box_border_color   	= $this->params->get_param( 'select_box_border_color' );
		$search_input_text_color    = $this->params->get_param( 'search_input_text_color');
		$search_input_background    = $this->params->get_param( 'search_input_background');
		$search_input_border_width  = $this->params->get_param( 'search_input_border_width' ). 'px';
		$search_input_border_color  = $this->params->get_param( 'search_input_border_color' );
		$search_button_text_color   = $this->params->get_param( 'search_button_text_color' );
		$search_button_background   = $this->params->get_param( 'search_button_background' );
		$search_button_border_width = $this->params->get_param( 'search_button_border_width' ). 'px';
		$search_button_border_color = $this->params->get_param( 'search_button_border_color' );
		$_custom_css 			    = $this->params->get_param( 'custom_css' );
		$custom_css   = "
            .selectbox_cat{
                color:{$select_box_text_color};
                background:{$select_box_background};
                border:{$select_box_border_width} solid {$select_box_border_color};
            }
            .ui.search .woo-s{
                color:{$search_input_text_color};
                background:{$search_input_background};
                border:{$search_input_border_width} solid {$search_input_border_color};
            }
            .ui.search .woo-searchsubmit{
                color:{$search_button_text_color};
                background:{$search_button_background};
                border:{$search_button_border_width} solid {$search_button_border_color};
            }
            .ui.search .result .title{
                color:{$title_cl};
                font-size:{$title_size};
                font-weight:{$title_font_weight};
            }
            .ui.search .result img{
                border:{$image_border_width} solid {$image_border_color};
            }" . $_custom_css;

		if(!wp_style_is('woosearch','registered')){
			wp_enqueue_style( 'woosearch', JMS_WOOSEARCH_CSS_URL . 'woosearch.css', array(), JMS_WOOSEARCH_VERSION );
			wp_add_inline_style( 'woosearch', $custom_css );
		}
	}

	public function register_woosearch_widget(){
		register_widget( 'WooSearch_Widget' );
	}

	public function woo_ajax_search_products() {
		$search_keyword =  $_REQUEST['s'];
		$posts_per_page = $this->params->get_param( 'posts_per_page' );
		$show_image = $this->params->get_param( 'show_image' );
		$show_excerpt = $this->params->get_param( 'show_excerpt' );
		$show_price = $this->params->get_param( 'show_price' );
		$show_excerpt_num_words = $this->params->get_param( 'show_excerpt_num_words' );
		$show_product_name = $this->params->get_param( 'show_product_name' );
		$show_view_all = $this->params->get_param( 'show_view_all' );
		$image_size = $this->params->get_param( 'image_size' );
		$view_all_text = $this->params->get_param( 'view_all_text' );

		$args = array(
			's'                   =>  $search_keyword,
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => -1,
			'suppress_filters'    => false,
		);

		if ( isset( $_REQUEST['product_cat'] ) && !empty($_REQUEST['product_cat'])) {
			$args['tax_query'] = array(
				'relation' => 'AND',
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'slug',
					'terms'    => $_REQUEST['product_cat']
				)
			);
		}

		$product_visibility_term_ids = wc_get_product_visibility_term_ids();
		$args['tax_query'][] = array(
			'taxonomy' => 'product_visibility',
			'field'    => 'term_taxonomy_id',
			'terms'    => $product_visibility_term_ids['exclude-from-search'],
			'operator' => 'NOT IN',
		);

		$products = get_posts( $args );
		$rs = [];
		if ( !empty( $products ) ) {
			foreach ( $products as $post ) {
				$product = wc_get_product( $post );

				if($show_product_name) $data['title'] = strip_tags($product->get_title());
				if($show_excerpt) $data['description'] = wp_trim_words($product->get_short_description(),$show_excerpt_num_words,'...');
				if($show_price) $data['price'] = $product->get_price_html();

				if($show_image){
					if ( has_post_thumbnail( $product->get_id() ) ) {
						$image_link = get_the_post_thumbnail_url( $product->get_id(), $image_size);
					} elseif ( $product->get_type() == 'variation' ) {
						$parent_id  = $product->get_parent_id();
						$image_link = get_the_post_thumbnail_url( $parent_id, $image_size);
					} else {
						$image_link = '';
					}
					$data['image'] = $image_link;
				}

				if(is_array($data) && !empty($data)){
					if ( $product->is_type( 'external' )) {
						$link = get_post_meta( $product->get_id(), '_product_url', '#' );
						if ( ! $link ) {
							$link = get_permalink( $product->get_id() );
							$link = wp_nonce_url( $link, 'woosearch_click', 'link' );
						}
					} else {
						$link = get_permalink( $product->get_id() );
						$link = wp_nonce_url( $link, 'woosearch_click', 'link' );
					}
					$data['url'] =  $link;
					$rs[] = $data;
				}
			}
		}
		wp_reset_postdata();
		$rs = array('results' => $rs);
		if($posts_per_page < count($products) && $show_view_all){
			$url = add_query_arg(array(
				's' => $search_keyword,
				'post_type' => 'product'
			),home_url('/'));
			$rs['action'] = array(
				'url'  => esc_url($url),
				'text' => $view_all_text,
			);
		}
		echo json_encode( $rs );
		die();
	}

	public function get_level($category, $level = 0){
		if ($category->parent == 0) {
			return $level;
		} else {
			$level++;
			$category = get_term_by('id',$category->parent,'product_cat');
			return $this->get_level($category, $level);
		}
	}

	public function get_product_cat_by_level( $level = 0){
		$args = array(
			'taxonomy' => 'product_cat',
			'hide_empty' => 0
		);
		if(!$level) $args['parent'] = 0;
		$cats = get_categories( $args );
		$include = [];
		if( $cats ){
			foreach($cats as $cat){
				$current_cat_level = $this->get_level($cat);
				if( $current_cat_level >= $level ){
					$include[] = $cat->cat_ID;
				}
			}
		}
		return $include;
	}
	protected function checkFirstCharacter($color,$check = '#'){
		$firstCharacter = substr($color, 0, 1);
		if($firstCharacter !== $check) return '#'.$color;
		return $color;
	}

	public function woo_ajax_search_shortcode( $args = array() ) {
		do_action('woo_ajaxsearch_before',$args);
		$atts = shortcode_atts( array(
			'cat_box'          => $this->params->get_param( 'show_category' ),
			'cat_level'        => $this->params->get_param( 'category_parent' ),
			'cat_tree'         => $this->params->get_param( 'category_tree' ),
			'search_button'    => $this->params->get_param( 'show_search_button' ),
			'search_icon'      => $this->params->get_param( 'show_icon_search' ),
			'hide_empty'       => $this->params->get_param( 'hide_empty' ),
			'cat_default'      => $this->params->get_param( 'default_product_cat' ),
			'cat_box_bg'       => $this->params->get_param( 'select_box_background' ),
			'cat_box_color'    => $this->params->get_param( 'select_box_text_color' ),
			'cat_box_bw'       => $this->params->get_param( 'select_box_border_width' ),
			'cat_box_bc'       => $this->params->get_param( 'select_box_border_color' ),
			'input_bg'         => $this->params->get_param( 'search_input_background' ),
			'input_color'      => $this->params->get_param( 'search_input_text_color' ),
			'input_bw'         => $this->params->get_param( 'search_input_border_width' ),
			'input_bc'         => $this->params->get_param( 'search_input_border_color' ),
			'button_bg'        => $this->params->get_param( 'search_button_background' ),
			'button_color'     => $this->params->get_param( 'search_button_border_color' ),
			'button_bw'     => $this->params->get_param( 'search_button_border_width' ),
			'button_bc'     => $this->params->get_param( 'search_button_border_color' ),
			'placeholder'   => $this->params->get_param( 'placeholder_text' )
		), $args );

		$id =  'jms-wooajax-'.md5(uniqid(rand(), true));
		$sc_css = "";
		if(!empty($args['cat_box_bg']) || !empty($args['cat_box_color']) || !empty($args['cat_box_bw']) || !empty($args['cat_box_bc'])){
			$sc_css .= "
                #{$id} .selectbox_cat{
                    color:{$this->checkFirstCharacter($atts['cat_box_color'])};
                    background:{$this->checkFirstCharacter($atts['cat_box_bg'])};
                    border:{$atts['cat_box_bw']}px solid {$this->checkFirstCharacter($atts['cat_box_bc'])};
                }
            ";
		}
		if(!empty($args['input_bg']) || !empty($args['input_color']) || !empty($args['input_bw']) || !empty($args['input_bc'])){
			$sc_css .= "
                #{$id} .woo-s{
                    color:{$this->checkFirstCharacter($atts['input_color'])};
                    background:{$this->checkFirstCharacter($atts['input_bg'])};
                    border:{$atts['input_bw']}px solid {$this->checkFirstCharacter($atts['input_bc'])};
                }
            ";
		}
		if(!empty($args['button_bg']) || !empty($args['button_color']) || !empty($args['button_bw']) || !empty($args['button_bc'])){
			$sc_css .= "
                #{$id} .woo-searchsubmit{
                    color:{$this->checkFirstCharacter($atts['button_color'])};
                    background:{$this->checkFirstCharacter($atts['button_bg'])};
                    border:{$atts['button_bw']}px solid {$this->checkFirstCharacter($atts['button_bc'])};
                }
            ";
		}
		wp_register_style( 'woosearch-custom', false );
		wp_enqueue_style( 'woosearch-custom' );
		wp_add_inline_style( 'woosearch-custom', $sc_css );

		ob_start();
		?>
        <div class="woo-ajaxsearchform-container" id="<?php echo $id; ?>">
            <form role="search" method="get" id="woo-ajaxsearchform" action="<?php echo esc_url( home_url( '/'  ) ) ?>">
				<?php if(intval($atts['cat_box'])) {?>
					<?php
					$include =  filter_var($atts['cat_level'],FILTER_VALIDATE_BOOLEAN) ? $this->get_product_cat_by_level($atts['cat_level'],true) : '';
					?>
                    <div class="searchform-select">
						<?php
						$args = array(
							'show_option_all' => esc_html__('All Categories', 'woosearch'),
							'hierarchical' => intval($atts['cat_tree']),
							'class' => 'selectbox_cat',
							'echo' => 1,
							'value_field' => 'slug',
							'taxonomy' => 'product_cat',
							'depth' => 0,
							'hide_empty' => intval($atts['hide_empty']),
							'include' => $include,
							'name' => 'product_cat'
						);
						if( filter_var($atts['cat_default'],FILTER_VALIDATE_BOOLEAN) === FALSE ) $args['exclude'] = get_option( 'default_product_cat' );
						wp_dropdown_categories($args);
						?>
                    </div>
				<?php } ?>
                <div class="ui search">
                    <div class="ui icon input">
                        <label class="screen-reader-text" for="woo-s"><?php _e( 'Search for:', 'woosearch' ) ?></label>
                        <input type="search"
                               value="<?php echo get_search_query(); ?>"
                               name="s"
                               id="woo-s"
                               class="woo-s prompt"
                               placeholder="<?php echo $atts['placeholder']; ?>"/>
                        <i class="search icon <?php if(intval($atts['search_icon'])) echo 'show-icon'; ?>"></i>
                    </div>
                    <div class="results"></div>
					<?php if(intval($atts['search_button'])){ ?>
                        <input type="submit" id="woo-searchsubmit" class="woo-searchsubmit" value="<?php _e( 'Search', 'woosearch' ) ?>" />
					<?php } ?>
                    <input type="hidden" name="post_type" value="product" />
                </div>
            </form>
        </div>
		<?php
		return ob_get_clean();
	}
}
?>