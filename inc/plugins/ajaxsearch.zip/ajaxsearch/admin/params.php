<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WooSearch_Params {
	static $params;
	private static $messages = array();
	private static $errors   = array();
	public function __construct() {
		add_action( 'admin_init', array( $this, 'save_params_trigger' ) );
	}

	public function save_params_trigger() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}
		if ( ! isset( $_POST['_woosearch_nonce'] ) || ! isset( $_POST['woosearch_params'] ) ) {
			return false;
		}
		//update_option( '_woosearch_prefix', substr( md5( date( "YmdHis" ) ), 0, 10 ) );
		update_option( 'woosearch_params', $_POST['woosearch_params'] );
		if(isset( $_POST['woosearch_params']))
			self::add_message( __( 'Your settings have been saved.', 'woosearch' ) );

	}
	public static function add_error( $text ) {
		self::$errors[] = $text;
	}
	public static function add_message( $text ) {
		self::$messages[] = $text;
	}
	public static function show_messages() {
		if ( count( self::$errors ) > 0 ) {
			foreach ( self::$errors as $error ) {
				echo '<div id="message" class="error inline"><p><strong>' . esc_html( $error ) . '</strong></p></div>';
			}
		} elseif ( count( self::$messages ) > 0 ) {
			echo '<div id="message" class="updated inline"><p><strong>' . esc_html( self::$messages[0] ) . '</strong></p></div>';
		}
	}
	protected static function set_nonce() {
		return wp_nonce_field( '_woosearch_setting_form_', '_woosearch_nonce' );
	}
	protected static function gen_param_name( $_param, $multi = false ) {
		if ( $_param ) {
			if ( $multi ) {
				return 'woosearch_params[' . $_param . '][]';
			} else {
				return 'woosearch_params[' . $_param . ']';
			}
		} else {
			return '';
		}
	}
	public static function get_param( $_param, $default = '' ) {
		$params = get_option( 'woosearch_params', array() );
		if ( self::$params ) {
			$params = self::$params;
		} else {
			self::$params = $params;
		}
		if ( isset( $params[$_param] ) && $_param ) {
			return $params[$_param];
		} else {
			return $default;
		}
	}
	protected static function get_image_sizes() {
		global $_wp_additional_image_sizes;

		$sizes = array();
		$array = get_intermediate_image_sizes();
		$filterArray = array_filter($array, function ($var) {
			return (strpos($var, 'woocommerce') !== false);
		});
		array_unshift($filterArray, "thumbnail");
		foreach ( $filterArray as $_size ) {
			if ( in_array( $_size, array('thumbnail', 'medium', 'medium_large', 'large') ) ) {
				$sizes[ $_size ]['width']  = get_option( "{$_size}_size_w" );
				$sizes[ $_size ]['height'] = get_option( "{$_size}_size_h" );
				$sizes[ $_size ]['crop']   = (bool) get_option( "{$_size}_crop" );
			} elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
				$sizes[ $_size ] = array(
					'width'  => $_wp_additional_image_sizes[ $_size ]['width'],
					'height' => $_wp_additional_image_sizes[ $_size ]['height'],
					'crop'   => $_wp_additional_image_sizes[ $_size ]['crop'],
				);
			}
		}

		return $sizes;
	}

	public static function get_all_level_taxonomy($taxonomy,$parent = '')
	{
		$args = array(
			'parent' => $parent,
			'hide_empty' => false
		);
		$terms = get_terms($taxonomy, $args);
		$max_depth = 0;
		foreach ($terms as $term) {
			if($term->parent){
				$depth = static::get_all_level_taxonomy($taxonomy,$term->term_id) + 1;
				if ($depth > $max_depth) {
					$max_depth = $depth;
				}
			}
		}
		return $max_depth;
	}

	public static function params_form() {
		self::$params = get_option( 'woosearch_params', array() );
		?>
        <div class="wrap woo-notification">
            <h2><?php esc_attr_e( 'WooCommerce Ajax Search Settings', 'woosearch' ) ?></h2>
			<?php self::show_messages(); ?>
            <form method="post" action="" class="ui form mt-3">
				<?php
				//settings_fields( 'woosearch_setting_form' );
				//do_settings_sections( 'woosearch_setting_form' );
				?>
				<?php echo ent2ncr( self::set_nonce() ) ?>
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#general"><?php esc_html_e( 'General', 'woosearch' ) ?></a></li>
                    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#output"><?php esc_html_e( 'Output', 'woosearch' ) ?></a></li>
                    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#customstyle"><?php esc_html_e( 'Custom Style', 'woosearch' ) ?></a></li>
                    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#document"><?php esc_html_e( 'Plugin Userguide', 'woosearch' ) ?></a></li>
                </ul>
                <div class="tab-content">
                    <div id="general" class="tab-pane fade in active show">
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Minimum number of characters', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="fields">
                                    <div class="twelve field">
                                        <input type="number" name="<?php echo self::gen_param_name( 'min_chars' ) ?>" value="<?php echo self::get_param( 'min_chars', '3' ) ?>" />
                                    </div>
                                </div>
                                <p class="description"><?php esc_html_e( 'Minimum number of characters required to start search.', 'woosearch' ) ?></p>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Number of Results to Show', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="fields">
                                    <div class="twelve field">
                                        <input type="number" name="<?php echo self::gen_param_name( 'posts_per_page' ) ?>" value="<?php echo self::get_param( 'posts_per_page', '3' ) ?>" />
                                    </div>
                                </div>
                                <p class="description"><?php esc_html_e( 'Number of results showed in search box.', 'woosearch' ) ?></p>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show Categories Select Box', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'show_category' ) ?>" type="checkbox" <?php checked( self::get_param( 'show_category' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'show_category' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row form_category">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Enable Categories Tree', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'category_tree' ) ?>" type="checkbox" <?php checked( self::get_param( 'category_tree' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'category_tree' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row form_category">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show Product Default Categories (Uncategorized)', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'default_product_cat' ) ?>" type="checkbox" <?php checked( self::get_param( 'default_product_cat' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'default_product_cat' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row form_category">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Hide Empty Categories', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'hide_empty' ) ?>" type="checkbox" <?php checked( self::get_param( 'hide_empty' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'hide_empty' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row form_category">
							<?php
							$level = self::get_all_level_taxonomy('product_cat');
							?>
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Level to Show', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <select name="<?php echo self::gen_param_name( 'category_parent' ) ?>" class="ui fluid dropdown">
                                    <option <?php selected( self::get_param( 'category_parent' ), '0' ) ?> value="0"><?php esc_html_e( 'All Categories', 'woosearch' ) ?></option>
									<?php for ($i = 1; $i <= $level; $i++) {?>
                                        <option <?php selected( self::get_param( 'category_parent' ), $i ) ?> value="<?php echo esc_attr( $i ) ?>">Level <?php echo esc_html( $i ) ?></option>
									<?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show Search Button', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'show_search_button' ) ?>" type="checkbox" <?php checked( self::get_param( 'show_search_button' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'show_search_button' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show Search Icon', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'show_icon_search' ) ?>" type="checkbox" <?php checked( self::get_param( 'show_icon_search' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'show_icon_search' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="output" class="tab-pane fade">
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show Image', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'show_image' ) ?>" type="checkbox" <?php checked( self::get_param( 'show_image' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'show_image' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row form_image">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Image Size', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <select name="<?php echo self::gen_param_name( 'image_size' ) ?>" class="ui fluid dropdown">
									<?php
									$image_size = self::get_image_sizes();
									if ( count( $image_size ) ) :
										foreach ( $image_size as $key => $size ) : ?>
                                            <option <?php selected( self::get_param( 'image_size' ), $key ) ?> value="<?php echo esc_attr( $key ) ?>"><?php echo esc_html( ucwords($key) ) ?> (Size : <?php echo esc_attr($size['width']) .'x'. esc_attr($size['height'])?>)</option>
										<?php
										endforeach;
									endif;
									?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row form_image">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Image Position', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <select name="<?php echo self::gen_param_name( 'image_position' ) ?>" class="ui fluid dropdown">
                                    <option <?php selected( self::get_param( 'image_position' ), 'img_left' ) ?> value="img_left">Image at Left</option>
                                    <option <?php selected( self::get_param( 'image_position' ), 'img_right' ) ?> value="img_right">Image at Right</option>
                                    <option <?php selected( self::get_param( 'image_position' ), 'img_top' ) ?> value="img_top">Image at Top</option>
                                    <option <?php selected( self::get_param( 'image_position' ), 'img_bottom' ) ?> value="img_bottom">Image at Bottom</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show Product Name', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'show_product_name' ) ?>" type="checkbox" <?php checked( self::get_param( 'show_product_name' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'show_product_name' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show Product Price', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'show_price' ) ?>" type="checkbox" <?php checked( self::get_param( 'show_price' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'show_price' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show Product Short Desc', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'show_excerpt' ) ?>" type="checkbox" <?php checked( self::get_param( 'show_excerpt' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'show_excerpt' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row form_excerpt">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Number of Words to Show in Excerpt', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input id="<?php echo self::gen_param_name( 'show_excerpt_num_words' ) ?>" type="number" tabindex="0" value="<?php echo self::get_param( 'show_excerpt_num_words', 10 ) ?>" name="<?php echo self::gen_param_name( 'show_excerpt_num_words' ) ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Placeholder input text', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input id="<?php echo self::gen_param_name( 'placeholder_text' ) ?>" type="text" tabindex="0" value="<?php echo self::get_param( 'placeholder_text', 'Start typing here...' ) ?>" name="<?php echo self::gen_param_name( 'placeholder_text' ) ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show "View all" link', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'show_view_all' ) ?>" type="checkbox" <?php checked( self::get_param( 'show_view_all' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'show_view_all' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Text of "View all" link', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input id="<?php echo self::gen_param_name( 'view_all_text' ) ?>" type="text" tabindex="0" value="<?php echo self::get_param( 'view_all_text', 'View all' ) ?>" name="<?php echo self::gen_param_name( 'view_all_text' ) ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Text of "No results"', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input id="<?php echo self::gen_param_name( 'no_results_text' ) ?>" type="text" tabindex="0" value="<?php echo self::get_param( 'no_results_text', 'No results' ) ?>" name="<?php echo self::gen_param_name( 'no_results_text' ) ?>" />
                            </div>
                        </div>
                    </div>
                    <div id="customstyle" class="tab-pane fade">
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Product Name Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'title_color', '#000000' ) ?>" name="<?php echo self::gen_param_name( 'title_color' ) ?>" class="color-field" data-default-color="#000000" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Product Name Font Size', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input id="<?php echo self::gen_param_name( 'title_size' ) ?>" type="number" tabindex="0" value="<?php echo self::get_param( 'title_size', 13 ) ?>" name="<?php echo self::gen_param_name( 'title_size' ) ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Product Name Font Weight ', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <select name="<?php echo self::gen_param_name( 'title_font_weight' ) ?>" class="ui fluid dropdown">
                                    <option <?php selected( self::get_param( 'title_font_weight' ), '100' ) ?> value="100">Thin (100)</option>
                                    <option <?php selected( self::get_param( 'title_font_weight' ), '200' ) ?> value="200">Extra Light (200)</option>
                                    <option <?php selected( self::get_param( 'title_font_weight' ), '300' ) ?> value="300">Light (300)</option>
                                    <option <?php selected( self::get_param( 'title_font_weight' ), '400' ) ?> value="400">Normal (400)</option>
                                    <option <?php selected( self::get_param( 'title_font_weight' ), '500' ) ?> value="500">Medium (500)</option>
                                    <option <?php selected( self::get_param( 'title_font_weight' ), '600' ) ?> value="600">Semi Bold (600)</option>
                                    <option <?php selected( self::get_param( 'title_font_weight' ), '700' ) ?> value="700">Bold (700)</option>
                                    <option <?php selected( self::get_param( 'title_font_weight' ), '800' ) ?> value="800">Extra Bold (800)</option>
                                    <option <?php selected( self::get_param( 'title_font_weight' ), '900' ) ?> value="900">Black (900)</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Show Border Image', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <div class="ui toggle checkbox">
                                    <input id="<?php echo self::gen_param_name( 'show_border_image' ) ?>" type="checkbox" <?php checked( self::get_param( 'show_border_image' ), 1 ) ?> tabindex="0" class="hidden" value="1" name="<?php echo self::gen_param_name( 'show_border_image' ) ?>" />
                                    <label></label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row form_border_image">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Image Border Width ', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input id="<?php echo self::gen_param_name( 'border_width' ) ?>" type="number" tabindex="0" value="<?php echo self::get_param( 'border_width', 1 ) ?>" name="<?php echo self::gen_param_name( 'border_width' ) ?>" />
                            </div>
                        </div>
                        <div class="form-group row form_border_image">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Image Border Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'border_color', '#000000' ) ?>" name="<?php echo self::gen_param_name( 'border_color' ) ?>" class="color-field" data-default-color="#000000" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Select Box Text Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'select_box_text_color', '#000000' ) ?>" name="<?php echo self::gen_param_name( 'select_box_text_color' ) ?>" class="color-field" data-default-color="#000000" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Select Box Background Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'select_box_background', '#ffffff' ) ?>" name="<?php echo self::gen_param_name( 'select_box_background' ) ?>" class="color-field" data-default-color="#ffffff" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Select Box Border Width ', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input id="<?php echo self::gen_param_name( 'select_box_border_width' ) ?>" type="number" tabindex="0" value="<?php echo self::get_param( 'select_box_border_width', 1 ) ?>" name="<?php echo self::gen_param_name( 'select_box_border_width' ) ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Select Box Border Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'select_box_border_color', '#cccccc' ) ?>" name="<?php echo self::gen_param_name( 'select_box_border_color' ) ?>" class="color-field" data-default-color="#cccccc" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Search Input Text Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'search_input_text_color', '#000000' ) ?>" name="<?php echo self::gen_param_name( 'search_input_text_color' ) ?>" class="color-field" data-default-color="#000000" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Search Input  Background Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'search_input_background', '#ffffff' ) ?>" name="<?php echo self::gen_param_name( 'search_input_background' ) ?>" class="color-field" data-default-color="#ffffff" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Search Input Border Width ', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input id="<?php echo self::gen_param_name( 'search_input_border_width' ) ?>" type="number" tabindex="0" value="<?php echo self::get_param( 'search_input_border_width', 1 ) ?>" name="<?php echo self::gen_param_name( 'search_input_border_width' ) ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Search Input Border Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'search_input_border_color', '#cccccc' ) ?>" name="<?php echo self::gen_param_name( 'search_input_border_color' ) ?>" class="color-field" data-default-color="#cccccc" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Search Button Text Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'search_button_text_color', '#ffffff' ) ?>" name="<?php echo self::gen_param_name( 'search_button_text_color' ) ?>" class="color-field" data-default-color="#ffffff" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Search Button  Background Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'search_button_background', '#000000' ) ?>" name="<?php echo self::gen_param_name( 'search_button_background' ) ?>" class="color-field" data-default-color="#000000" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Search Button Border Width ', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input id="<?php echo self::gen_param_name( 'search_button_border_width' ) ?>" type="number" tabindex="0" value="<?php echo self::get_param( 'search_button_border_width', 0 ) ?>" name="<?php echo self::gen_param_name( 'search_button_border_width' ) ?>" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Search Button Border Color', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
                                <input type="text" value="<?php echo self::get_param( 'search_button_border_color', '#ffffff' ) ?>" name="<?php echo self::gen_param_name( 'search_button_border_color' ) ?>" class="color-field" data-default-color="#ffffff" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold"><?php esc_html_e( 'Custom CSS', 'woosearch' ) ?></label>
                            <div class="col-sm-10">
								<?php $custom_css = self::get_param( 'custom_css', '' );?>
                                <textarea name="<?php echo self::gen_param_name( 'custom_css') ?>"><?php echo $custom_css ?></textarea>
                                <p class="description"><?php esc_html_e( 'You can add custom css', 'woosearch' ) ?></p>
                            </div>
                        </div>
                    </div>
                    <div id="document" class="tab-pane fade">
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <h3>WooCommerce Ajax Search following 2 ways below :</h3>
                                <ul>
                                    <li>
                                        <h4>1 - Using in Widget</h4>
                                        <p class="mb-3">You can go to Appearance >> Widgets add WooCommerce Ajax Search to Sidebar to use</p>
                                    </li>
                                    <li>
                                        <h4>2 - Using via ShortCode</h4>
                                        <p>WooCommerce Ajax Search provides shortcode with structure below :</p>
                                        <pre><code>[woocommerce_ajax_search cat_box=1 cat_default=1 hide_empty=1 cat_level=0 cat_tree=1 search_button=1 search_icon=1]</code></pre>
                                        <p>Shortcode Attributes:</p>
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item border-0"><code>cat_box</code> – Show categories select box. The default is “1” which will show categories select box. Set to “0” to hide categories select box.</li>
                                            <li class="list-group-item border-0"><code>cat_default</code> – The default is “1” which will show default(uncategorized) categories. Set to “0” to hide default(uncategorized) categories</li>
                                            <li class="list-group-item border-0"><code>hide_empty</code> – The default is “1” which will hide empty categories. Set to “0” to show empty categories.</li>
                                            <li class="list-group-item border-0"><code>cat_level</code> – Display the categories by level. The default is “0” which will show all categories. Level of categories will automatically load.</li>
                                            <li class="list-group-item border-0"><code>cat_tree</code> – Display the categories in a hierarchical structure. The default is “1”.</li>
                                            <li class="list-group-item border-0"><code>search_button</code> – Show search button. The default is “1” which will show search button. Set to “0” to hide search button.</li>
                                            <li class="list-group-item border-0"><code>search_icon</code> – Show search icon. The default is “1” which will show search icon. Set to “0” to hide search icon.</li>
                                            <li class="list-group-item border-0"><code>cat_box_bg</code> – Categories select box background color. &nbsp; Eg: <code>cat_box_bg="dd3333"</code>.</li>
                                            <li class="list-group-item border-0"><code>cat_box_color</code> – Categories select box text color. &nbsp; Eg: <code>cat_box_color="000000"</code>.</li>
                                            <li class="list-group-item border-0"><code>cat_box_bw</code> – Categories select box border-width. &nbsp; Eg: <code>cat_box_bw=1</code></li>
                                            <li class="list-group-item border-0"><code>cat_box_bc</code> – Categories select box border-color. &nbsp; Eg: <code>cat_box_bc="cccccc"</code></li>
                                            <li class="list-group-item border-0"><code>input_bg</code> –  Search input background color. &nbsp; Eg: <code>input_bg="333333"</code></li>
                                            <li class="list-group-item border-0"><code>input_color</code> – Search input text color. &nbsp; Eg: <code>input_color="ffffff"</code></li>
                                            <li class="list-group-item border-0"><code>input_bw</code> – Search input border-width. &nbsp; Eg: <code>input_bw=1</code></li>
                                            <li class="list-group-item border-0"><code>input_bc</code> – Search input border-color. &nbsp; Eg: <code>input_bc="cccccc"</code></li>
                                            <li class="list-group-item border-0"><code>button_bg</code> – Search button background color. &nbsp; Eg: <code>button_bg="e10000"</code></li>
                                            <li class="list-group-item border-0"><code>button_color</code> – Search button text color. &nbsp; Eg: <code>button_color="81d742"</code></li>
                                            <li class="list-group-item border-0"><code>button_bw</code> – Search button border-width. &nbsp; Eg: <code>button_bw=1</code></li>
                                            <li class="list-group-item border-0"><code>button_bc</code> – Search button border-color. &nbsp; Eg: <code>button_bc="cccccc"</code></li>
                                        </ul>
                                        <h4>You can use shortcode by inserting in the template the following php code:</h4>
                                        <pre><code>&lt;?php echo do_shortcode('[woocommerce_ajax_search]');?&gt;</code></pre>
                                        <p>if use [woocommerce_ajax_search] it will get default settings of plugin in backend.</p>
                                        <p>Or</p>
                                        <pre><code>&lt;?php echo do_shortcode('[woocommerce_ajax_search cat_box=1 cat_default=1 hide_empty=1 cat_level=0 cat_tree=1 search_button=1 search_icon=1]');?&gt;</code></pre>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <p style="position: relative; z-index: 99999; margin-bottom: 70px; display: inline-block;">
                    <input type="submit" class="h-100 ui button primary" value=" <?php esc_html_e( 'Save', 'woosearch' ) ?> " />
                </p>
            </form>
        </div>
		<?php
	}
}
?>