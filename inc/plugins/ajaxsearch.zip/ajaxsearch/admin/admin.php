<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WooSearch_Admin {
    function __construct() {
        add_action( 'init', array( $this, 'woosearch_load_textdomain' ) );
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 99999 );
    }

    /**
     * Register a custom menu page.
     */
    public function add_admin_menu() {
        add_menu_page( esc_html__( 'Woo Ajax Search', 'woosearch' ), esc_html__( 'Woo Ajax Search', 'woosearch' ), 'manage_options', 'woosearch', array(
            'WooSearch_Params',
            'params_form'
        ), 'dashicons-admin-comments', 888 );

    }
    public function register_plugin_settings() {
        //register our settings
        register_setting( 'woosearch_setting_form', 'woosearch_params' );
    }
    function woosearch_load_textdomain() {
        load_plugin_textdomain( 'woosearch', false, dirname( plugin_basename(__FILE__) ) . '/languages' );
    }
    public function admin_enqueue_scripts() {
        $page = isset( $_REQUEST['page'] ) ? $_REQUEST['page'] : '';
        if ( $page == 'woosearch' ) {
            wp_enqueue_style( 'woosearch-bootstrap', JMS_WOOSEARCH_CSS_URL . 'bootstrap.min.css' );
            wp_enqueue_style( 'woosearch-semantic', JMS_WOOSEARCH_CSS_URL . 'semantic.min.css' );
            wp_enqueue_style( 'woosearch-admin', JMS_WOOSEARCH_CSS_URL . 'admin.css' );
            wp_enqueue_style('wp-color-picker');
            wp_enqueue_script( 'woosearch-bootstrap', JMS_WOOSEARCH_JS_URL . 'bootstrap.min.js', array( 'jquery' ) );
            wp_enqueue_script( 'woosearch-semantic', JMS_WOOSEARCH_JS_URL . 'semantic.min.js', array( 'jquery' ) );
            wp_enqueue_script( 'woosearch-admin', JMS_WOOSEARCH_JS_URL . 'admin.js', array( 'jquery' ) );
            wp_enqueue_script('wp-color-picker');
        }
    }
}

?>
