'use strict';
jQuery(document).ready(function () {	
	jQuery('.ui.checkbox').checkbox();
	jQuery('.ui.dropdown.multi').each(function() { 		
		var values = jQuery(this).parent().find('.selected_vals').eq(0).val();
		if(values)
			jQuery(this).dropdown("set selected", values.split(','));					
		else 
			jQuery(this).dropdown();			
    })
    jQuery('.color-field').wpColorPicker();
    jQuery('input[name="woosearch_params[show_image]"]').on('change', function () {
        if(this.checked) {
            jQuery('.form_image').show();
		}else{
            jQuery('.form_image').hide();
		}
    });
    jQuery('input[name="woosearch_params[show_excerpt]"]').on('change', function () {
        if(this.checked) {
            jQuery('.form_excerpt').show();
        }else{
            jQuery('.form_excerpt').hide();
        }
    });
    jQuery('input[name="woosearch_params[show_border_image]"]').on('change', function () {
        if(this.checked) {
            jQuery('.form_border_image').show();
        }else{
            jQuery('.form_border_image').hide();
        }
    });
    jQuery('input[name="woosearch_params[show_category]"]').on('change', function () {
        if(this.checked) {
            jQuery('.form_category').show();
        }else{
            jQuery('.form_category').hide();
        }
    });
    function assign_page_oncheck() {
        if(!jQuery('input[name="woosearch_params[show_image]"]').is(":checked")) jQuery('.form_image').hide();
        if(!jQuery('input[name="woosearch_params[show_excerpt]"]').is(":checked")) jQuery('.form_excerpt').hide();
        if(!jQuery('input[name="woosearch_params[show_border_image]"]').is(":checked")) jQuery('.form_border_image').hide();
        if(!jQuery('input[name="woosearch_params[show_category]"]').is(":checked")) jQuery('.form_category').hide();
    }
    assign_page_oncheck();
});