(function ($) {
    'use strict';
    $.fn.search.settings.templates.special = function(response,fields) {
        var html = '',
            image_position = WooSearch.image_position || 'image-left';
        if(response[fields.results] !== undefined) {

            // each result
            $.each(response[fields.results], function(index, result) {
                var reverse = (image_position == 'img_bottom')?'result reverse':'result';
                if(result[fields.url]) {
                    html  += '<a class="'+ reverse +'" href="' + result[fields.url] + '">';
                }
                else {
                    html  += '<a class="' + reverse +'">';
                }
                if(result[fields.image] !== undefined) {
                    html += ''
                        + '<div class="image '+ image_position + '">'
                        + ' <img src="' + result[fields.image] + '">'
                        + '</div>'
                    ;
                }
                html += '<div class="content">';
                if(result[fields.title] !== undefined) {
                    html += '<div class="title">' + result[fields.title] + '</div>';
                }
                if(result[fields.price] !== undefined) {
                    html += '<div class="price">' + result[fields.price] + '</div>';
                }
                if(result[fields.description] !== undefined) {
                    html += '<div class="description">' + result[fields.description] + '</div>';
                }
                html  += ''
                    + '</div>'
                ;
                html += '</a>';
            });
            if(response[fields.action]) {
                html += ''
                    + '<a href="' + response[fields.action][fields.actionURL] + '" class="action">'
                    +   response[fields.action][fields.actionText]
                    + '</a>';
            }
            return html;
        }
        return false;
    };
    $.fn.search.settings.templates.message = function(message, type) {
        var
            html = ''
        ;
        if(message !== undefined && type !== undefined) {
            html +=  ''
                + '<div class="message ' + type + '">'
            ;
            // message type
            if(type == 'empty') {
                html += ''
                    + '<div class="header">' + WooSearch.no_results_text + '</div class="header">'
                    + '<div class="description">' + message + '</div class="description">'
                ;
            }
            else {
                html += ' <div class="description">' + message + '</div>';
            }
            html += '</div>';
        }
        return html;
    };
    $.fn.serializeObject = function() {
        var obj = {};
        var arr = this.serializeArray();
        arr.forEach(function(item, index) {
            if (obj[item.name] === undefined) { // New
                obj[item.name] = item.value || '';
            } else {                            // Existing
                if (!obj[item.name].push) {
                    obj[item.name] = [obj[item.name]];
                }
                obj[item.name].push(item.value || '');
            }
        });
        return obj;
    };
    $(document).ready(function () {
        if ($('#woo-ajaxsearchform').length > 0) {
            var el = $('.ui.search');
            el.search({
                //debug: true,
                apiSettings: {
                    url: WooSearch.ajax_url,
                    method: 'POST',
                    action: 'search',
                    className: {
                        loading : 'woo-loading',
                        error   : 'error'
                    },
                    beforeSend: function(settings) {
                        var action = {'action':'search_products'};
                        settings.data = $.extend( {}, action, $(this).closest('form').serializeObject() );
                        return settings;
                    }
                },
                minCharacters : WooSearch.min_chars,
                maxResults:WooSearch.posts_per_page,
                fields: {
                    results : 'results',
                    title   : 'title',
                    description: 'description',
                    image : 'image',
                    price : 'price',
                },
                type: 'special',
                //cache:false,
            });
            $('select[name="product_cat"]').on('change', function () {
                var el = $(this).closest('form').find('.ui.search');
                $(el).search("clear cache").search("event focus");
                /*setTimeout(function(){
                    $(el).find('input.prompt').focus();
                }, 500);*/
            });
        }
    });
})(jQuery);